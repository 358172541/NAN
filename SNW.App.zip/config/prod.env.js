'use strict'

module.exports = {
    NODE_ENV: '"production"',
    BASE_URL: '"http://192.168.2.49:8001"'
}
