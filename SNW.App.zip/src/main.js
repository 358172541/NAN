import Vue from 'vue'
import App from './App'

import router from '@/router'
import store from '@/store'

import './var.scss'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'

import ElementUI from 'element-ui'
Vue.use(ElementUI)

import VueMobileAudio from 'vue-mobile-audio'
Vue.use(VueMobileAudio)

import VueQuillEditor from 'vue-quill-editor'
Vue.use(VueQuillEditor)

Vue.config.productionTip = false

Vue.prototype.$ELEMENT = { size: 'small', zIndex: 2333 }

new Vue({
    el: '#app',
    router,
    store,
    components: { App },
    template: '<App/>'
})
