<template>
    <router-view />
</template>

<script>
    export default {
        name: 'App',
        data() {
            return {

            }
        }
    }
</script>

<style lang="scss">
    /*****************************************************************/

    @import "./var.scss";

    /*****************************************************************/

    .box-shadow {
        box-shadow: 0 0 2px rgba(0, 0, 0, 0.4);
    }

    .margin-top {
        margin-top: 8px;
    }

    .padding {
        padding: 20px;
    }

    .margin-bottom-8 {
        margin-bottom: 8px;
    }

    .width-100-percent {
        width: 100%;
    }

    /*****************************************************************/

    /*.quill-editor {
        display: flex;
        flex-direction: column-reverse;

        .ql-container.ql-snow {
            border-top: 1px solid #ccc !important;
        }

        .ql-toolbar.ql-snow {
            border-top: 0px !important;
        }
    }*/

    /*****************************************************************/
    .el-button {
        margin: unset !important;

        &.el-button--small {
            padding: 8.5px !important;
        }
    }

    .el-date-editor {
        &.el-input {
            width: 100% !important;
        }

        &.el-input__inner {
            width: 100% !important;
        }
    }

    .el-descriptions {
        .el-descriptions-item {
            &.el-descriptions-item__cell {
                padding-bottom: 8px !important;
            }
        }
    }

    .el-scrollbar {
        &[noscrollx] {
            height: 100% !important;

            .el-scrollbar__wrap {
                overflow-x: hidden !important;
            }
        }
    }

    .el-dialog__wrapper {
        text-align: center !important;

        &:after {
            content: "" !important;
            display: inline-block !important;
            height: 100% !important;
            vertical-align: middle !important;
        }

        .el-dialog {
            display: inline-block !important;
            margin-top: unset !important;
            vertical-align: middle !important;

            .el-dialog__header {
                border-bottom: 1px solid $--border-color-base !important;
                box-sizing: border-box !important;
                padding: 7.5px 20px !important;
                text-align: left !important;

                .el-dialog__headerbtn {
                    font-size: $--font-size-medium !important;
                    top: 12px !important;
                }
            }

            .el-dialog__body {
                max-height: cacl(100vh) !important;
                overflow-y: auto !important;
                padding: 20px !important;
                text-align: left !important;
            }

            .el-dialog__footer {
                padding: 0px 20px 20px 20px !important;
            }
        }
    }
    
    .el-dropdown-menu {
        padding: unset !important;

        .el-dropdown-menu__item {
            /*height: 40px !important;
            line-height: 40px !important;*/

            i {
                font-size: $--font-size-medium !important;
            }
        }
    }

    .el-select-dropdown {
        .el-select-dropdown__wrap {
            max-height: 276px !important;

            .el-select-dropdown__list {
                padding: unset !important;

                .el-select-dropdown__item {
                    /*height: 40px !important;
                    line-height: 40px !important;*/

                    i {
                        font-size: $--font-size-medium !important;
                    }
                }
            }
        }
    }
    
    .el-header {
        padding: unset !important;

        .el-header__wrapper {
            ul {
                letter-spacing: -9px !important;
                list-style: none !important;

                li {
                    color: $--color-white !important;
                    cursor: pointer !important;
                    display: inline-block !important;
                    letter-spacing: normal !important;
                    text-align: center !important;

                    &:hover {
                        background-color: #E74C3C !important;
                    }

                    .el-avatar {
                        margin-top: -4px !important;
                        vertical-align: middle !important;
                    }

                    i {
                        color: $--color-white !important;
                        font-size: $--font-size-medium !important;
                    }
                }
            }
        }
    }

    .v-modal {
        opacity: .3 !important;
    }

    .el-input-number {
        .el-input__inner {
            text-align: left !important;
        }
    }

    .el-menu {
        border-right: unset !important;

        &.el-menu--popup {
            padding: unset !important;
        }

        .el-submenu {
            .el-submenu__title {
                color: $--color-white !important;
                height: 40px !important;
                line-height: 40px !important;

                &:hover {
                    background-color: #E74C3C !important;
                }
            }
        }

        .el-menu-item {
            color: $--color-white !important;
            height: 40px !important;
            line-height: 40px !important;

            &:hover {
                background-color: #E74C3C !important;
            }

            &.is-active {
                background-color: #E74C3C !important;
            }
        }

        i {
            color: $--color-white !important;
            font-size: $--font-size-medium !important;
            margin-right: unset !important;
            width: $--font-size-medium !important;
        }
    }

    .el-pagination {
        padding: unset !important;

        &.is-background {
            .btn-prev {
                background: $--color-white !important;
                border-bottom: 1px solid $--border-color-base !important;
                border-left: 1px solid $--border-color-base !important;
                border-top: 1px solid $--border-color-base !important;
                border-radius: $--pagination-border-radius !important;
                box-sizing: border-box !important;
                font-weight: $--font-weight-primary !important;
                margin: unset !important;
            }

            .btn-next {
                background: $--color-white !important;
                border: 1px solid $--border-color-base !important;
                border-radius: $--pagination-border-radius !important;
                box-sizing: border-box !important;
                font-weight: $--font-weight-primary !important;
                margin: unset !important;
            }

            .el-pager {
                li {
                    background: $--color-white !important;
                    border-bottom: 1px solid $--border-color-base !important;
                    border-left: 1px solid $--border-color-base !important;
                    border-top: 1px solid $--border-color-base !important;
                    border-radius: $--pagination-border-radius !important;
                    box-sizing: border-box !important;
                    font-weight: $--font-weight-primary !important;
                    margin: unset !important;

                    &:not(.disabled) {
                        &.active {
                            color: $--color-primary !important;
                        }
                    }
                }
            }

            .el-pagination__sizes {
                margin: 0px 3px !important;

                .el-input {
                    .el-input__inner {
                        border-color: $--border-color-base !important;
                        height: $--pagination-button-height !important;
                    }
                }
            }

            .el-pagination__total {
                margin-left: 8px !important;
            }
        }
    }

    .el-popover {
        border-radius: $--border-radius-base !important;
    }

    .el-drawer {
        .el-drawer__header {
            border-bottom: 1px solid $--border-color-base !important;
            box-sizing: border-box !important;
            font-size: $--font-size-base !important;
            margin-bottom: unset !important;
            padding: 11px 20px !important;
            text-align: left !important;

            .el-drawer__close-btn {
                font-size: $--font-size-medium !important;
                padding: unset !important;
                margin-top: 2px !important;
            }
        }
    }

    .el-switch {
        &[nocursor] {
            .el-switch__core {
                cursor: unset !important;
            }
        }
    }

    .el-table {
        &.el-table {
            font-size: $--font-size-base !important;
        }

        .el-table__cell {
            height: 40px !important;
        }

        .cell {
            line-height: 1.5em !important;
            /*padding: 2px 8px !important;*/
        }

        .el-button--mini {
            font-size: $--font-size-base !important;
            margin-left: unset !important;
            padding: 4px !important;
        }
    }

    /*****************************************************************/
</style>
