var en={

    'common':{
        'service':'service',
        'serviceStatus':'status',
    }
}
export default en