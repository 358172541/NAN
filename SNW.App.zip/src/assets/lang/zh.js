var zh={
    'common':{
        'service':'服务',
        'serviceStatus':'状态',
    }
}
export default zh