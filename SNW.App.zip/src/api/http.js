import axios from 'axios'
import { Message } from 'element-ui'

const instance = axios.create({
    baseURL: process.env.BASE_URL,
    timeout: 30000
})

instance.interceptors.request.use(config => {
    if (localStorage.getItem('TOKEN')) {
        config.headers['Authorization'] = 'Bearer' + ' ' + localStorage.getItem('TOKEN')
    }
    return config
}, error => {
    Promise.reject(error)
})

instance.interceptors.response.use(response => {
    return response
}, async error => {
    if (error && error.response) {

        let response = error.response
        let responseData = response.data
        let responseStatus = response.status

        if (responseData instanceof Blob) {
            let blob = new Blob([responseData], {
                type: "application/json"
            })
            let reader = new FileReader()
            reader.onload = (ev) => {
                Message({
                    showClose: true,
                    message: '[' + responseStatus + ']' + ev.target.result,
                    type: 'error'
                })
            }
            reader.readAsText(blob)
        } else { // default
            switch (error.response.status) { // if(error.response.headers['x-validation'])

                case 400:
                    Message({
                        showClose: true,
                        message: '[' + responseStatus + ']' + responseData,
                        type: 'error'
                    })
                    break

                /*
                case 401:
                    if (error.response.headers['x-token']) {
                        store.commit('SIGNOUT')
                        router.push({ name: 'Login' })
                        refreshing = false
                        refreshingInvocation = null
                    } else {
                        return refresh(_ => axios.request(error.config))
                    }
                    break
                */

                case 500:
                    Message({
                        showClose: true,
                        message: response,
                        type: 'error'
                    })
                    break

                default:
                    Message({
                        showClose: true,
                        message: '[' + responseStatus + ']' + responseData,
                        type: 'error'
                    })
            }
        }
    }
    return Promise.reject(error)
})

export default instance
