import http from '../http'

export function getTransitGatherPrintParams(parameter) {
    return http({
        method:'get',
        url:'api/transit/transit_gather_print',
        params:parameter
    })
}

export function GetDeliveryRegions(parameter) {
    return http({
        method:'get',
        url:'api/packages/transit/GetDeliveryRegions',
        params:parameter
    })
}

export function BatchUpdateRouteDeliveryRegionProc(parameter) {
    return http({
        method:'post',
        url:'api/packages/transit/BatchUpdateRouteDeliveryRegionProc',
        data:parameter
    })
}

export function StartUnpackCheck(parameter) {
    return http({
        method:'post',
        url:'api/packages/transit/StartUnpackCheck',
        params:parameter
    })
}

export function ForceCheckPass(parameter) {
    return http({
        method:'post',
        url:'api/PackageUnpackScan/ForceCheckPass',
        params:parameter
    })
}

export function RollbackToExpressGather(parameter) {
    return http({
        method:'post',
        url:'api/PackageUnpackScan/RollbackToExpressGather',
        params:parameter
    })
}
