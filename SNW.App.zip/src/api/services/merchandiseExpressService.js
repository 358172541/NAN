import http from '../http'

export function GetExpressList(parameter) {
    return http({
        method:'get',
        url:'/api/transit/get_transit_info_list',
        params:parameter
    })
}

export function UpdateShipStatus(parameter) {
    return http({
        method:'put',
        url:'/api/transit/UpdateShipStatus',
        data:parameter
    })
}

export function Edit(parameter) {
    return http({
        method:'put',
        url:'/api/transit/Edit',
        data:parameter
    })
}

export function LinkToSurper(parameter) {
    return http({
        method:'post',
        url:'/api/transit/LinkToSurper',
        params:parameter
    })
}

export function EditRegion(parameter) {
    return http({
        method:'post',
        url:'/api/transit/EditRegion',
        params:parameter
    })
}

export function GetReportList(parameter) {
    return http({
        method:'get',
        url:'/api/transit/GetReportList',
        params:parameter
    })
}

export function BatchDeleteReport(parameter) {
    return http({
        method:'delete',
        url:'/api/transit/BatchDeleteReport',
        data:parameter
    })
}

export function GenerateReport(parameter) {
    return http({
        method:'get',
        url:'/api/transit/GenerateReport',
        params:parameter
    })
}

export function GetPackageManageInfoList(parameter) {
    return http({
        method:'get',
        url:'/api/transit/GetPackageManageInfoList',
        params:parameter
    })
}

export function BatchUpdateTransitInfo(parameter) {
    return http({
        method:'post',
        url:'/api/transit/BatchUpdateTransitInfo',
        data:parameter
    })
}
