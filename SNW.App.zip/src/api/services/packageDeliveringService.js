import http from '../http'

//
export function packageDeliveringSearch(params) {
    return http({
        method: 'get',
        url: 'api/packages/delivering',
        params
    })
}
