import http from '../http'

//
export function routeSearch(params) {
    return http({
        method: 'get',
        url: 'api/routes',
        params
    })
}

//
export function routeSingle(id) {
    return http({
        method: 'get',
        url: 'api/routes/' + id,
        params: {}
    })
}

//
export function routeCreate(data) {
    return http({
        method: 'post',
        url: 'api/routes',
        data
    })
}

//
export function routeUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/routes/' + id,
        data
    })
}

//
export function routeDelete(id) {
    return http({
        method: 'delete',
        url: 'api/routes/' + id,
        params: {}
    })
}
