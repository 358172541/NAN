import http from '../http'

export function permissionSearch() {
    return http({
        method: 'get',
        url: 'api/permissions',
        params: {}
    })
}

export function permissionSingle(key) {
    return http({
        method: 'get',
        url: 'api/permissions/' + key,
        params: {}
    })
}

export function permissionCreate(data) {
    return http({
        method: 'post',
        url: 'api/permissions',
        data
    })
}

export function permissionUpdate(key, data) {
    return http({
        method: 'put',
        url: 'api/permissions/' + key,
        data
    })
}

export function permissionDelete(key) {
    return http({
        method: 'delete',
        url: 'api/permissions/' + key,
        params: {}
    })
}
