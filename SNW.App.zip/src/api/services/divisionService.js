import http from '../http'

//
export function divisionSearch(params) {
    return http({
        method: 'get',
        url: 'api/divisions',
        params
    })
}

//
export function divisionSingle(id) {
    return http({
        method: 'get',
        url: 'api/divisions/' + id,
        params: {}
    })
}

//
export function divisionCreate(data) {
    return http({
        method: 'post',
        url: 'api/divisions',
        data
    })
}

//
export function divisionUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/divisions/' + id,
        data
    })
}

//
export function divisionDelete(id) {
    return http({
        method: 'delete',
        url: 'api/divisions/' + id,
        params: {}
    })
}
