import http from '../http'

// 用户下拉框
export function GetUsers(){
    return http({
        method: 'get',
        url: 'api/PackageLookup/GetUsers',
    })
}

// 航线下拉框
export function GetRoutes(){
  return http({
      method: 'get',
      url: 'api/PackageLookup/GetRoutes',
  })
}

// 船次下拉框
export function GetShipNos(){
  return http({
      method: 'get',
      url: 'api/PackageLookup/GetShipNos',
  })
}

// 地区下拉框
export function GetRegionList(){
  return http({
      method: 'get',
      url: 'api/PackageLookup/GetRegions',
  })
}

export function GetRegionList2(){
  return http({
      method: 'get',
      url: 'api/PackageLookup/GetRegions2',
  })
}

// 派送地区下拉框
export function GetDeliveryRegionDropdownList(){
  return http({
      method: 'get',
      url: 'api/PackageLookup/GetDeliveryRegionDropdownList',
  })
}

// 调柜部门
export function GetAdjustDepartments(){
  return http({
      method: 'get',
      url: 'api/PackageLookup/GetAdjustDepartments',
  })
}

// 开单人列表
export function GetAdmins(){
  return http({
      method: 'get',
      url: 'api/PackageLookup/GetAdmins',
  })
}
