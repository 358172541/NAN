import http from '../http'

export function BatchUpdateItemStatus(params) {
    return http({
        method: 'put',
        url: 'api/packages/storage/batch_update_itemstatusXX',
        data:params
    })
}

export function BatchDelete(params) {
    return http({
        method: 'delete',
        url: 'api/packages/storage/BatchDelete',
        data:params
    })
}

export function BatchUpdateRegion(params) {
    return http({
        method: 'put',
        url: 'api/packages/storage/BatchUpdateRegion',
        data:params
    })
}

export function UpdateToNewLibrary(params) {
    return http({
        method: 'put',
        url: 'api/packages/storage/UpdateToNewLibrary',
        data:params
    })
}
