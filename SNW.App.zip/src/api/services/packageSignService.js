import http from '../http'

export function ScanOpenOrder(parameter) {
    return http({
        method: 'post',
        url: 'api/v1/PackageSign/ScanOpenOrder',
        data:parameter
    })
}
