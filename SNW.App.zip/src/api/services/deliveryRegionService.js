import http from '../http'

//
export function deliveryRegionSearch(params) {
    return http({
        method: 'get',
        url: 'api/delivery_regions',
        params
    })
}

//
export function deliveryRegionSearch2(id, params) {
    return http({
        method: 'get',
        url: 'api/delivery_regions/' + id + '/delivery_regions',
        params
    })
}

//
export function deliveryRegionSingle(id) {
    return http({
        method: 'get',
        url: 'api/delivery_regions/' + id,
        params: {}
    })
}

//
export function deliveryRegionCreate(data) {
    return http({
        method: 'post',
        url: 'api/delivery_regions',
        data
    })
}

//
export function deliveryRegionUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/delivery_regions/' + id,
        data
    })
}

//
export function deliveryRegionDelete(id) {
    return http({
        method: 'delete',
        url: 'api/delivery_regions/' + id,
        params: {}
    })
}
