import http from '../http'

export function SupplementAndPrint(parameter) {
    return http({
        method: 'post',
        url: 'api/SupplementOrder/SupplementAndPrint',
        data:parameter
    })
}
