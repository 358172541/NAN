import http from '../http'

export function getLookupAdmins() {
    return http({
        method: 'get',
        url: 'api/lookups/admin',
        params: {}
    })
}

export function getLookupAdminTypes() {
    return http({
        method: 'get',
        url: 'api/lookups/admin_type',
        params: {}
    })
}

export function getLookupItemTypes() {
    return http({
        method: 'get',
        url: 'api/lookups/item_type',
        params: {}
    })
}

export function getLookupBalanceStatuses() {
    return http({
        method: 'get',
        url: 'api/lookups/balance_status',
        params: {}
    })
}

export function getLookupContentCategories() {
    return http({
        method: 'get',
        url: 'api/lookups/content_category',
        params: {}
    })
}

export function getLookupDeliveryRegions() {
    return http({
        method: 'get',
        url: 'api/lookups/delivery_region',
        params: {}
    })
}

export function getLookupDeliveryRoutes() {
    return http({
        method: 'get',
        url: 'api/lookups/delivery_route',
        params: {}
    })
}

export function getLookupMembers() {
    return http({
        method: 'get',
        url: 'api/lookups/member',
        params: {}
    })
}

export function getLookupPermissions() {
    return http({
        method: 'get',
        url: 'api/lookups/permission',
        params: {}
    })
}

export function getLookupPermissionTypes() {
    return http({
        method: 'get',
        url: 'api/lookups/permission_type',
        params: {}
    })
}

export function getLookupRegions() {
    return http({
        method: 'get',
        url: 'api/lookups/region',
        params: {}
    })
}

export function getLookupContainers() {
    return http({
        method: 'get',
        url: 'api/lookups/container',
        params: {}
    })
}
