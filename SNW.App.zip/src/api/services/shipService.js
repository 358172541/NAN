import http from '../http'

// 装柜中
export function Putting(parameter) {
    return http({
        method: 'put',
        url: '/api/ships/Putting',
        data:parameter
    })
}

// 是否装柜完成
export function IsFinishShip(parameter) {
    return http({
        method:'put',
        url:'/api/ships/IsFinishShip',
        data:parameter
    })
}

// 装柜完成
export function PutFinish(parameter) {
    return http({
        method: 'put',
        url: '/api/ships/PutFinish',
        data:parameter
    })
}

// 生成报表
export function GenerateReport(parameter) {
    return http({
        method: 'get',
        url: '/api/ships/GenerateReport',
        params:parameter
    })
}

// 获取报表列表
export function GetReportList(parameter) {
    return http({
        method: 'get',
        url: '/api/ships/GetReportList',
        params:parameter
    })
}

// 下载报表
export function BatchDeleteReport(parameter) {
    return http({
        method: 'delete',
        url: '/api/ships/BatchDeleteReport',
        data:parameter
    })
}

// 分票对话框数据
export function GetPackageSplitBillData(parameter){
  return http({
      method: 'get',
      url: '/api/ships/GetPackageSplitBillData',
      params:parameter
  })
}

// 分票提交
export function PackageSplitBillSubmit(parameter){
  return http({
      method: 'post',
      url: '/api/ships/PackageSplitBillSubmit',
      data:parameter
  })
}

// 从新库中选择
export function GetNewStorageListByShipNo(parameter){
  return http({
      method: 'get',
      url: '/api/ships/GetNewStorageListByShipNo',
      params:parameter
  })
}
export function GetStorageListByShipNo(parameter){
  return http({
      method: 'get',
      url: '/api/ships/GetStorageListByShipNo',
      params:parameter
  })
}

export function MoveToStorage(parameter){
  return http({
      method: 'post',
      url: '/api/ships/MoveToStorage',
      params:parameter
  })
}

export function FromNewStorageSelectBatchJoin(parameter){
  return http({
      method: 'post',
      url: '/api/ships/FromNewStorageSelectBatchJoin',
      data:parameter
  })
}
