import http from '../http'

export function contentCategorySearch() {
    return http({
        method: 'get',
        url: 'api/content_categories',
        params: {}
    })
}

export function contentCategorySingle(id) {
    return http({
        method: 'get',
        url: 'api/content_categories/' + id,
        params: {}
    })
}

export function contentCategoryCreate(data) {
    return http({
        method: 'post',
        url: 'api/content_categories',
        data
    })
}

export function contentCategoryUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/content_categories/' + id,
        data
    })
}

export function contentCategoryDelete(id) {
    return http({
        method: 'delete',
        url: 'api/content_categories/' + id,
        params: {}
    })
}
