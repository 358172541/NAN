import http from '../http'

//
export function regionSearch(params) {
    return http({
        method: 'get',
        url: 'api/regions',
        params
    })
}

//
export function regionSingle(id) {
    return http({
        method: 'get',
        url: 'api/regions/' + id,
        params: {}
    })
}

//
export function regionCreate(data) {
    return http({
        method: 'post',
        url: 'api/regions',
        data
    })
}

//
export function regionUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/regions/' + id,
        data
    })
}

//
export function regionDelete(id) {
    return http({
        method: 'delete',
        url: 'api/regions/' + id,
        params: {}
    })
}