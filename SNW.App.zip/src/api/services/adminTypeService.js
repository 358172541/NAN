import http from '../http'

//
export function adminTypeSearch() {
    return http({
        method: 'get',
        url: 'api/admin_types',
        params: {}
    })
}

//
export function adminTypeDeliveryRegions(id) {
    return http({
        method: 'get',
        url: 'api/admin_types/' + id + '/delivery_regions',
        params: {}
    })
}

//
export function adminTypePermissions(id) {
    return http({
        method: 'get',
        url: 'api/admin_types/' + id + '/permissions',
        params: {}
    })
}

//
export function adminTypeRegions(id) {
    return http({
        method: 'get',
        url: 'api/admin_types/' + id + '/regions',
        params: {}
    })
}

//
export function adminTypeDeliveryRegionsAssign(id, deliveryRegionIds) {
    return http({
        method: 'put',
        url: 'api/admin_types/' + id + '/delivery_regions',
        data: deliveryRegionIds
    })
}

//
export function adminTypePermissionsAssign(id, permissionIds) {
    return http({
        method: 'put',
        url: 'api/admin_types/' + id + '/permissions',
        data: permissionIds
    })
}

//
export function adminTypeRegionsAssign(id, regionIds) {
    return http({
        method: 'put',
        url: 'api/admin_types/' + id + '/regions',
        data: regionIds
    })
}
