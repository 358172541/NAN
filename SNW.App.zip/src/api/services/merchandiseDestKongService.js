import http from '../http'

export function DestKongSign(parameter){
    return http({
        method: 'post',
        url: 'api/PackageDestKongStorage/SignDone',
        data:parameter
    })
}

export function PickupMerchandise(parameter){
    return http({
        method: 'post',
        url: 'api/PackageDestKongStorage/PickupMerchandise',
        data:parameter
    })
}

export function DeliveryRegionProcess(parameter){
    return http({
        method: 'post',
        url: 'api/PackageDestKongStorage/DeliveryRegionProcess',
        data:parameter
    })
}

export function ExportToExcel(parameter){
    return http({
        method: 'get',
        url: 'api/PackageDestKongStorage/ExportToExcel',
        params:parameter
    })
}

export function SmallExportToExcel(parameter){
    return http({
        method: 'get',
        url: 'api/PackageDestKongStorage/SmallBagExportToExcel',
        params:parameter
    })
}
