import http from '../http'

//
export function friendlyLinkSearch(params) {
    return http({
        method: 'get',
        url: 'api/friendly_links',
        params
    })
}

//
export function friendlyLinkSingle(id) {
    return http({
        method: 'get',
        url: 'api/friendly_links/' + id,
        params: {}
    })
}

//
export function friendlyLinkCreate(data) {
    return http({
        method: 'post',
        url: 'api/friendly_links',
        data
    })
}

//
export function friendlyLinkUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/friendly_links/' + id,
        data
    })
}

//
export function friendlyLinkDelete(id) {
    return http({
        method: 'delete',
        url: 'api/friendly_links/' + id,
        params: {}
    })
}
