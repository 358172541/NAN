import http from '../http'

//
export function packageHistorySearch(params) {
    return http({
        method: 'get',
        url: 'api/packages/history',
        params
    })
}

//
export function packageHistoryExport(params) {
    return http({
        method: 'get',
        url: 'api/packages/history_export',
        params
    })
}

//
export function packageHistoryExportM(params) {
    return http({
        method: 'get',
        url: 'api/packages/history_export_m',
        params
    })
}
