import http from '../http'

// 批量快速、库存
export function BatchUpdate(params) {
    return http({
        method: 'put',
        url: 'api/PackageOpenOrder/BatchUpdate',
        data:params
    })
}
