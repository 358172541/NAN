import http from '../http'

// 处理完成
export function ProcDone(params) {
    return http({
        method: 'put',
        url: 'api/v1/PackageCollection/ProcDone',
        params:params
    })
}

// 对账完成
export function MatchBillDone(params) {
    return http({
        method: 'put',
        url: 'api/v1/PackageCollection/MatchBillDone',
        params:params
    })
}

// 对账完成
export function CanBeShipped(params) {
    return http({
        method: 'put',
        url: 'api/v1/PackageCollection/CanBeShipped',
        params:params
    })
}
