import http from '../http'

export function GetDataList(parameter) {
    return http({
        method: 'get',
        url: 'api/PackageUnpackScan/GetTearBoxScanDetectionList',
        params:parameter
    })
}

export function GetParamExtras(parameter) {
    return http({
        method: 'get',
        url: 'api/PackageUnpackScan/GetParamExtras',
        params:parameter
    })
}

// 导出Excel
export function ExportToExcel(parameter) {
    return http({
        method: 'get',
        url: 'api/PackageUnpackScan/ExportToExcel',
        params:parameter
    })
}

// 导出小包Excel
export function SmallBagExportToExcel(parameter) {
    return http({
        method: 'get',
        url: 'api/PackageUnpackScan/SmallBagExportToExcel',
        params:parameter
    })
}
