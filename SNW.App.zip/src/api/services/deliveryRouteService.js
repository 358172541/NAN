import http from '../http'

//
export function deliveryRouteSearch(params) {
    return http({
        method: 'get',
        url: 'api/delivery_routes',
        params
    })
}

//
export function deliveryRouteSingle(id) {
    return http({
        method: 'get',
        url: 'api/delivery_routes/' + id,
        params: {}
    })
}

//
export function deliveryRouteCreate(data) {
    return http({
        method: 'post',
        url: 'api/delivery_routes',
        data
    })
}

//
export function deliveryRouteUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/delivery_routes/' + id,
        data
    })
}

//
export function deliveryRouteDelete(id) {
    return http({
        method: 'delete',
        url: 'api/delivery_routes/' + id,
        params: {}
    })
}
