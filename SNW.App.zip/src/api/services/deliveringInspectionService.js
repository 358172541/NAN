import http from '../http'

//
export function deliveringInspectionSearch(params) {
    return http({
        method: 'get',
        url: 'api/delivering_inspection',
        params
    })
}
