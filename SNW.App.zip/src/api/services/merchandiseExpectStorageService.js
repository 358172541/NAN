import http from '../http'

export function Print(parameter){
    return http({
        method: 'post',
        url: 'api/PackageExpectStore/Print',
        data:parameter
    })
}

export function GetExpectSmallBagPrintImage(parameter){
    return http({
        method: 'post',
        url: '/api/PackageExpectStore/SmallBagPrint',
        data: parameter
    })
}
