import http from '../http'

//
export function barcode() {
    return http({
        method: 'get',
        url: 'api/examples/barcode',
        params: {}
    })
}

//
export function excel() {
    return http({
        method: 'get',
        url: 'api/examples/excel',
        params: {},
        responseType: 'blob'
    })
}

//
export function qrcode() {
    return http({
        method: 'get',
        url: 'api/examples/qrcode',
        params: {}
    })
}
