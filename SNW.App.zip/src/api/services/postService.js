import http from '../http'

// Post机相关接口


// 获取船次审核列表
export function GetShipCheckList(parameter) {
    return http({
        method: 'get',
        url: 'api/ShipCheck/GetShipCheckList',
        params:parameter
    })
}

// 船次审核
export function ShipCheck(parameter) {
    return http({
        method: 'post',
        url: 'api/ShipCheck/ShipCheck',
        params:parameter
    })
}

export function UnpackBoxSubmit(parameter) {
    return http({
        method: 'post',
        url: 'api/UnpackBox/Submit',
        params:parameter
    })
}

// 出货检测-列表
export function GetShippingCheckList(parameter) {
    return http({
        method: 'get',
        url: 'api/PostShippingCheck/GetShipCheckList',
        params:parameter
    })
}

// 出货检测-提交
export function ShippingCheckSubmit(parameter) {
    return http({
        method: 'post',
        url: 'api/PostShippingCheck/Submit',
        params:parameter
    })
}
