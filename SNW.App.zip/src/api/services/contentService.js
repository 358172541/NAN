import http from '../http'

export function contentSearch(params) {
    return http({
        method: 'get',
        url: 'api/contents',
        params
    })
}

export function contentSingle(id) {
    return http({
        method: 'get',
        url: 'api/contents/' + id,
        params: {}
    })
}

export function contentCreate(data) {
    return http({
        method: 'post',
        url: 'api/contents',
        data
    })
}

export function contentUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/contents/' + id,
        data
    })
}

export function contentDelete(id) {
    return http({
        method: 'delete',
        url: 'api/contents/' + id,
        params: {}
    })
}
