import http from '../http'

//
export function shiftSearch(params) {
    return http({
        method: 'get',
        url: 'api/shifts',
        params
    })
}

//
export function shiftSingle(id) {
    return http({
        method: 'get',
        url: 'api/shifts/' + id,
        params: {}
    })
}

//
export function shiftCreate(data) {
    return http({
        method: 'post',
        url: 'api/shifts',
        data
    })
}

//
export function shiftUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/shifts/' + id,
        data
    })
}

//
export function shiftDelete(id) {
    return http({
        method: 'delete',
        url: 'api/shifts/' + id,
        params: {}
    })
}

//
export function shiftPackagesSearch(id, params) {
    return http({
        method: 'get',
        url: 'api/shifts/' + id + '/packages',
        params
    })
}

//
export function shiftDetect(shiftIds) {
    return http({
        method: 'post',
        url: 'api/shifts/detect',
        data: shiftIds
    })
}

//
export function shiftFinish(shiftIds) {
    return http({
        method: 'post',
        url: 'api/shifts/finish',
        data: shiftIds
    })
}

//
export function shiftPackagesRemove(id, packageIds) {
    return http({
        method: 'put',
        url: 'api/shifts/' + id + '/packages_remove',
        data: packageIds
    })
}

//
export function shiftPackagesImport(id, packageIds) {
    return http({
        method: 'put',
        url: 'api/shifts/' + id + '/packages_import',
        data: packageIds
    })
}

//
export function shiftPackagesImportSearch(params) {
    return http({
        method: 'get',
        url: 'api/shifts/packages_import',
        params
    })
}

//
export function shiftPackagesExport(id) {
    return http({
        method: 'get',
        url: 'api/shifts/' + id + '/packages_export',
        params: {},
        responseType: 'blob'
    })
}

//
export function shiftPackagePackageNumberDestOutstockUnpassed(id) {
    return http({
        method: 'get',
        url: 'api/shift/package/' + id + '/package_number/dest_outstock_unpassed',
        params: {}
    })
}
