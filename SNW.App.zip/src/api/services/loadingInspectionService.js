import http from '../http'

//
export function loadingInspectionSearch(params) {
    return http({
        method: 'get',
        url: 'api/loading_inspection',
        params
    })
}
