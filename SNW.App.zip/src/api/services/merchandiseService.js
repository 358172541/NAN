import http from '../http'

// 货物-开单列表-筛选参数
export function get_open_order_filter_list_list() {
    return http({
        method: 'get',
        url: 'api/packages/get_open_order_filter_list_list'
    })
}

// 货物-开单列表
export function get_open_order_list(parameter) {
  console.log('call .....')
    return http({
        method: 'get',
        url: 'api/packages/get_open_order_list',
        params:parameter
    })
}

// 货物开单-参数
export function get_open_order_filter_param() {
    return http({
        method: 'get',
        url: 'api/packages/get_merchandise_open_order_filter_param'
    })
}

// 打印时条形码生成
export function Print_GetLabel(parameter){
    return http({
        method: 'post',
        url: 'api/ImageGenerate/GetLabel',
        data:parameter
    })
}

// 货物开单
export function OpenOrder(parameter){
    return http({
        method: 'post',
        url: 'api/packages/setup',
        data:parameter
    })
}

// 货物开单
export function OpenOrderItemDelete(parameter){
    return http({
        method: 'delete',
        url: 'api/packages/package_open_order_item_del',
        data:parameter
    })
}

// 小包-预入库
export function getSmallExpectStorageList(parameter){
    return http({
        method: 'get',
        url: 'api/packages/get_small_expect_storage_list',
        params: parameter
    })
}

// 小包-预入库參數
export function get_small_expect_storage_query_params(parameter){
    return http({
        method: 'get',
        url: 'api/packages/get_small_expect_storage_query_params',
        data: parameter
    })
}

// 大货-预入库-列表
export function get_big_expect_storage_list(parameter){
    return http({
        method: 'get',
        url: 'api/packages/get_big_expect_storage_list',
        params: parameter
    })
}

export function BatchDeleteExpectData(parameter){
    return http({
        method: 'delete',
        url: 'api/PackageExpectStore/BatchDelete',
        data: parameter
    })
}

// 包裹签收列表-筛选参数
export function get_package_signing_filter_params(){
    return http({
        method: 'get',
        url: 'api/packages/get_package_signing_filter_params',
    })
}

// 包裹签收列表
export function get_package_signing_list(parameter){
    return http({
        method: 'get',
        url: 'api/packages/get_package_signing_list',
        params: parameter
    })
}

// 包裹签收列表项更新
export function package_signing_list_item_edit(parameter){
    return http({
        method: 'put',
        url: 'api/packages/package_signing_list_item_edit',
        data: parameter
    })
}

// 包裹签收列表项删除
export function package_signing_list_item_del(parameter){
    return http({
        method: 'delete',
        url: 'api/packages/package_signing_list_del',
        data: parameter
    })
}

// 扫描签收包裹
export function ScanPackageSigning(parameter){
    return http({
        method: 'post',
        url: 'api/v1/PackageSign/ScanPackageSigning',
        data: parameter
    })
}

// 包裹签收列表-开单
export function PackageSignListOpenOrder(parameter){
    return http({
        method: 'post',
        url: 'api/packages/package_sign_list_open_order',
        data: parameter
    })
}

// 货物-入库->货物保存
export function PackageStoringSave(parameter){
    return http({
        method: 'post',
        url: 'api/packages/cargo_storage_package_save',
        data: parameter
    })
}

// 货物-入库->货物查询
export function PackageStoringSaveGetMerchandise(parameter){
    return http({
        method: 'get',
        url: 'api/packages/cargo_storage_get_package_by_id',
        params: parameter
    })
}

// 扫描入库-小包慢递
export function ScanStoringSmallBagSlowExpress(parameter){
    return http({
        method: 'post',
        url: 'api/packages/slow_express_scan_storage',
        params: parameter
    })
}

// 入库-小包慢递-查询
export function CargoStorageSmallSlowExpressQuery(parameter){
    return http({
        method: 'get',
        url: 'api/packages/cargo_storage_small_slow_express_query',
        params: parameter
    })
}

// 入库-小包慢递列表筛选参数查询
export function CargoStorageSmallSlowExpressListFilterParamQuery(parameter){
    return http({
        method: 'get',
        url: 'api/packages/cargo_storage_small_bag_slow_express_list_query_filter_params',
        params: parameter
    })
}

// 入库-小包慢递列表查询
export function CargoStorageSmallSlowExpressListQuery(parameter){
    return http({
        method: 'get',
        url: 'api/packages/cargo_storage_small_bag_slow_express_list_query',
        params: parameter
    })
}

// 信息补充及检测
export function GetInfoSupplementAndCheckList(parameter){
    return http({
        method: 'get',
        url: 'api/PackageInfoSupplement/CargoInfoSupplementListQuery',
        params: parameter
    })
}

// 信息补充及检测-获取包裹信息
export function GetInfoSupplementAndCheckGetPackageEditParam(parameter){
    return http({
        method: 'get',
        url: 'api/PackageInfoSupplement/GetPackageEditParam',
        params: parameter
    })
}

export function GetInfoSupplementAndCheckGetPackageUpdatePackage(parameter){
    return http({
        method: 'put',
        url: 'api/PackageInfoSupplement/UpdatePackage',
        data: parameter
    })
}

// 獲取貨物庫存列表
export function GetMerchandiseStorageList(parameter){
    return http({
        method: 'get',
        url: 'api/packages/storage',
        params: parameter
    })
}

export function GetMerchandiseQuickStorageList(parameter){
    return http({
        method: 'get',
        url: 'api/packages/quickstorage',
        params: parameter
    })
}

export function GetMerchandiseStorageListExtraParams(parameter){
    return http({
        method: 'get',
        url: 'api/packages/storage/get_extra_params',
        params: parameter
    })
}
export function GetQuickStorageExraParams(parameter){
    return http({
        method: 'get',
        url: 'api/packages/storage/GetQuickStorageExraParams',
        params: parameter
    })
}

export function GetShipList(parameter){
  return http({
      method: 'get',
      url: 'api/ships/get',
      params: parameter
  })
}

export function GetPackageByShipId(parameter){
  return http({
      method: 'get',
      url: 'api/ships/GetPackageByShipId',
      params: parameter
  })
}

export function CreateShip(parameter){
    return http({
        method: 'post',
        url: 'api/ships/create',
        data: parameter
    })
}

export function ShipCheck(parameter){
    return http({
        method: 'put',
        url: 'api/ships/ShipCheck',
        data: parameter
    })
}

export function UpdateShip(parameter){
    return http({
        method: 'put',
        url: 'api/ships/UpdateShip',
        data: parameter
    })
}

export function GetMerchandiseSettlementList(parameter){
    return http({
        method: 'get',
        url: 'api/packages/cargo_settle_accounts_list_query',
        params: parameter
    })
}

export function GetExpressGatherList(parameter){
    return http({
        method: 'get',
        url: 'api/transit/get_expressing_collect_list',
        params: parameter
    })
}

export function GetCollectionPackageList(parameter){
    return http({
        method: 'get',
        url: 'api/v1/PackageCollection/GetPackageList',
        params: parameter
    })
}

export function GetPackageListExtraParam(parameter){
    return http({
        method: 'get',
        url: 'api/v1/PackageCollection/GetPackageListExtraParam',
        params: parameter
    })
}

export function GetDestKongStorageList(parameter){
    return http({
        method: 'get',
        url: '/api/packages/get_destination_kong_store_list',
        params: parameter
    })
}

export function SupplementInformation(parameter){
    return http({
        method: 'post',
        url: '/api/packageInfoSupplement/SupplementInformation',
        data: parameter
    })
}

export function GetExpressNoByUserIdAndRegionId(parameter){
    return http({
        method: 'get',
        url: '/api/packages/GetExpressNoByUserIdAndRegionId',
        params: parameter
    })
}

export function BatchUpdateBalanceStatus(parameter){
    return http({
        method: 'put',
        url: '/api/packages/BatchUpdateBalanceStatus',
        params: parameter
    })
}

export function LoadExistAddress(parameter){
    return http({
        method: 'get',
        url: '/api/PackageInfoSupplement/GetDefaultAddress',
        params: parameter
    })
}

export function GetExpectSmallBagPrintImage(parameter){
    return http({
        method: 'get',
        url: '/api/PackageExpectStore/GetDefaultAddress',
        params: parameter
    })
}
