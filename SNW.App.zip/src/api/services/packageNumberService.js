import http from '../http'

export function getPagedPackageNumbersByPackageId(packageId, params) {
    return http({
        method: 'get',
        url: 'api/package_numbers/package_id/' + packageId,
        params
    })
}
