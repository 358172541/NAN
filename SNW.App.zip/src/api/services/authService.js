import http from '../http'

//
export function authsToken4Admin(data) {
    return http({
        method: 'post',
        url: 'api/auths/token4admin',
        data
    })
}

export function authsToken4Member(data) {
    return http({
        method: 'post',
        url: 'api/auths/token4member',
        data
    })
}
