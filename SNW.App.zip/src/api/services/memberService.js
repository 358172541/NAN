import http from '../http'

//
export function memberSearch(params) {
    return http({
        method: 'get',
        url: 'api/members',
        params
    })
}

//
export function memberSingle(id) {
    return http({
        method: 'get',
        url: 'api/members/' + id,
        params: {}
    })
}

//
export function memberCreate(data) {
    return http({
        method: 'post',
        url: 'api/members',
        data
    })
}

//
export function memberUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/members/' + id,
        data
    })
}

//
export function memberDelete(id) {
    return http({
        method: 'delete',
        url: 'api/members/' + id,
        params: {}
    })
}
