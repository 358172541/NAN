import http from '../http'

//
export function adminSearch(params) {
    return http({
        method: 'get',
        url: 'api/admins',
        params
    })
}

//
export function adminSingle(id) {
    return http({
        method: 'get',
        url: 'api/admins/' + id,
        params: {}
    })
}

//
export function adminCreate(data) {
    return http({
        method: 'post',
        url: 'api/admins',
        data
    })
}

//
export function adminUpdate(id, data) {
    return http({
        method: 'put',
        url: 'api/admins/' + id,
        data
    })
}

//
export function adminDelete(id) {
    return http({
        method: 'delete',
        url: 'api/admins/' + id,
        params: {}
    })
}
