<template>
    <el-container class="main">

        <el-aside :width="sideWidth" :style="{'background-color':backgroundColor,'z-index':zIndex}" class="side">

            <el-header :style="{'height':height,'line-height':lineHeight}" class="mark">
                <el-row type="flex">
                    <i class="el-icon-s-management logo"
                       :style="{'height':height,'line-height':lineHeight,'width':width}" />
                    <span class="titl" v-if="!isCollapse">云第海运</span>
                </el-row>
            </el-header>

            <el-scrollbar noscrollx>

                <div class="info" v-if="!isCollapse">
                    <el-avatar class="avatar"
                               src="https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg"
                               :size="55"></el-avatar>
                    <div class="name">
                        <p>超级管理员</p>
                        <!--
                        <i class="el-icon-user-solid"></i>
                        <i class="el-icon-s-comment"></i>
                        <i class="el-icon-s-tools"></i>
                        <i class="el-icon-switch-button"></i>
                        -->
                    </div>
                </div>

                <el-menu router
                         unique-opened
                         :background-color="backgroundColor"
                         :collapse-transition="false"
                         :collapse="isCollapse"
                         :default-active="$store.state.DEFAULT_ACTIVE">

                    <!--<el-menu-item index="dashboard">
                        <i class="el-icon-pie-chart" />
                        <span slot="title">仪表盘</span>
                    </el-menu-item>-->

                    <el-menu-item index="home">
                        <i class="el-icon-s-home" />
                        <span slot="title">首页</span>
                    </el-menu-item>

                    <el-submenu index="basic">
                        <template slot="title">
                            <i class="el-icon-ice-tea" />
                            <span>基础信息</span>
                        </template>

                        <el-menu-item index="region">
                            <i class="el-icon-location" />
                            <span>地区</span>
                        </el-menu-item>

                        <!--
                            <el-menu-item index="division">
                                <i class="el-icon-add-location" />
                                <span>区域划分</span>
                            </el-menu-item>
                        -->

                        <el-menu-item index="deliveryRegion">
                            <i class="el-icon-timer" />
                            <span>派送地区</span>
                        </el-menu-item>

                        <el-menu-item index="deliveryRoute">
                            <i class="el-icon-place" />
                            <span>派送路线</span>
                        </el-menu-item>

                        <el-menu-item index="member">
                            <i class="el-icon-user" />
                            <span>会员</span>
                        </el-menu-item>

                        <el-menu-item index="permission">
                            <i class="el-icon-s-marketing" />
                            <span>权限</span>
                        </el-menu-item>

                        <el-menu-item index="adminType">
                            <i class="el-icon-s-check" />
                            <span>管理员类型</span>
                        </el-menu-item>

                        <el-menu-item index="admin">
                            <i class="el-icon-coordinate" />
                            <span>管理员</span>
                        </el-menu-item>

                    </el-submenu>

                    <el-submenu index="merchandise">
                        <template slot="title">
                            <i class="el-icon-s-cooperation" />
                            <span>货物管理</span>
                        </template>

                        <el-menu-item index="PackageSign">
                            <i class="el-icon-tickets" />
                            <span>包裹签收</span>
                        </el-menu-item>

                        <el-menu-item index="PackageSignList">
                            <i class="el-icon-tickets" />
                            <span>包裹签收列表</span>
                        </el-menu-item>

                        <el-menu-item index="BigBagStoring">
                            <i class="el-icon-shopping-bag-1" />
                            <span>大货-预报</span>
                        </el-menu-item>

                        <el-menu-item index="SmallBagStoring">
                            <i class="el-icon-shopping-bag-2" />
                            <span>小包-预报</span>
                        </el-menu-item>

                        <el-menu-item index="OpenOrder">
                            <i class="el-icon-open" />
                            <span>开单</span>
                        </el-menu-item>

                        <el-menu-item index="OpenOrderList">
                            <i class="el-icon-coin" />
                            <span>开单列表</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseStoring">
                            <i class="el-icon-first-aid-kit" />
                            <span>货物-入库</span>
                        </el-menu-item>

                        <el-menu-item index="ScanStoringSmallBagSlowExpress">
                            <i class="el-icon-first-aid-kit" />
                            <span>扫描入库-小包慢递</span>
                        </el-menu-item>

                        <el-menu-item index="PackageStoringSmallBagSlowExpress">
                            <i class="el-icon-first-aid-kit" />
                            <span>入库-小包慢递</span>
                        </el-menu-item>

                        <el-menu-item index="PackageStoringSmallBagSlowExpressList">
                            <i class="el-icon-set-up" />
                            <span>入库-小包慢递列表</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseInfoSupplementAndCheckList">
                            <i class="el-icon-toilet-paper" />
                            <span>货物-信息补充及检测</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseStrageList">
                            <i class="el-icon-present" />
                            <span>货物-库存</span>
                        </el-menu-item>
                        <el-menu-item index="MerchandiseQuickStorageList">
                            <i class="el-icon-film" />
                            <span>货物-快速库存</span>
                        </el-menu-item>
                        <el-menu-item index="MerchandiseShipCreate">
                            <i class="el-icon-ship"></i>
                            <span>货物-船次建立</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseSettlementList">
                            <i class="el-icon-mobile-phone"></i>
                            <span>货物-结算</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseExpressInfoList">
                            <i class="el-icon-truck"></i>
                            <span>货物-运输信息</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseExpressGatherList">
                            <i class="el-icon-truck"></i>
                            <span>货物-运输中汇总</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseCollectFreightList">
                            <i class="el-icon-soccer"></i>
                            <span>货物-代收运费</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseUnpackScanCheckList">
                            <i class="el-icon-aim"></i>
                            <span>货物-拆柜扫描检测</span>
                        </el-menu-item>

                        <el-menu-item index="MerchandiseDestKongStoreList">
                            <i class="el-icon-wind-power"></i>
                            <span>货物-目的港库存</span>
                        </el-menu-item>

                        <el-menu-item index="shift">
                            <i class="el-icon-truck" />
                            <span slot="title">货物-派送路线车次</span>
                        </el-menu-item>

                        <!--<el-menu-item index="loadingInspection">
                            <i class="el-icon-tickets" />
                            <span slot="title">货物-装柜检测</span>
                        </el-menu-item>-->
                        <!--<el-menu-item index="unpackingInspection">
                            <i class="el-icon-tickets" />
                            <span slot="title">货物-拆柜入仓检测</span>
                        </el-menu-item>-->
                        <!--<el-menu-item index="deliveringInspection">
                            <i class="el-icon-tickets" />
                            <span slot="title">货物-车次出库检测</span>
                        </el-menu-item>-->
                        <!--<el-menu-item index="delivery">
                            <i class="el-icon-tickets" />
                            <span slot="title">送货员-派送</span>
                        </el-menu-item>-->

                        <el-menu-item index="packageDelivering">
                            <i class="el-icon-truck" />
                            <span slot="title">货物-派送中</span>
                        </el-menu-item>
                        <el-menu-item index="MerchandiseSupplementOrder">
                            <i class="el-icon-tickets" />
                            <span slot="title">货物-补单</span>
                        </el-menu-item>
                        <el-menu-item index="PostShipCheckList">
                            <i class="el-icon-mobile-phone" />
                            <span slot="title">Post机-船次审核</span>
                        </el-menu-item>
                        <el-menu-item index="PostUnpackCheckList">
                            <i class="el-icon-mobile-phone" />
                            <span slot="title">Post机-拆柜检测</span>
                        </el-menu-item>
                        <el-menu-item index="PostShippingCheckList">
                            <i class="el-icon-mobile-phone" />
                            <span slot="title">Post机-出货检测</span>
                        </el-menu-item>
                        <el-menu-item index="packageHistory">
                            <i class="el-icon-potato-strips" />
                            <span slot="title">历史包裹</span>
                        </el-menu-item>
                    </el-submenu>
                    <el-submenu index="website">
                        <template slot="title">
                            <i class="el-icon-news" />
                            <span>网站前台</span>
                        </template>

                        <el-menu-item index="contentCategory">
                            <i class="el-icon-tickets" />
                            <span>内容类别</span>
                        </el-menu-item>

                        <el-menu-item index="content">
                            <i class="el-icon-tickets" />
                            <span>内容</span>
                        </el-menu-item>

                        <el-menu-item index="friendlyLink">
                            <i class="el-icon-tickets" />
                            <span>友情链接</span>
                        </el-menu-item>
                    </el-submenu>
                    <el-submenu index="exampleModule">
                        <template slot="title">
                            <i class="el-icon-tickets" />
                            <span>Development</span>
                        </template>

                        <el-menu-item index="drawerExample">
                            <i class="el-icon-tickets" />
                            <span>Drawer</span>
                        </el-menu-item>

                        <el-menu-item index="exportExample">
                            <i class="el-icon-tickets" />
                            <span>Export</span>
                        </el-menu-item>

                        <el-menu-item index="importExample">
                            <i class="el-icon-tickets" />
                            <span>Import</span>
                        </el-menu-item>

                        <el-menu-item index="printExample">
                            <i class="el-icon-tickets" />
                            <span>Print</span>
                        </el-menu-item>

                        <el-menu-item index="printLabelExample">
                            <i class="el-icon-tickets" />
                            <span>Print Label</span>
                        </el-menu-item>

                        <el-menu-item index="quillEditorExample">
                            <i class="el-icon-tickets" />
                            <span>Rich Editor</span>
                        </el-menu-item>
                        <el-menu-item index="sundryExample">
                            <i class="el-icon-tickets" />
                            <span>Sundry</span>
                        </el-menu-item>
                    </el-submenu>

                </el-menu>

            </el-scrollbar>

        </el-aside>

        <el-container>
            <el-header :height="height" :style="{'background-color': backgroundColor,'z-index':zIndex}">
                <el-row type="flex" justify="space-between" class="el-header__wrapper">
                    <ul>
                        <li :style="{'height':height,'line-height':lineHeight,'width':width}" @click="collapse">
                            <i :class="[isCollapse?'el-icon-d-arrow-right':'el-icon-d-arrow-left']" />
                        </li>
                        <li :style="{'height':height,'line-height':lineHeight,'width':width}" @click="refresh">
                            <i class="el-icon-refresh" />
                        </li>
                    </ul>
                    <ul>
                        <!--
                        <li :style="{'height':height,'line-height':lineHeight,'width':width}">
                            <el-popover placement="bottom-end" trigger="click" width="251" title="标题" content="这是一段内容。">
                                <div slot="reference">
                                    <i class="el-icon-s-comment" />
                                </div>
                            </el-popover>
                        </li>
                        -->

                        <li :style="{'height':height,'line-height':lineHeight,'width':width}">
                            <el-dropdown placement="bottom-end"
                                         size="small"
                                         trigger="click"
                                         @command="command">
                                <div :style="{'height':height,'line-height':lineHeight,'width':width}">
                                    <el-avatar src="https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg"
                                               size="medium"></el-avatar>
                                </div>
                                <el-dropdown-menu slot="dropdown">
                                    <el-dropdown-item command="signout">退出登录</el-dropdown-item>
                                </el-dropdown-menu>
                            </el-dropdown>
                        </li>

                        <li :style="{'height':height,'line-height':lineHeight,'width':width}" @click="screenfull">
                            <i class="el-icon-full-screen" />
                        </li>
                    </ul>
                </el-row>
            </el-header>

            <!--
            <div class="bred">
                <el-breadcrumb separator="/" style="height:40px;line-height:40px">
                    <el-breadcrumb-item>首页</el-breadcrumb-item>
                    <el-breadcrumb-item>活动管理</el-breadcrumb-item>
                    <el-breadcrumb-item>活动列表</el-breadcrumb-item>
                    <el-breadcrumb-item>活动详情</el-breadcrumb-item>
                </el-breadcrumb>
                <div></div>
            </div>
            -->

            <el-scrollbar noscrollx>
                <el-main>
                    <router-view v-if="visible"></router-view>
                </el-main>
            </el-scrollbar>

        </el-container>
    </el-container>
</template>
<script>
    import screenfull from 'screenfull'

    export default {

        computed: {
            sideWidth() {
                return this.isCollapse ? this.width : '235px'
            }
        },

        data() {
            return {
                backgroundColor: '#33485c',
                isCollapse: false,
                height: '55px',
                lineHeight: '55px',
                visible: true,
                width: '55px',
                zIndex: 3
            }
        },
        methods: {
            collapse() {
                this.isCollapse = !this.isCollapse
            },
            command(cmd) {
                if (cmd === 'signout') {
                    this.$confirm('确定退出登录吗', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }).then(_ => {
                        localStorage.clear();
                        this.$router.push({ name: 'login' })
                    })
                }
            },
            refresh() {
                this.visible = false
                this.$nextTick(() => this.visible = true)
            },
            screenfull() {
                screenfull.toggle()
            }
        }
    }
</script>
<style lang="scss" scoped>
    .main {
        background: #f0f2f5;
        height: 100vh;

        .side {
            overflow: hidden;

            .info {
                align-items: center;
                color: white;
                display: flex;
                height: 80px;
                line-height: 1;
                padding: 0 20px;

                .avatar {
                    margin-right: 8px;
                }

                .name {
                    line-height: 1.3em;

                    i {
                        font-size: 13px;
                    }
                }
            }

            .mark {
                color: white;

                .logo {
                    font-size: 30px;
                    text-align: center;
                }

                .titl {
                }
            }
        }

        .bred {
            align-items: center;
            background: white;
            display: flex;
            justify-content: space-between;
            padding: 0 20px;
        }
    }
</style>
