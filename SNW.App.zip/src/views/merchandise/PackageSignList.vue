<template>
    <el-card>
      <div slot="header" class="clearfix">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
          <el-breadcrumb-item>包裹签收列表</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="user">
        <el-row>
          <el-row class="tool-bar">
            <el-button class="btnScan" type="warning" icon="el-icon-view" @click="onHandleScanSupplementInfo()">扫描补充资料</el-button>
          </el-row>
          <el-row class="tool-bar">
            <el-select v-model="selectedVipParams" placeholder="选择客户">
              <el-option
                v-for="item in filterParams.vipParams"
                :key="item.key"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-row>
          <el-row class="tool-bar">
            <el-input v-model="batch" placeholder="请输入批次" clearable/>
          </el-row>
          <el-row class="tool-bar">
            <el-input v-model="keyword" placeholder="请输入面单号" clearable/>
          </el-row>
          <el-row class="tool-bar">
            <el-select v-model="selectedStatus" placeholder="选择状态">
              <el-option
                v-for="item in filterParams.Status"
                :key="item.key"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
            &nbsp
            <el-button class="btnSearch" type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>
        </el-row>
      </el-row>
      <el-row style="margin-top:10px">
          <el-col>
              <el-table border ref="multipleTable" tooltip-effect="dark"
                  @selection-change="handleSelectionChange" style="width: 100%"
                  :data="dataTable" :row-class-name="tableRowClassName">
                  <el-table-column type="selection"width="50"/>
                  <el-table-column prop="batch" label="批次" width="180"/>
                  <el-table-column prop="client" label="客户"/>
                  <el-table-column prop="orderNo" label="面单号"/>
                  <el-table-column prop="receiveTime" label="签收时间"/>
                  <el-table-column prop="status" label="状态">
                    <template slot-scope="scope">
                      <el-tag type="success" v-if="scope.row.status == 0">已签收</el-tag>
                      <el-tag type="danger" v-if="scope.row.status == 1">已开单</el-tag>
                    </template>
                  </el-table-column>
                  <el-table-column
                   fixed="right"
                   label="操作"
                   width='auto'>
                   <template slot-scope="scope">
                     <el-row>
                      <el-button type="success" @click="handleOpenOrder(scope.row)">开单</el-button>
                      <el-button type="primary" @click="editHandle(scope.row)">编辑</el-button>
                      <el-button type="warning" icon="el-icon-delete" @click="delHandle(scope.row)">删除</el-button>
                    </el-row>
                   </template>
                 </el-table-column>
              </el-table>
              <div style="width:100%;inline-flex;margin-top:15px">
                <el-button type="danger" icon="el-icon-delete" @click="batchDelete()">批量删除</el-button>
                <div style="float:right">
                  <el-pagination background layout="prev, pager,next,total,jumper"
                   :total="pagination.totalCount" :page-count="pagination.totalPage"
                   :current-page="pagination.pageNo"
                   @current-change="pageNoChange"/>
                </div>
              </div>
          </el-col>
      </el-row>
      <el-dialog title="修改" width="380px"
                 :close-on-click-modal="false"
                 :visible.sync="updateDialog.visible">
          <el-form :model="updateDialog.formModel"
                   :rules="updateDialog.formRules"
                   ref="updatePermissionRef"
                   label-width="79px">
              <el-form-item label="客户" prop="selectedVipParams">
                  <el-select v-model="updateDialog.formModel.selectedVipParams" class="fw">
                      <el-option v-for="item in updateDialog.formModel.vipParams"
                                 :label="item.label"
                                 :value="item.value"
                                 :key="item.key">
                      </el-option>
                  </el-select>
              </el-form-item>
              <el-form-item label="面单号" prop="orderNumber" required>
                  <el-input v-model="updateDialog.formModel.orderNumber"></el-input>
              </el-form-item>
              <el-form-item label="状态" prop="selectedStatus">
                  <el-select v-model="updateDialog.formModel.selectedStatus" class="fw">
                      <el-option v-for="item in updateDialog.formModel.status"
                                 :label="item.name"
                                 :value="item.id"
                                 :key="item.id">
                      </el-option>
                  </el-select>
              </el-form-item>
              <el-form-item>
                  <el-button icon="el-icon-circle-check"
                             type="primary"
                             :loading="updateDialog.saveLoading"
                             @click="updateDialogSave()">保存</el-button>
              </el-form-item>
          </el-form>
      </el-dialog>
      <el-dialog title="签收快递，扫描开单" width="500px"
                 :close-on-click-modal="false"
                 :visible.sync="ScanDialog.Visible">
          <el-form :model="ScanDialog.FormModel"
                   :rules="ScanDialog.FormRules"
                   ref="ScanDialogRef"
                   label-width="79px">
              <el-form-item label="包裹信息" prop="InputData" required>
                  <el-input v-model="ScanDialog.FormModel.InputData"
                    @input="ScanOpenOrderSave"
                    placeholder="包裹信息，格式：快递号,重量,长|宽|高"/>
              </el-form-item>
              <el-form-item>
                <el-button @click="ScanOpenOrderReset()">重置</el-button>
                <el-button type="primary" :loading="ScanDialog.SaveLoading" @click="ScanOpenOrderSave()">保存</el-button>
              </el-form-item>
          </el-form>
      </el-dialog>
    </div>
    </el-card>
</template>

<script>
import { get_package_signing_filter_params,get_package_signing_list,
  package_signing_list_item_edit,package_signing_list_item_del } from '@/api/services/merchandiseService'
import { ScanOpenOrder } from '@/api/services/packageSignService'
import { playAudio } from '@/utils/audio_util'

export default {
  name: 'PackageSignList',
  data() {
      return {
          dataTable:[],
          multipleSelection: [],
          pagination:{
            pageNo:1,       // 当前页
            pageSize:8,     // 当前页数量
            totalPage:2,    // 总页数
            totalCount:10,   // 总条数
          },
          filterParams:{
            vipParams:[],             // 会员
            Status:[
              {
                value: '-1',
                label: '全部'
              },
              {
                value: '0',
                label: '已签收'
              },
              {
                value: '1',
                label: '已开单'
              },
            ]
          },
          selectedVipParams:'',
          selectedRoutes:'',
          selectedStatus:'',
          keyword:'',
          batch:'',
          ScanDialog:{
            Visible:false,
            SaveLoading:false,
            FormModel:{
              InputData:''
            },
            FormRules:{
              InputData:{ required: true, message: '请输入包裹信息', trigger:['change','blur'] },
            }
          },
          updateDialog:{
            visible:false,
            formModel:{
              id:-1,
              status:[
                {
                  id: -1,
                  name: '全部'
                },
                {
                  name:'已签收',
                  id:0
                },
                {
                  name:'已入库',
                  id:1
                }
              ],
              vipParams:[],
              orderNumber:'',
              selectedVipParams:'',
              selectedStatus:-1,
            }
          }
      }
  },
  created(){
    this.getTableDataFilterParams()
    this.getTableData()
  },
  methods:{
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    async getTableDataFilterParams(){
      get_package_signing_filter_params().then(res => {
        this.filterParams.vipParams.push({
          key:-1,
          value:-1,
          label:'选择客户',
        })
        for(var i = 0;i < res.data.clients.length;i++){
          var item = res.data.clients[i]
          this.filterParams.vipParams.push({
            key:item.id,
            value:item.id,
            label:item.name
          })
        }
      })
    },
    onHandleScanSupplementInfo(){
      this.ScanDialog.Visible = true
    },
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    ScanOpenOrderReset(){
      this.$refs['ScanDialogRef'].resetFields()
    },
    ScanOpenOrderSave(){
      this.$refs['ScanDialogRef'].validate((valid) => {
        if(!valid){
          console.log('error submit!!');
          return false;
        }
        const params = {
          InputData:this.ScanDialog.FormModel.InputData,
        }
        ScanOpenOrder(params).then(res => {
          if(res.data.code != 200){
            this.$message.error(res.data.message)
            playAudio('audios/5051.wav')
            return
          }
          playAudio('audios/1431-0713广告女070-4.mp3')
          this.$message.success(res.data.message)
          this.ScanDialog.Visible = false
          this.getTableData()
        })
      })
    },
    async getTableData(){
      var params = {
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
        ClientId:this.selectedVipParams,
        Keyword:this.keyword,
        Batch:this.batch,
        OrderNo:this.keyword,
        Status:this.selectedStatus
      }
      if(params['ClientId'] == ''){
        delete params['ClientId']
      }
      if(params['Status'] == '' || params['Status'] == -1){
        delete params['Status']
      }
      if(params['OrderNo'] == ''){
        delete params['OrderNo']
      }
      if(params['Batch'] == ''){
        delete params['Batch']
      }
      if(params['Keyword'] == ''){
        delete params['Keyword']
      }
      get_package_signing_list(params).then(res => {
        this.dataTable = res.data.collection
        this.pagination.pageNo = res.data.pageNo
        this.pagination.pageSize = res.data.pageSize
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    handleSelectionChange(val) {
        this.multipleSelection = val;
    },
    batchDelete(){
      console.log(`multipleSelection: ${JSON.stringify(this.multipleSelection)}`)
      this.openConfirm('此操作将永久删除, 是否继续?',() => {
        var arr = []
        this.multipleSelection.forEach((item, i) => {
          arr.push(item.id)
        });
        package_signing_list_item_del(arr).then((res) => {
          this.$message({
            type:res.data.code == 200 ? 'success' : 'error',
            message:res.data.message
          });
          this.getTableData()
        })
      })
    },
    handleOpenOrder({orderNo}){
      this.$router.push({path:'/PackageSignListItemOpenOrder',query:{orderNo:orderNo}})
    },
    editHandle({orderNo,status,id,client}){
      this.updateDialog.formModel.selectedStatus = status
      this.updateDialog.formModel.vipParams = this.filterParams.vipParams
      this.updateDialog.formModel.orderNumber = orderNo
      this.updateDialog.formModel.id = id
      var ele = this.filterParams.vipParams.find(x => x.label == client)
      if(ele != null){
        this.updateDialog.formModel.selectedVipParams = ele.value
      }
      this.updateDialog.visible = true
    },
    delHandle({id}){
      this.openConfirm('此操作将永久删除, 是否继续?',() => {
        var arr = []
        arr.push(id)
        package_signing_list_item_del(arr).then((res) => {
          this.$message({
            type:res.data.code == 200 ? 'success' : 'error',
            message:res.data.message
          });
          this.getTableData()
        })
      })
    },
    updateDialogSave(){
      this.updateDialog.visible = false
      var id = this.updateDialog.formModel.id
      var status = this.updateDialog.formModel.selectedStatus
      var orderNumber = this.updateDialog.formModel.orderNumber
      var ClientId = this.updateDialog.formModel.selectedVipParams
      console.log(`status: ${status},orderNumber: ${orderNumber},ClientId: ${ClientId},id: ${id}`)
      package_signing_list_item_edit({
        id:id,
        userId:ClientId,
        orderNumber:orderNumber,
        status:status,
      }).then(res => {
        this.$message({
          message:res.data.message,
          type: 'success'
        });
        this.getTableData()
      })
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    }
  }
}
</script>
<style scoped>
.tool-bar{
  margin-right:5px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
</style>
