<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>开单列表</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user">
      <el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedOpenOrderPeoples" placeholder="开单人选择">
            <el-option
              v-for="item in filterParams.openOrderPeoples"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedVipParams" placeholder="选择会员">
            <el-option
              v-for="item in filterParams.vipParams"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedRoutes" placeholder="选择航线">
            <el-option
              v-for="item in filterParams.routes"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-input v-model="toSearchExpressNumber" placeholder="请输入运输单号" clearable/>&nbsp
          <el-button class="btnSearch" type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>
        </el-row>
      </el-row>
        <el-row style="margin-top:10px">
            <el-col>
                <el-table border ref="multipleTable" tooltip-effect="dark"
                    @selection-change="handleSelectionChange" style="width: 100%"
                    :data="dataTable" :row-class-name="tableRowClassName">
                    <el-table-column type="selection" width="55"/>
                    <el-table-column align="center" type="index" width="56">
                        <template slot="header" slot-scope="scope">
                            <i class="el-icon-s-operation" style="font-size:16px"></i>
                        </template>
                    </el-table-column>
                    <el-table-column prop="expressNumber" label="运输单号" width="180"/>
                    <el-table-column prop="mark" label="唛头" width="180"/>
                    <el-table-column prop="userDisplay" label="会员编号"/>
                    <el-table-column prop="itemCount" label="件数"/>
                    <el-table-column prop="weight" label="重量">
                      <template slot-scope="scope">
                        <span v-if="scope.weight == null || scope.weight < 1" style="font-weight:bold;color:red">XX</span>
                        <span v-else-if="scope.weight != null && scope.weight > 0">{{scope.row.weight}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="regionDisplay" label="地区"/>
                    <el-table-column prop="volume" label="S/体积">
                      <template slot-scope="scope">
                        <span v-if="scope.volume == null || scope.volume < 1" style="font-weight:bold;color:red">XX</span>
                        <span v-else-if="scope.volume != null && scope.volume > 0">{{scope.row.volume}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="itemName" label="品名"/>
                    <el-table-column prop="creatorDisplay" label="开单人"/>
                    <el-table-column prop="isFast" label="是否快速">
                      <template slot-scope="scope">
                        <el-tag type="primary" v-if="scope.row.temporaryLibrary == 1">是</el-tag>
                        <el-tag type="danger" v-else-if="scope.row.temporaryLibrary != 1">否</el-tag>
                      </template>
                    </el-table-column>
                </el-table>
                <div style="width:100%;display:inline-flex;margin-top:15px">
                  <div style="float:left;display:inline-flex;width:100%">
                    <el-button @click="batchDelete()">批量删除</el-button>
                    <el-button @click="onHandleBatchToFast()">批量到快速</el-button>
                    <el-button @click="onHandleBatchToStorage()">批量到库存</el-button>
                  </div>
                  <div style="float:right;">
                    <el-pagination background layout="prev, pager,next,total,jumper"
                     :total="pagination.totalCount" :page-count="pagination.totalPage"
                     :current-page="pagination.pageNo" @current-change="pageNoChange"/>
                  </div>
                </div>
            </el-col>
        </el-row>
    </div>
  </el-card>
</template>

<script>
import { get_open_order_list,get_open_order_filter_list_list,
OpenOrderItemDelete } from '@/api/services/merchandiseService'
import { GetUsers,GetRoutes,GetRegionList,
  GetDeliveryRegionDropdownList,GetAdmins
 } from '@/api/services/packageLookupService'
import { BatchUpdate } from '@/api/services/openOrderService'

export default {
  name:'OpenOrderList',
  data(){
      return {
          dataTable:[],
          multipleSelection: [],
          pagination:{
            pageNo:1,       // 当前页
            pageSize:8,     // 当前页数量
            totalPage:1,    // 总页数
            totalCount:1,   // 总条数
          },
          filterParams:{
            openOrderPeoples:[],      // 开单人
            vipParams:[],             // 会员
            routes:[],                // 航线
          },
          selectedVipParams:'',
          selectedRoutes:'',
          selectedOpenOrderPeoples:'',
          toSearchExpressNumber:'',
      }
  },
  created(){
    GetAdmins().then(res => {
      this.filterParams.openOrderPeoples = []
      this.filterParams.openOrderPeoples.push({
        key:-1,
        value:-1,
        label:'选择开单人'
      })
      res.data.forEach((item, i) => {
        this.filterParams.openOrderPeoples.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetUsers().then(res => {
      this.filterParams.vipParams = []
      this.filterParams.vipParams.push({
        key:-1,
        value:-1,
        label:'选择会员'
      })
      res.data.forEach((item, i) => {
        this.filterParams.vipParams.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRoutes().then(res => {
      this.filterParams.routes = []
      this.filterParams.routes.push({
        key:-1,
        value:-1,
        label:'选择航线'
      })
      res.data.forEach((item, i) => {
        this.filterParams.routes.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    this.getTableData()
  },
  methods:{
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    tableRowClassName({row, rowIndex}) {
      if (row.status === 0) {
        return 'status0';
      } else if (row.status === 1) {
        return 'status1';
      }else if (row.status === 2) {
        return 'status2';
      }else if (row.status === 3) {
        return 'status3';
      }else if (row.status === 4) {
        return 'status4';
      }else if (row.status === 5) {
        return 'status5';
      }
      return '';
    },
    async getTableDataFilterParams(){
      get_open_order_filter_list_list().then(res => {
        this.filterParams.openOrderPeoples = res.data.openOrderPeoples
      })
    },
    async getTableData(){
      console.log('selectedOpenOrderPeoples: ' + this.selectedOpenOrderPeoples)
      var params = {
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
        AdminId:this.selectedOpenOrderPeoples.toString().length > 0 ? this.selectedOpenOrderPeoples : -1,
        UserId:this.selectedVipParams.toString().length > 0 ? this.selectedVipParams : -1,
        RouteId:this.selectedRoutes.toString().length > 0 ? this.selectedRoutes : -1,
        Keyword:this.toSearchExpressNumber.toString().length > 0 ? this.toSearchExpressNumber : ""
      }
      if(params.CreateAdmin == -1){
        delete params['CreateAdmin']
      }
      if(params.ExpressId == -1){
        delete params['ExpressId']
      }
      if(params.RouteId == -1){
        delete params['RouteId']
      }
      if(params.Keyword == ''){
        delete params['Keyword']
      }
      get_open_order_list(params).then(res => {
        this.dataTable = res.data.collection
        this.pagination.pageNo = res.data.pageNo
        this.pagination.pageSize = res.data.pageSize
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    handleSelectionChange(val) {
        this.multipleSelection = val;
    },
    batchDelete(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请选择欲操作列表项!')
        return
      }
      this.openConfirm('此操作将永久删除该文件, 是否继续?',() => {
        OpenOrderItemDelete(ids).then(res => {
          this.$message({
            type:res.data.code == 200 ? 'success' : 'error',
            message:res.data.message
          });
          this.getTableData()
        })
      })
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    },
    onHandleBatchToFast(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请选择欲操作列表项!')
        return
      }
      BatchUpdate({
        Ids:ids.join(','),
        Value:1
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
      })
    },
    onHandleBatchToStorage(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请选择欲操作列表项!')
        return
      }
      BatchUpdate({
        Ids:ids.join(','),
        Value:0
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
      })
    }
  }
}
</script>
<style>
.tool-bar{
  margin-right:5px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
.btnSearch{
  margin-left:10px;
}
.el-table .status0 {
  background:#fff;
}
.el-table .status1 {
  background:#99CDFF;
}
.el-table .status2 {
  background:#FFFF00;
}
.el-table .status3 {
  background:#C2C2C2;
}
.el-table .status4 {
  background:#66FFCC;
}
.el-table .status5 {
  background:#FFCCFF;
}
</style>
