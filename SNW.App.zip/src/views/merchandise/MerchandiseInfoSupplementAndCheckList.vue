<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-信息补充及检测</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user">
      <el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedMerchandiseType" placeholder="选择货物类型">
            <el-option v-for="item in toShowMerchandiseTypeList"
             :key='item.key' :label='item.label' :value='item.value'/>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedSupplementType" placeholder="选择资料">
            <el-option v-for="item in toShowSupplementList"
             :key='item.key' :label='item.label' :value='item.value'/>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedShipNo" placeholder="选择船次">
            <el-option
              v-for="item in toShowShipNoList"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedUserId" placeholder="选择会员">
            <el-option
              v-for="item in toShowUserList"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedRouteId" placeholder="选择航线">
            <el-option
              v-for="item in toShowRouteList"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-input v-model="ExpressNo" placeholder="请输入运输单号" clearable/>
        </el-row>
        <el-row class="tool-bar">
          <el-input v-model="Mark" placeholder="请输入唛头" style="margin-right:15px;" clearable/>
          <el-button class="btnSearch" type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>
          <el-button-group style="display: inline-flex;margin-left:20px;">
            <el-button type='warning' icon="el-icon-question" @click="onClickImportRule()">Excel导入规则</el-button>&nbsp
            <el-button type='primary' icon="el-icon-s-open" @click="onClickUpload()">导入覆盖地址</el-button>
          </el-button-group>
        </el-row>
      </el-row>
      <el-row style="margin-top:10px">
        <el-col>
          <el-table border ref="multipleTable" tooltip-effect="dark"
              @selection-change="handleSelectionChange" style="width: 100%"
              :data="dataTable" :row-class-name="tableRowClassName"
              :cell-style="columnbackgroundStyle">
              <el-table-column type="selection"width="50"/>
              <el-table-column prop="expressNumber" label="运输单号" width="180"/>
              <el-table-column prop="mark" label="唛头" width="180"/>
              <el-table-column prop="userDisplay" label="会员"/>
              <el-table-column prop="containerNumber" label="柜号"/>
              <el-table-column prop="itemType" label="类型"/>
              <el-table-column prop="itemName" label="品名"/>
              <el-table-column prop="volume" label="S/体积">
                <template slot-scope="scope">
                  <span v-if="scope.row.volume == null || scope.row.volume < 1" style="font-weight:bold;color:red">XX</span>
                  <span v-else-if="scope.row.volume > 0">{{scope.row.volume}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="itemCount" label="件数"/>
              <el-table-column prop="receivedFreight" label="代收"/>
              <el-table-column prop="routeName" label="线路"/>
              <el-table-column prop="deliveryAddress" label="派送地区" width='100':show-overflow-tooltip='true'/>
              <el-table-column prop="address" label="地址" max-width='auto':show-overflow-tooltip='true'/>
              <el-table-column prop="recipientName" label="收件人"/>
              <el-table-column prop="recipientPhoneNo" label="手机"/>
              <el-table-column prop="companyName" label="公司"/>
              <el-table-column
               fixed="right"
               label="操作"
               width='auto'>
               <template slot-scope="scope">
                 <el-row>
                  <el-button type="primary" icon="el-icon-edit" @click="editHandle(scope.row)">编辑</el-button>
                </el-row>
               </template>
             </el-table-column>
          </el-table>
          <div style="margin-top:20px;display:inline-flex;width:100%">
            <div style="width:100%;">
              <el-button type="warning" icon="el-icon-delete" @click="onSupplementInfo()">资料补充完整</el-button>
            </div>
            <div style="float:right">
              <el-pagination background layout="prev,pager,next,total,jumper"
               :total="pagination.totalCount" :page-count="pagination.totalPage"
               :current-page="pagination.pageNo" @current-change="pageNoChange"/>
            </div>
          </div>
        </el-col>
      </el-row>
      <el-dialog
        title="Excel导入对应字段"
        :visible.sync="dialogRuleVisible"
        width="20%" class="dialog-rule" >
        <div style="background-color:#393D49;color:white;padding:15px;">
          <span>
            EXCEL 工作表名称为 Sheet1 或者 sheet1</br>
            A 对应的是 运单号</br>
            B 对应的是 地址</br>
            C 对应的是 收件人</br>
            D 对应的是 手机
          </span>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="dialogRuleVisible = false">确 定</el-button>
        </span>
      </el-dialog>
      <el-dialog
        title="导入数据"
        :visible.sync="dialogUploadVisible"
        width="400px" class="dialog-upload" >
        <el-upload
          :headers="uploadHeaders"
          name="files"
          :show-file-list="true"
          :limit="10" multiple
          accept=".xlsx,.xls,.xlsm"
          :on-success="handleUploadSeccess"
          :on-error="handleUploadError"
          :on-exceed="handleExceed" drag
          :action="BatchImportLink">
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip" slot="tip">只允许上传xlsx/xls/xlsm文件，且不超过10MB</div>
        </el-upload>
      </el-dialog>
    </div>
  </el-card>
</template>
<script>
import { GetUsers,GetRoutes,GetShipNos } from '@/api/services/packageLookupService'
import { GetInfoSupplementAndCheckList,SupplementInformation } from '@/api/services/merchandiseService'
export default {
  name: 'MerchandiseInfoSupplementAndCheckList',
  data() {
      return {
        BatchImportLink:process.env.BASE_URL + '/api/PackageInfoSupplement/ImportFromExcel',
          uploadHeaders:{
            Authorization : 'Bearer' + ' ' + localStorage.getItem('TOKEN'),
          },
          dataTable:[],
          multipleSelection: [],
          pagination:{
            pageNo:1,       // 当前页
            pageSize:8,     // 当前页数量
            totalPage:2,    // 总页数
            totalCount:10,   // 总条数
          },
          selectedMerchandiseType:-1,
          toShowMerchandiseTypeList:[
            {
              key:-1,
              value:-1,
              label:'选择类型'
            },
            {
              key:0,
              value:0,
              label:'TT'
            },
            {
              key:1,
              value:1,
              label:'JJ'
            },
            {
              key:2,
              value:2,
              label:'A'
            },
            {
              key:3,
              value:3,
              label:'B'
            },
            {
              key:4,
              value:4,
              label:'C'
            },
            {
              key:5,
              value:5,
              label:'F'
            },
            {
              key:6,
              value:6,
              label:'M'
            },
            {
              key:7,
              value:7,
              label:'MT'
            },
          ],
          selectedSupplementType:0,
          toShowSupplementList:[
            {
              key:0,
              value:0,
              label:'所有订单'
            },
            {
              key:1,
              value:1,
              label:'已补充资料'
            },
            {
              key:2,
              value:2,
              label:'未补充资料'
            },
          ],
          selectedShipNo:-1,
          selectedRouteId:-1,
          toShowShipNoList:[
            {
              key:-1,
              value:-1,
              label:'选择船次'
            },
          ],
          toShowRouteList:[
            {
              key:-1,
              value:-1,
              label:'选择航线'
            },
          ],
          selectedUserId:-1,
          toShowUserList:[
            {
              key:-1,
              value:-1,
              label:'选择会员'
            },
          ],
          ExpressNo:'',
          Mark:'',
          dialogRuleVisible:false,
          dialogUploadVisible:false
      }
  },
  created(){
    GetUsers().then(res => {
      res.data.forEach((item, i) => {
        this.toShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRoutes().then(res => {
      res.data.forEach((item, i) => {
        this.toShowRouteList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetShipNos().then(res => {
      res.data.forEach((item, i) => {
        this.toShowShipNoList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    this.getTableData()
  },
  methods:{
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    tableRowClassName({row, rowIndex}) {
      return 'statusX';
    },
    columnbackgroundStyle({ row, column, rowIndex, columnIndex }) {
      if(columnIndex == 1){
        if(row.expressNumber != null && row.expressNumber.startsWith('M')) {
          return 'color:red;font-weight:bold;'
        }
      }
      if(columnIndex == 13){
        if(row.recipientName == '' || row.recipientName == null) {
          return 'background:#C2C2C2;'
        }
      }
      if(columnIndex == 14){
        if(row.recipientPhoneNo == '' || row.recipientPhoneNo == null) {
          return 'background:#C2C2C2;'
        }
      }
      if(columnIndex == 15){
        if(row.companyName == '' || row.companyName == null) {
          return 'background:#C2C2C2;'
        }
      }
    },
    async getTableData(){
      var params = {
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
        ItemType:this.selectedMerchandiseType,
        SupplementInfo:this.selectedSupplementType,
        BoxNumber:this.selectedShipNo,
        UserId:this.selectedUserId,
        RouteId:this.selectedRouteId,
        ExpressNo:this.ExpressNo,
        Mark:this.Mark,
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['SupplementInfo'] == 0){
        delete params['SupplementInfo']
      }
      if(params['BoxNumber'] == -1){
        delete params['BoxNumber']
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      GetInfoSupplementAndCheckList(params).then(res => {
        this.dataTable = res.data.collection
        this.pagination.pageNo = res.data.pageNo
        this.pagination.pageSize = res.data.pageSize
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    handleSelectionChange(val) {
        this.multipleSelection = val;
    },
    // 资料补充完整
    onSupplementInfo(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择要补充资料的列表项!')
        return
      }
      this.openConfirm('资料补充完整?',() => {
        SupplementInformation(ids).then(res => {
          console.log(`SupplementInformation res: ${JSON.stringify(res)}`)
          if(res.data.code != 200){
            this.$message.error({type:"error",message:res.data.message})
            return
          }
          this.getTableData()
          this.$message.success({type:"success",message:res.data.message})
        })
      })
    },
    // 文件选择回调
    handleExceed(files, fileList) {
        this.$message.warning(`当前限制选择 10 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
    },
    // 文件上传成功回调
    handleUploadSeccess(response, file, fileList){
      console.log(`response: ${JSON.stringify(response)},file:${file},fileList:${fileList}`)
      if(response.code == 200){
        this.dialogUploadVisible = false
        this.$message({type:'success',message:'导入成功!'})
        this.getTableData()
      }else{
        this.$message({type:'error',message:response.message})
      }
    },
    handleUploadError(err, file, fileList){
      console.log(`err：${err},file:${file},fileList:${fileList}`)
      this.$message({type:'error',message:`上传失败:\n${err}`})
    },
    editHandle({id}){
      this.$router.push('/MerchandiseInfoSupplementAndCheckEdit?id=' + id)
    },
    onClickImportRule(){
      this.dialogRuleVisible = true
    },
    onClickUpload(){
      this.dialogUploadVisible = true
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    }
  }
}
</script>
<style scoped>
.tool-bar{
  margin-right:5px;
  margin-top:15px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
.el-table .statusX {
  background:#FFF;
}
</style>
