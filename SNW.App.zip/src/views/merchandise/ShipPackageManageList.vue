<template>
  <el-card style="padding-bottom:20px">
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item :to="{path:'/MerchandiseShipCreate'}">船次建立</el-breadcrumb-item>
        <el-breadcrumb-item>包裹管理</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
      <div class="create-ship-control-group" style="display:inline-flex;align-items: baseline;">
        <span style="font-size:20px;color:black">柜号：CS-5997</span>
        <div style="margin-left:20px;display:inline-flex">
          <div style="font-size:20px;color:red">
            柜体积:
            <el-tag type="danger" style="font-size:20px;color:red">0 m³</el-tag>
          </div>
          <div style="margin-left:20px;color:red;font-size:20px;">
            柜重量:
            <el-tag type="danger" style="font-size:20px;color:red">0 KG</el-tag>
          </div>
        </div>
      </div>
      <div class="create-ship-control-group" style="margin-top:10px">
        <el-button type='danger' icon="el-icon-back" @click="onHandleBack">上一步</el-button>
        <el-button type="primary" icon="el-icon-news" @click="onHandleShowImportFromNew">从新库中选择</el-button>
        <el-button type="primary" icon="el-icon-news" @click="onHandleShowImportFromStorage">导入库存</el-button>
        <el-select v-model="selectedUserId" placeholder="选择会员">
          <el-option
            v-for="item in toShowUserList"
            :key="item.key"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="selectedMerchandiseType" placeholder="货物类型">
          <el-option v-for="item in toShowMerchandiseTypeList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
        <el-button type="primary" icon="el-icon-search" @click="onHandleSearch">查询</el-button>
      </div>
      <el-table border ref="multipleTable" tooltip-effect="dark"
          @selection-change="handleSelectionChange" style="width:100%;margin-top:8px"
          :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column type="selection" width="50"/>
          <el-table-column prop="itemType" label="类型" width="auto">
            <template slot-scope="scope">
              <el-row>
                <span>{{getItemTypeDisplayText(scope.row)}}</span>
              </el-row>
            </template>
          </el-table-column>
          <el-table-column prop="expressNumber" label="运单号" width="160"/>
          <el-table-column prop="mark" label="唛头"/>
          <el-table-column prop="userDisplay" label="会员编号"/>
          <el-table-column prop="itemName" label="品名" width="auto" :show-overflow-tooltip='true'/>
          <el-table-column prop="-" label="地区"/>
          <el-table-column prop="itemCount" label="件数"/>
          <el-table-column prop="weight" label="重量"/>
          <el-table-column prop="volumeWeight" label="S/体积"/>
          <el-table-column prop="packingType" label="包装类型"/>
          <el-table-column prop="-" label="订单检测"/>
          <el-table-column prop="sort" label="排序"/>
          <el-table-column prop="regionDisplay" label="位置"/>
      </el-table>
      <el-pagination background layout="prev, pager,next,total,jumper"
       style="margin-top:10px"
       :total="pagination.totalCount" :page-count="pagination.totalPage"
       :current-page="pagination.pageNo" @current-change="pageNoChange"/>
       <div class="bottom-left-button-group" style="margin-top:10px">
        <el-button type="primary" @click="onHandleSplitBill">分票</el-button>
        <el-button type="primary" @click="onHandleMoveToStorage">移到库存</el-button>
       </div>
       <el-dialog title="分票" :visible.sync="SplitBillDialog.Visible"
          width="auto">
          <div class="dialog-body" style="display: inline-grid;">
            <span>原始单号：{{this.SplitBillDialog.Form.expressNo}}</span>
            <span style="margin-top:15px;">总件数：{{this.SplitBillDialog.Form.totalPackageCount}}</span>
            <span style="margin-top:15px;">未检测件数: {{this.SplitBillDialog.Form.unpackPackageCount}}</span>
            <div style="display:inline-flex;margin-top:15px;align-items: baseline;">
              <span style="white-space:nowrap">剩余件数：</span>
              <el-input style="margin-left:10px" v-model="SplitBillDialog.Form.LeftCount"/>
              <el-button type="primary" icon="el-icon-sugar" style="margin-left:5px" @click="onHandleSplitBillSubmit">提交</el-button>
            </div>
          </div>
       </el-dialog>
       <el-dialog title="从新库导入" :visible.sync="ImportFromNewStorage.Visible"
          width="auto">
          <div class="dialog-body" style="display: inline-grid;">
            <div style="color:red;font-size:x-large;font-family: Verdana, Geneva, sans-serif;">
              <span style="margin-left:30%;white-space:nowrap;">
                计划装柜体积: 0
              </span>
              <span style="white-space:nowrap;margin-left:30px">
                计划装柜重量: 0
              </span>
            </div>
            <div style="display:inline-flex;margin-top:20px;white-space:nowrap;">
              <el-select v-model="ImportFromNewStorage.selectedUserId" placeholder="选择会员" style="width:150px">
                <el-option
                  v-for="item in toShowUserList"
                  :key="item.key"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              <el-input placeholder="位置" v-model="ImportFromNewStorage.Location" style="width:150px;margin-left:10px" clearable/>
              <el-input placeholder="唛头" v-model="ImportFromNewStorage.Mark" style="width:150px;margin-left:10px" clearable/>
              <el-select v-model="ImportFromNewStorage.selectedRegionId" placeholder="选择地区" style="width:150px;margin-left:10px">
                <el-option
                  v-for="item in toShowRegionList"
                  :key="item.key"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              <div style="width:150px;margin-left:10px">
                <el-date-picker
                   v-model="ImportFromNewStorage.StartTime"
                   placement="bottom-start"
                   type="date"
                   placeholder="开始时间">
                </el-date-picker>
              </div>
              <div style="width:150px;margin-left:10px">
                <el-date-picker
                   style="width:150px"
                   v-model="ImportFromNewStorage.EndTime"
                   placement="bottom-start"
                   type="date"
                   placeholder="结束时间">
                </el-date-picker>
              </div>
              <el-select v-model="ImportFromNewStorage.selectedMerchandiseType" placeholder="货物类型" style="width:150px;margin-left:10px">
                <el-option v-for="item in toShowMerchandiseTypeList"
                 :key='item.key' :label='item.label' :value='item.value'/>
              </el-select>
              <el-button type="primary" icon="el-icon-search" style="margin-left:10px;width:80px" @click="onHandleImportFromNewStorageSearch">查询</el-button>
            </div>
            <div style="margin-top:10px">
              <el-table border ref="multipleTable" tooltip-effect="dark"
                  @selection-change="onHandleImportFromNewStorageSelectionChange" style="width: 100%"
                  :data="ImportFromNewStorage.dataTable" :row-class-name="tableRowClassName">
                  <el-table-column type="selection"width="50"/>
                  <el-table-column prop="expressNumber" label="流水号" width="150"/>
                  <el-table-column prop="mark" label="唛头"/>
                  <el-table-column prop="collection" label="会员编号"/>
                  <el-table-column prop="weight" label="重量"/>
                  <el-table-column prop="volume" label="体积"/>
                  <el-table-column prop="itemName" label="品名" width="200" :show-overflow-tooltip='true'/>
                  <el-table-column prop="itemCount" label="件数"/>
                  <el-table-column prop="weight" label="重量"/>
                  <el-table-column prop="regionDisplay" label="地区"/>
                  <el-table-column prop="itemType" label="类型">
                    <template slot-scope="scope">
                      <el-row>
                        <span>{{getItemTypeDisplayText(scope.row)}}</span>
                      </el-row>
                    </template>
                  </el-table-column>
                  <el-table-column prop="packingType" label="位置"/>
              </el-table>
              <div style="margin-top:5px">
                <el-button type="primary" icon="el-icon-share" @click="onHandleImportFromNewStorageBatchJoin">批量加入</el-button>
              </div>
            </div>
          </div>
       </el-dialog>
       <el-dialog title="导入库存" :visible.sync="ImportFromStorage.Visible"
          width="auto">
          <div class="dialog-body" style="display: inline-grid;">
            <div style="color:red;font-size:x-large;font-family: Verdana, Geneva, sans-serif;">
              <span style="margin-left:30%;white-space:nowrap;">
                计划装柜体积: 0
              </span>
              <span style="white-space:nowrap;margin-left:30px">
                计划装柜重量: 0
              </span>
            </div>
            <div style="display:inline-flex;margin-top:20px;white-space:nowrap;">
              <el-select v-model="ImportFromStorage.selectedUserId" placeholder="选择会员" style="width:150px">
                <el-option
                  v-for="item in toShowUserList"
                  :key="item.key"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              <el-input placeholder="位置" v-model="ImportFromStorage.Location" style="width:150px;margin-left:10px" clearable/>
              <el-input placeholder="唛头" v-model='ImportFromStorage.Mark' style="width:150px;margin-left:10px" clearable/>
              <el-select v-model="ImportFromStorage.selectedRegionId" placeholder="选择地区" style="width:150px;margin-left:10px">
                <el-option
                  v-for="item in toShowRegionList"
                  :key="item.key"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              <div style="width:150px;margin-left:10px">
                <el-date-picker
                   v-model="ImportFromStorage.StartTime"
                   placement="bottom-start"
                   type="date"
                   placeholder="开始时间">
                </el-date-picker>
              </div>
              <div style="width:150px;margin-left:10px">
                <el-date-picker
                   style="width:150px"
                   v-model="ImportFromStorage.EndTime"
                   placement="bottom-start"
                   type="date"
                   placeholder="结束时间">
                </el-date-picker>
              </div>
              <el-select v-model="ImportFromStorage.selectedMerchandiseType" placeholder="货物类型" style="width:150px;margin-left:10px">
                <el-option v-for="item in toShowMerchandiseTypeList"
                 :key='item.key' :label='item.label' :value='item.value'/>
              </el-select>
              <el-button type="primary" icon="el-icon-search" style="margin-left:10px;width:80px" @click="onHandleImportFromStorageSearch">查询</el-button>
            </div>
            <div style="margin-top:10px">
              <el-table border ref="multipleTable" tooltip-effect="dark"
                  @selection-change="onHandleImportFromStorageSelectionChange" style="width: 100%"
                  :data="ImportFromStorage.dataTable" :row-class-name="tableRowClassName">
                  <el-table-column type="selection"width="50"/>
                  <el-table-column prop="expressNumber" label="流水号" width="150"/>
                  <el-table-column prop="mark" label="唛头"/>
                  <el-table-column prop="collection" label="会员编号"/>
                  <el-table-column prop="weight" label="重量"/>
                  <el-table-column prop="volume" label="体积"/>
                  <el-table-column prop="itemName" label="品名" width="200" :show-overflow-tooltip='true'/>
                  <el-table-column prop="itemCount" label="件数"/>
                  <el-table-column prop="weight" label="重量"/>
                  <el-table-column prop="regionDisplay" label="地区"/>
                  <el-table-column prop="itemType" label="类型">
                    <template slot-scope="scope">
                      <el-row>
                        <span>{{getItemTypeDisplayText(scope.row)}}</span>
                      </el-row>
                    </template>
                  </el-table-column>
                  <el-table-column prop="packingType" label="位置"/>
              </el-table>
              <div style="margin-top:5px">
                <el-button type="primary" icon="el-icon-share" @click="onHandleImportFromStorageBatchJoin">批量加入</el-button>
              </div>
            </div>
          </div>
       </el-dialog>
    </div>
  </el-card>
</template>
<script>
import { GetRegionList,GetUsers } from '@/api/services/packageLookupService'
import { GetPackageByShipId } from '@/api/services/merchandiseService'
import { GetPackageSplitBillData,PackageSplitBillSubmit,
  GetNewStorageListByShipNo,GetStorageListByShipNo,MoveToStorage,FromNewStorageSelectBatchJoin
} from '@/api/services/shipService'
export default{
  name:'ShipPackageManageList',
  data(){
    return{
      ShipId:'',
      tableData:[],
      multipleSelection:[],
      pagination:{
        pageNo:1,
        pageSize:8,
        totalPage:1,
        totalCount:1,
      },
      ShipId:-1,
      toShowRegionList:[],
      selectedUserId:-1,
      toShowUserList:[],
      selectedMerchandiseType:-1,
      toShowMerchandiseTypeList:[
        {
          key:-1,
          value:-1,
          label:'选择类型'
        },
        {
          key:0,
          value:0,
          label:'TT'
        },
        {
          key:1,
          value:1,
          label:'JJ'
        },
        {
          key:2,
          value:2,
          label:'A'
        },
        {
          key:3,
          value:3,
          label:'B'
        },
        {
          key:4,
          value:4,
          label:'C'
        },
        {
          key:5,
          value:5,
          label:'F'
        },
        {
          key:6,
          value:6,
          label:'M'
        },
        {
          key:7,
          value:7,
          label:'MT'
        },
        {
          key:8,
          value:8,
          label:'MF'
        }
      ],
      SplitBillDialog:{
        Visible:false,
        Form:{
          LeftCount:0,
          ExpressNo:''
        }
      },
      ImportFromNewStorage:{
        Visible:false,
        dataTable:[],
        PageNo:1,
        multipleSelection:[],
        selectedUserId:-1,
        selectedRegionId:-1,
        Location:'',
        Mark:'',
        StartTime:'',
        EndTime:''
      },
      ImportFromStorage:{
        Visible:false,
        dataTable:[],
        PageNo:1,
        multipleSelection:[],
        selectedUserId:-1,
        selectedRegionId:-1,
        Location:'',
        Mark:'',
        StartTime:'',
        EndTime:''
      }
    }
  },
  created(){
    this.ShipId = this.$route.query.ShipId
    this.getTableData()
    GetUsers().then(res => {
      this.toShowUserList = []
      this.toShowUserList.push({
        key:-1,
        value:-1,
        label:'选择会员',
      })
      res.data.forEach((item, i) => {
        this.toShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRegionList().then(res => {
      this.toShowRegionList = []
      this.toShowRegionList.push({
        key:-1,
        value:-1,
        label:'选择地区',
      })
      res.data.forEach((item, i) => {
        this.toShowRegionList.push({
          key:item.id,
          label:item.name,
          value:item.id
        })
      });

    })
  },
  methods:{
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    toggleSelection(rows){
      if(rows)
      {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      }
      else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    getTableData(){
      var params = {
        ShipId:this.ShipId,
        UserId:this.selectedUserId,
        ItemType:this.selectedMerchandiseType,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize
      }
      if(params.UserId == -1){
        delete params['UserId']
      }
      if(params.ItemType == -1){
        delete params['ItemType']
      }
      GetPackageByShipId(params).then(res => {
        this.pagination.pageNo = res.data.pageNo
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
        this.tableData = res.data.collection
      })
    },
    getImportFromNewStorageTableData(){
      var params = {
        ShipId:this.ShipId,
        PageNo:this.ImportFromNewStorage.PageNo,
        PageSize:8,
        UserId:this.ImportFromNewStorage.selectedUserId,
        Location:this.ImportFromNewStorage.Location,
        Mark:this.ImportFromNewStorage.Mark,
        StartTime:this.ImportFromNewStorage.StartTime,
        EndTime:this.ImportFromNewStorage.EndTime,
        RegionId:this.ImportFromNewStorage.selectedRegionId,
        ItemType:this.ImportFromNewStorage.selectedMerchandiseType
      }
      if(params.UserId == -1)delete params['UserId']
      if(params.RegionId == -1)delete params['RegionId']
      if(params.EndTime == '')delete params['EndTime']
      if(params.StartTime == '')delete params['StartTime']
      if(params.Mark == '')delete params['Mark']
      if(params.Location == '')delete params['Location']
      if(params.ItemType == -1)delete params['ItemType']
      GetNewStorageListByShipNo(params).then(res => {
        this.ImportFromNewStorage.PageNo = res.data.pageNo
        this.ImportFromNewStorage.dataTable = res.data.collection
      })
    },
    getImportFromStorageTableData(){
      var params = {
        ShipId:this.ShipId,
        PageNo:this.ImportFromStorage.PageNo,
        PageSize:8,
        UserId:this.ImportFromStorage.selectedUserId,
        Location:this.ImportFromStorage.Location,
        Mark:this.ImportFromStorage.Mark,
        StartTime:this.ImportFromStorage.StartTime,
        EndTime:this.ImportFromStorage.EndTime,
        RegionId:this.ImportFromStorage.selectedRegionId,
        ItemType:this.ImportFromStorage.selectedMerchandiseType
      }
      if(params.UserId == -1)delete params['UserId']
      if(params.RegionId == -1)delete params['RegionId']
      if(params.EndTime == '')delete params['EndTime']
      if(params.StartTime == '')delete params['StartTime']
      if(params.Mark == '')delete params['Mark']
      if(params.Location == '')delete params['Location']
      if(params.ItemType == -1)delete params['ItemType']
      GetStorageListByShipNo(params).then(res => {
        this.ImportFromStorage.PageNo = res.data.pageNo
        this.ImportFromStorage.dataTable = res.data.collection
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    onHandleBack(){
      this.$router.back()
    },
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    onHandleSplitBill(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      if(ids.length > 1){
        this.$message.warning('分票只能单独一个订单操作!')
        return
      }
      GetPackageSplitBillData({Id:ids[0]}).then(res => {
        this.SplitBillDialog.Form = res.data
        this.SplitBillDialog.Visible = true
      })
    },
    onHandleBatchPutting(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
    },
    handleSelectionChange(val){
      this.multipleSelection = val;
    },
    getItemTypeDisplayText({itemType}){
      var ele = this.toShowMerchandiseTypeList.find(x => x.value == itemType)
      return ele.label
    },
    getItemStatusDisplayText({shipStatus}){
      const arr = ['计划装柜','装柜中','装柜完成']
      return arr[shipStatus]
    },
    onHandleSplitBillSubmit(){
      PackageSplitBillSubmit({
        ExpressNo:this.SplitBillDialog.Form.expressNo,
        LeftPackageCount:this.SplitBillDialog.Form.LeftCount,
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.SplitBillDialog.Visible = false
      })
    },
    onHandleMoveToStorage(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      MoveToStorage({ids:ids.join(',')}).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
      })
    },
    openAlert(message,title = '提示',callback){
      this.$alert(message,title,{
          confirmButtonText: '确定',
          callback:callback,
      });
    },
    onHandleShowImportFromNew(){
      this.ImportFromNewStorage.Visible = true
      this.ImportFromNewStorage.PageNo = 1
      this.getImportFromNewStorageTableData();
    },
    onHandleImportFromNewStorageBatchJoin(){
      var ids = []
      this.ImportFromNewStorage.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      FromNewStorageSelectBatchJoin({
        ShipId:this.ShipId,
        PackageIds:ids
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.ImportFromNewStorage.Visible = false
        this.getTableData()
      })
    },
    onHandleImportFromStorageBatchJoin(){
      var ids = []
      this.ImportFromStorage.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      FromNewStorageSelectBatchJoin({
        ShipId:this.ShipId,
        PackageIds:ids
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.ImportFromStorage.Visible = false
        this.getTableData()
      })
    },
    onHandleImportFromNewStorageSelectionChange(val){
      this.ImportFromNewStorage.multipleSelection = val
    },
    onHandleShowImportFromStorage(){
      this.ImportFromStorage.PageNo = 1
      this.ImportFromStorage.Visible = true
      this.getImportFromStorageTableData()
    },
    onHandleImportFromStorageSelectionChange(val){
      this.ImportFromStorage.multipleSelection = val
    },
    onHandleImportFromStorageSearch(){
      this.ImportFromStorage.PageNo = 1
      this.getImportFromStorageTableData()
    },
    onHandleImportFromNewStorageSearch(){
      this.ImportFromNewStorage.PageNo = 1
      this.getImportFromNewStorageTableData()
    },
  }
}
</script>
<style scoped>
.create-ship-button{
  float:left;
  margin-bottom:8px;
}
.bottom-left-button-group{
  float:left;
  margin-top:10px;
}
.ship-create-list-pagination{
  margin-top:10px;
}
.updateDialogForm-input-control{
  width:200px;
}
</style>
