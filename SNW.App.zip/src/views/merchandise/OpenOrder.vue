<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>开单</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div id="custom-form-container">
      <el-form id="custom_form" class="OpenOrderForm"
       label-width="auto" :model="ruleForm"
       :rules="FormRules" ref="ruleForm">
          <el-form-item label="用户编号:" prop="SelectedUserId">
              <el-select class="fw" v-model="ruleForm.SelectedUserId" style="width:215px">
                  <el-option v-for="item in ToShowUserList"
                             :key="item.key"
                             :label="item.label"
                             :value="item.value">
                  </el-option>
              </el-select>
          </el-form-item>
          <el-form-item label="地区:" prop="SelectedRegionId">
              <el-select class="fw" v-model="ruleForm.SelectedRegionId" style="width:215px">
                  <el-option v-for="item in ToShowRegionList"
                             :key="item.key"
                             :label="item.label"
                             :value="item.value">
                  </el-option>
              </el-select>
          </el-form-item>
          <el-form-item label="唛头:" prop="Mark">
              <el-input v-model="ruleForm.Mark" style="width:215px"/>
          </el-form-item>
          <el-form-item label="件数:" prop="ItemCount">
              <el-input-number :min='0' v-model="ruleForm.ItemCount" style="width:215px"/>
          </el-form-item>
          <el-form-item label="物品名称:" prop="ItemName">
              <el-input v-model="ruleForm.ItemName" style="width:215px"/>
          </el-form-item>
          <el-form-item label="发货人/发货公司:" prop="SenderOrCompany">
              <el-input v-model="ruleForm.SenderOrCompany" style="width:215px"/>
          </el-form-item>
          <el-form-item label="送货人电话:" prop="SenderPhone">
              <el-input v-model="ruleForm.SenderPhone" style="width:215px"/>
          </el-form-item>
          <el-form-item label="订单号(送货):" prop="SenderOrderNumber">
              <el-input v-model="ruleForm.SenderOrderNumber" style="width:215px"/>
          </el-form-item>
          <el-form-item label="快递列表:" prop="ExpressList">
              <el-input id="leftNum" type="textarea" :autosize="{ minRows: 5, maxRows: 999}"
                v-model="ruleForm.ExpressList" @input="onInputExpressList"
                style="width:215px" show-word-limit maxlength="30"/>
          </el-form-item>
          <el-form-item>
              <el-button icon="el-icon-circle-check" type="primary" style="margin-right:10px;" @click="onReset('ruleForm')">重置</el-button>
              <el-button icon="el-icon-printer" type="success" @click="onSubmit('ruleForm')">打印</el-button>
          </el-form-item>
      </el-form>
    </div>
  </el-card>
</template>
<script>
import print from 'print-js'
import { mmToPx } from '@/utils/screen_util'
import { GetUsers,GetRegionList,GetRegionList2 } from '@/api/services/packageLookupService'
import { get_open_order_filter_param, Print_GetLabel, OpenOrder } from '@/api/services/merchandiseService'
export default {
    name: 'OpenOrder',
    data(){
        return {
            ruleForm: {
                ItemName: '',
                Mark: '',
                ItemCount: 0,
                SenderOrCompany: '',
                SenderPhone: '',
                SenderOrderNumber: '',
                SelectedUserId:-1,
                SelectedRegionId:-1,
            },
            ToShowUserList:[],
            ToShowRegionList:[],
            FormRules: {
              SelectedUserId:[
                { required: true, message: '请选择用户', trigger: 'change' }
              ],
              SelectedRegionId:{ required: true, message: '请选择地区', trigger:['change','blur'] },
              ItemCount:[
                { required: true, message: '请输入物品件数', trigger:['change','blur'] },
                { pattern:/[1-9][0-9]*/,message:'请输入有效物品件数',trigger:['blur','change'] },
              ],
              ItemName:{ required: true, message: '请输入物品名称', trigger: ['blur', 'change'] },
              Mark:{ required: true, message: '请输入唛头', trigger:['blur', 'change'] },
              SenderPhone:{ required: true, message: '请输入发货人电话', trigger:['blur', 'change'] },
              SenderOrCompany:{ required: true, message: '请输入发货人/发货公司', trigger:['blur', 'change'] },
              SenderOrderNumber:{ required: true, message: '请输入订单号(送货)', trigger:['blur', 'change'] },
              ExpressList:{ required: false, message: '请输入快递列表', trigger:['blur', 'change'] },
            }
        }
    },
    created() {
        this.getParams()

        setTimeout(() => {
          var element = document.getElementsByClassName('el-input__count')[0]
          element.innerText = "1个"
        },200)
    },
    methods: {
        async getParams() {
          this.ToShowUserList.push({
            key:-1,
            value:-1,
            label:'选择用户'
          })
          GetUsers().then(res => {
            res.data.forEach((item, i) => {
              this.ToShowUserList.push({
                key:item.id,
                label:item.name,
                value:item.id
              });
            });
          })
          GetRegionList2().then(res => {
            this.ToShowRegionList = []
            this.ToShowRegionList.push({
              key:-1,
              value:-1,
              label:'选择地区'
            })
            res.data.forEach((item, i) => {
              this.ToShowRegionList.push({
                key:item.id,
                label:item.name,
                value:item.id
              });
            });
          })
        },
        onSubmit(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    OpenOrder({
                        userId: this.ruleForm.SelectedUserId,
                        regionId: this.ruleForm.SelectedRegionId,
                        itemCount: this.ruleForm.ItemCount,
                        itemName: this.ruleForm.ItemName,
                        senderName: this.ruleForm.SenderOrCompany,
                        mark: this.ruleForm.Mark,
                        deliverPhoneNumber: this.ruleForm.SenderPhone,
                        orderNumber: this.ruleForm.SenderOrderNumber,
                        expressList: this.ruleForm.ExpressList,
                    }).then(res => {
                        console.log('res: ' + JSON.stringify(res))
                        if (res.status == 200) {
                          const expressNumber = res.data.content
                            Print_GetLabel({
                                width:parseInt(mmToPx(100)),
                                height:parseInt(mmToPx(70)),
                                // width:485,
                                // height:364,
                                ExpressNumber:expressNumber,
                                Mark: this.ruleForm.Mark,
                                ItemCount: this.ruleForm.ItemCount
                            }).then(res => {
                                if (res.data != null && res.data.length > 1) {
                                    printJS({
                                        printable: res.data,
                                        type: 'pdf',
                                        base64: true
                                    })
                                }
                            })
                        }
                    })
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });
        },
        onReset(formName) {
            this.$refs[formName].resetFields();
        },
        onInputExpressList(val){
          var array = val.split("\n")
          var count = array.length
          console.log(`array: ${array}`)
          console.log(`count: ${count}`)

          var element = document.getElementsByClassName('el-input__count')[0]
          element.innerText = parseInt(count) + "个"
        }
    }
}
</script>
<style scoped>
.OpenOrderForm {
    white-space: nowrap;
    align-items: center;
}
.el-input__count{
  color:red;
}
</style>
