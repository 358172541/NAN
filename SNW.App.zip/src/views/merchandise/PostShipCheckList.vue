<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>Post机-船次审核</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
      <el-table :data="dataTable" border>
        <el-table-column prop="shipNo" label="船 次"/>
        <el-table-column prop="-" label="审 核">
          <template slot-scope="scope">
            <el-button type="primary" icon="el-icon-edit" size="small" @click="onHandleShowCheckDialog(scope.row.id)">审核</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div style="margin-top:15px;width:100%;display:inline-flex">
        <div style="width:100%"/>
        <div style="float:right">
          <el-pagination background layout="prev, pager,next,total,jumper"
           :total="pagination.totalCount" :page-count="pagination.totalPage"
           :current-page="pagination.pageNo" @current-change="pageNoChange"/>
        </div>
      </div>
      <el-dialog
        title="货物-装柜检测"
        :visible.sync="DialogCheckDialog.Visible"
        width="20%">
        <div>
          <el-input type="textarea" :rows="5" placeholder="请输入内容" v-model="DialogCheckDialog.InputData"/>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="onHandleCheckDialogReset">重置</el-button>
          <el-button type="primary" @click="onHandleCheckDialogSubmit">提交</el-button>
        </span>
      </el-dialog>
    </div>
  </el-card>
</template>
<script>
import { playAudio } from '@/utils/audio_util'
import { GetShipCheckList,ShipCheck } from '@/api/services/postService'

export default{
  name:'PostShipCheckList',
  data(){
    return{
      pagination:{
        pageNo:1,       // 当前页
        pageSize:8,     // 当前页数量
        totalPage:2,    // 总页数
        totalCount:10,   // 总条数
      },
      dataTable:[],
      DialogCheckDialog:{
        ShipId:0,
        Visible:false,
        InputData:''
      }
    }
  },
  created(){
    this.getTableData()
  },
  methods:{
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    getTableData(){
      GetShipCheckList({
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }).then(res => {
        this.dataTable = res.data.collection
        this.pagination.pageNo = res.data.pageNo
        this.pagination.pageSize = res.data.pageSize
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
        this.TotalGoway = res.data.totalCount
      })
    },
    onHandleShowCheckDialog(ShipId){
      this.DialogCheckDialog.Visible = true
      this.DialogCheckDialog.ShipId = ShipId
    },
    onHandleCheckDialogReset(){
      this.DialogCheckDialog.InputData = ''
    },
    onHandleCheckDialogSubmit(){
      if(this.DialogCheckDialog.InputData == ''){
        this.$message.error("输入内容必填!")
        return
      }
      ShipCheck({
        ShipId:this.DialogCheckDialog.ShipId,
        InputData:this.DialogCheckDialog.InputData
      }).then(res => {
        if(res.data.code != 200 || res.data.content != 1){
          this.$message.error(res.data.message)
          playAudio('audios/5051.wav')
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
        this.DialogCheckDialog.Visible = false
      })
    }
  }
}
</script>
