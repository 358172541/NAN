<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>扫描入库-小包慢递</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
      <el-form ref="RuleForm" :model="RuleForm" :rules="FormRules">
        <div style="width:300px;">
          <el-form-item label="包裹信息:" prop="Param">
              <el-input v-model="RuleForm.Param"
               placeholder="包裹信息，格式：快递号,重量,长|宽|高" @input="onSubmit" clearable/>
          </el-form-item>
        </div>
      </el-form>
      <div class='custom-button-group'>
        <el-button type="success" plain icon="el-icon-setting" @click="onReset">重置</el-button>&nbsp&nbsp
        <el-button type="primary" plain icon="el-icon-success" @click="onSubmit">保存</el-button>
      </div>
    </div>
  </el-card>
</template>
<script>
import { playAudio } from '@/utils/audio_util'
import { ScanStoringSmallBagSlowExpress } from '@/api/services/merchandiseService'
export default{
  name:'ScanStoringSmallBagSlowExpress',
  data(){
    return{
      RuleForm:{
        Param:'',
      },
      FormRules: {
        Param: { required: true, message: '请输入包裹信息', trigger: [ 'change','blur'] },
      }
    }
  },
  methods:{
    onReset(){
      this.$refs['RuleForm'].resetFields()
    },
    onSubmit(){
      this.$refs['RuleForm'].validate((valid) => {
        if(!valid){
          //this.$message({type:'error',message:'输入信息有误,请检查!'})
          return false;
        }
        ScanStoringSmallBagSlowExpress({param:this.RuleForm.Param}).then(res => {
          console.log(`res: ${JSON.stringify(res)}`)
          if(res.data.code == 200){
            this.$refs['RuleForm'].resetFields()
            //this.$message({type:'success',message:res.data.message})
            playAudio('audios/1431-0713广告女070-4.mp3')
          }else{
            //this.$message({type:'error',message:res.data.message})
            playAudio('audios/5051.wav')
          }
        })
      })
    }
  }
}
</script>
<style scoped>
.custom-button-group{
  margin-top:10px;
}
</style>
