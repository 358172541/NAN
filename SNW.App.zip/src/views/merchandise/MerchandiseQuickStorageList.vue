<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-库存</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user">
      <el-row>
        <el-col :span="5" style="font-size:20px;color:red;font-weight:bold">
          计划装柜体积:
          <el-tag type="danger" style="font-size:20px;color:red">{{TotalVolume}}</el-tag>
        </el-col>
        <el-col :span="5" style="font-size:20px;color:red;font-weight:bold">
          计划装柜重量:
          <el-tag type="danger" style="font-size:20px;color:red">{{TotalWeight}}</el-tag>
        </el-col>
      </el-row>
      <el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedUserId" placeholder="选择会员">
            <el-option
              v-for="item in toShowUserList"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedMerchandiseType" placeholder="货物类型">
            <el-option v-for="item in toShowMerchandiseTypeList"
             :key='item.key' :label='item.label' :value='item.value'/>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedSupplementType" placeholder="选择状态">
            <el-option v-for="item in toShowSupplementList"
             :key='item.key' :label='item.label' :value='item.value'/>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedRegionId" placeholder="选择地区">
            <el-option
              v-for="item in toShowRegionList"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedRouteId" placeholder="选择航线">
            <el-option
              v-for="item in toShowRouteList"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-date-picker
             v-model="StartTime"
             placement="bottom-start"
             type="date"
             placeholder="开始时间">
          </el-date-picker>
        </el-row>
        <el-row class="tool-bar">
          <el-date-picker
             v-model="EndTime"
             placement="bottom-start"
             type="date"
             placeholder="结束时间">
          </el-date-picker>
        </el-row>
        <el-row class="tool-bar">
          <el-input v-model="ExpressNo" placeholder="请输入运输单号"/>
        </el-row>
        <el-row class="tool-bar">
          <el-input v-model="Mark" placeholder="请输入唛头" style="margin-right:15px;"/>
        </el-row>
        <el-row class="tool-bar">
          <div class="button-toolbar" style="align-items:center">
            <el-button class="btnSearch" type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>
            <el-button type="success" @click="onHandleUpdateStatus(3)">货未齐</el-button>
            <el-button type="success" @click="onHandleUpdateStatus(4)">货已齐</el-button>
            <el-button type="success" @click="onHandleUpdateStatus(5)">可出货</el-button>
            <el-button type="success" @click="onHandleUpdateStatus(6)">扣货</el-button>
            <el-button type="success" @click="onHandleEditRoute()">批量更改航线</el-button>
          </div>
        </el-row>
      </el-row>
      <el-row style="margin-top:10px">
        <el-table border ref="multipleTable" tooltip-effect="dark"
            @selection-change="handleSelectionChange" style="width: 100%"
            :data="dataTable" :row-class-name="tableRowClassName">
            <el-table-column type="selection"width="50"/>
            <el-table-column prop="expressNumber" label="运输单号" width="180"/>
            <el-table-column prop="mark" label="唛头"/>
            <el-table-column prop="collection" label="代付"/>
            <el-table-column prop="regionDisplay" label="地址">
              <template slot-scope="scope">
                <div>
                 <span>{{scope.row.regionDisplay}}</span>
                 <el-button type="text" @click="onHandleShowDetailAddressDialog(scope.row)">查看</el-button>
               </div>
              </template>
            </el-table-column>
            <el-table-column prop="deliveryRegionDisplay" label="派送地区" width='200':show-overflow-tooltip='true'/>
            <el-table-column prop="userDisplay" label="会员编号"/>
            <el-table-column prop="itemCount" label="件数"/>
            <el-table-column prop="weight" label="重量"/>
            <el-table-column prop="regionDisplay" label="地区"/>
            <el-table-column prop="volume" label="S/体积"/>
            <el-table-column prop="itemName" label="品名" width='150':show-overflow-tooltip='true'/>
            <el-table-column prop="itemStatus" label="货物状态">
              <template slot-scope="scope">
                <div>
                 <span>{{getItemStatusDisplayText(scope.row)}}</span>
               </div>
              </template>
            </el-table-column/>
            <el-table-column prop="itemType" label="类型">
              <template slot-scope="scope">
                <el-row>
                  <span>{{getItemTypeDisplayText(scope.row)}}</span>
                </el-row>
              </template>
            </el-table-column>
            <el-table-column prop="packingType" label="包装">
              <template slot-scope="scope">
                <el-row>
                  <span>{{getPackingTypeDisplayText(scope.row)}}</span>
                </el-row>
              </template>
            </el-table-column>
            <el-table-column
             fixed="right"
             label="操作"
             width='100'>
             <template slot-scope="scope">
               <el-row>
                <el-button type="text" @click="editHandle(scope.row)">编辑</el-button>
                <el-button type="text" @click="onHandleGotoNewStorage(scope.row)">转到旧库存</el-button>
              </el-row>
             </template>
           </el-table-column>
        </el-table>
      </el-row>
      <el-row style="margin-top:20px;">
        <el-button type="danger" icon="el-icon-delete" @click="onHandleBatchDelete()">批量删除</el-button>
        <div style="float:right">
          <el-pagination background layout="prev, pager,next,total,jumper"
           :total="pagination.totalCount" :page-count="pagination.totalPage"
           :current-page="pagination.pageNo" @current-change="pageNoChange"/>
        </div>
      </el-row>
      <el-dialog
        title="批量更改线路"
        :visible.sync="dialogEditRouteVisible"
        width="20%">
        <div>
          选择地区:&nbsp&nbsp
          <el-select v-model="batchUpdateRegionDialogSelectedRegionId" placeholder="选择航线">
            <el-option
              v-for="item in toShowRegionList"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="onHandleEditRouteSubmit()">确定</el-button>
        </span>
      </el-dialog>
      <el-dialog
        title=""
        :visible.sync="showDetailAddressDialogVisible"
        width="20%">
        <div>
          <el-row>
            <span>流水号:</span>
            <span>{{this.showDetailAddressDialogValues.expressNumber}}</span>
          </el-row>
          <el-row style="margin-top:10px">
            <span>唛头:</span>
            <span>{{this.showDetailAddressDialogValues.mark}}</span>
          </el-row>
          <el-row style="margin-top:10px">
            <span>收件人:</span>
            <span>{{this.showDetailAddressDialogValues.recipientName}}</span>
          </el-row>
          <el-row style="margin-top:10px">
            <span>公司:</span>
            <span>{{this.showDetailAddressDialogValues.recipientCompanyName}}</span>
          </el-row>
          <el-row style="margin-top:10px">
            <span>联系电话:</span>
            <span>{{this.showDetailAddressDialogValues.recipientContactTelephone}}</span>
          </el-row>
          <el-row style="margin-top:10px">
            <span>邮编:</span>
            <span>{{this.showDetailAddressDialogValues.recipientPostcode}}</span>
          </el-row>
          <el-row style="margin-top:10px">
            <span>派送地址:</span>
            <span>{{this.showDetailAddressDialogValues.deliveryAddress}}</span>
          </el-row>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="showDetailAddressDialogVisible = false">确定</el-button>
        </span>
      </el-dialog>
    </div>
  </el-card>
</template>
<script>
import { GetUsers,GetRoutes,GetShipNos,GetRegionList } from '@/api/services/packageLookupService'
import { GetMerchandiseQuickStorageList,GetQuickStorageExraParams
} from '@/api/services/merchandiseService'
import { BatchUpdateItemStatus,BatchDelete,BatchUpdateRegion,UpdateToNewLibrary } from '@/api/services/merchandiseStoreService'
export default {
  name: 'MerchandiseQuickStorageList',
  data(){
    return {
      uploadHeaders:{
        Authorization : 'Bearer' + ' ' + localStorage.getItem('TOKEN'),
      },
      dataTable:[],
      multipleSelection: [],
      pagination:{
        pageNo:1,       // 当前页
        pageSize:8,     // 当前页数量
        totalPage:2,    // 总页数
        totalCount:10,   // 总条数
      },
      selectedRegionId:-1,
      toShowRegionList:[],
      selectedMerchandiseType:-1,
      toShowMerchandiseTypeList:[
        {
          key:-1,
          value:-1,
          label:'选择类型'
        },
        {
          key:0,
          value:0,
          label:'TT'
        },
        {
          key:1,
          value:1,
          label:'JJ'
        },
        {
          key:2,
          value:2,
          label:'A'
        },
        {
          key:3,
          value:3,
          label:'B'
        },
        {
          key:4,
          value:4,
          label:'C'
        },
        {
          key:5,
          value:5,
          label:'F'
        },
        {
          key:6,
          value:6,
          label:'M'
        },
        {
          key:7,
          value:7,
          label:'MT'
        },
        {
          key:8,
          value:8,
          label:'MF'
        }
      ],
      selectedSupplementType:-1,
      toShowSupplementList:[
        {
          key:-1,
          value:-1,
          label:'所有订单'
        },
        {
          key:0,
          value:0,
          label:'资料未齐'
        },
        {
          key:2,
          value:2,
          label:'资料已齐'
        },
        {
          key:3,
          value:3,
          label:'货未齐'
        },
        {
          key:4,
          value:4,
          label:'货已齐'
        },
        {
          key:5,
          value:5,
          label:'可出货'
        },
        {
          key:6,
          value:6,
          label:'扣货'
        },
        {
          key:7,
          value:7,
          label:'用户扣货'
        },
      ],
      selectedRouteId:-1,
      toShowRouteList:[
        {
          key:-1,
          value:-1,
          label:'选择航线'
        },
      ],
      selectedUserId:-1,
      toShowUserList:[
        {
          key:-1,
          value:-1,
          label:'选择会员'
        },
      ],
      ExpressNo:'',
      Mark:'',
      StartTime:'',
      EndTime:'',
      dialogRuleVisible:false,
      dialogUploadVisible:false,
      dialogEditRouteVisible:false,
      TotalVolume:0,
      TotalWeight:0,
      batchUpdateRegionDialogSelectedRegionId:-1,
      showDetailAddressDialogVisible:false,
      showDetailAddressDialogValues:{},
    }
  },
  created(){
    GetUsers().then(res => {
      res.data.forEach((item, i) => {
        this.toShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRoutes().then(res => {
      res.data.forEach((item, i) => {
        this.toShowRouteList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRegionList().then(res => {
      this.toShowRegionList.push({
        key:-1,
        value:-1,
        label:'选择地区',
      })
      res.data.forEach((item, i) => {
        this.toShowRegionList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetQuickStorageExraParams().then(res => {
      this.TotalVolume = res.data.totalVolume
      this.TotalWeight = res.data.totalWeight
    })
    this.getTableData()
  },
  methods:{
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    async getTableData(){
      var params = {
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
        ItemType:this.selectedMerchandiseType,
        ItemStatus:this.selectedSupplementType,
        BoxNumber:this.selectedShipNo,
        UserId:this.selectedUserId,
        RouteId:this.selectedRouteId,
        ExpressNumber:this.ExpressNo,
        Mark:this.Mark,
        RegionId:this.selectedRegionId,
        StartTime:this.StartTime,
        EndTime:this.EndTime
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['ItemStatus'] == -1){
        delete params['ItemStatus']
      }
      if(params['BoxNumber'] == -1){
        delete params['BoxNumber']
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['ExpressNumber'] == ''){
        delete params['ExpressNumber']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      if(params['RegionId'] == -1){
        delete params['RegionId']
      }
      if(params['StartTime'] == ''){
        delete params['StartTime']
      }
      if(params['EndTime'] == ''){
        delete params['EndTime']
      }
      GetMerchandiseQuickStorageList(params).then(res => {
        this.dataTable = res.data.collection
        this.pagination.pageNo = res.data.pageNo
        this.pagination.pageSize = res.data.pageSize
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    handleSelectionChange(val) {
        this.multipleSelection = val;
    },
    editHandle({id}){
      this.$router.push('/MerchandiseStorageEdit?id=' + id)
    },
    getItemTypeDisplayText({itemType}){
      var ele = this.toShowMerchandiseTypeList.find(x => x.value == itemType)
      return ele.label
    },
    getItemStatusDisplayText({itemStatus}){
      var ele = this.toShowSupplementList.find(x => x.value == itemStatus)
      return ele != null ? ele.label : ''
    },
    getPackingTypeDisplayText({packingType}){
      const list = [
        '-','纸箱','编织袋','木架','裸装','重货','超长','塑料桶','托盘'
      ]
      return list[packingType]
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    },
    onHandleUpdateStatus(itemStatus){
      console.log(`itemStatus: ${itemStatus}`)
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择要更改状态的列表项!')
        return
      }
      BatchUpdateItemStatus({
        Ids:ids,
        ItemStatus:itemStatus,
      }).then(res => {
        console.log(`BatchUpdateItemStatus: ${JSON.stringify(res)}`)
        if(res.status != 200){
          this.$message.error('更新状态出错!')
          return
        }else{
          this.$message.success('更新状态成功!')
        }
        this.getTableData()
      })
    },
    onHandleBatchDelete(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择要删除的列表项!')
        return
      }
      this.openConfirm('此操作将永久删除该文件, 是否继续?',() => {
        BatchDelete(ids).then(res => {
          this.$message({
            type:res.data.code == 200 ? 'success' : 'error',
            message:res.data.message
          });
          this.getTableData()
        })
      })
    },
    onHandleEditRoute(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请选择欲操作列表项!')
        return
      }
      this.dialogEditRouteVisible = true
    },
    onHandleShowDetailAddressDialog(values){
      this.showDetailAddressDialogVisible = true
      this.showDetailAddressDialogValues = values
    },
    onHandleEditRouteSubmit(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请选择欲操作列表项!')
        return
      }
      BatchUpdateRegion({
        Ids:ids,
        RegionId:this.batchUpdateRegionDialogSelectedRegionId,
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.dialogEditRouteVisible = false
        this.getTableData()
      })
    },
    onHandleGotoNewStorage({id}){
      UpdateToNewLibrary({
        Id:id,
        NewStorage:false
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
      })
    }
  }
}
</script>
<style scoped>
.tool-bar{
  margin-right:5px;
  margin-top:15px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
</style>
