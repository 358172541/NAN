<template>
  <el-card style="padding-bottom: 20px;">
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-船次建立</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
      <div class="create-ship-button">
        <el-button type="primary" icon="el-icon-news" @click="onHandleCreateShip">船次建立</el-button>
      </div>
      <el-table border ref="multipleTable" tooltip-effect="dark"
          @selection-change="handleSelectionChange" style="width: 100%"
          :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column type="selection"width="50"/>
          <el-table-column prop="shipNo" label="船次编号" width="150"/>
          <el-table-column prop="landTime" label="装柜时间"/>
          <el-table-column prop="startTime" label="开船时间"/>
          <el-table-column prop="receiveTime" label="到港时间"/>
          <el-table-column prop="internalShipNo" label="内部柜号"/>
          <el-table-column prop="sealShipNo" label="封条号"/>
          <el-table-column prop="sealShipNo" label="检测结果">
            <template slot-scope="scope">
              <el-button type="text" @click="onHandleCheck(scope.row)">开始检测</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="shipStatus" label="状态">
            <template slot-scope="scope">
              <el-row>
               <span>{{getItemStatusDisplayText(scope.row)}}</span>
             </el-row>
            </template>
          </el-table-column>
          <el-table-column prop="-" label="重量/体积">
            <template slot-scope="scope">
              <div style="display: grid;">
                <span style="white-space:nowrap">总体积：{{scope.row.totalVolume != null ? scope.row.totalVolume : '0'}}</span>
                <span style="white-space:nowrap;margin-top:7px">总重量：{{scope.row.totalWeight != null ? scope.row.totalWeight : '0'}}</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column
           fixed="right"
           label="操作"
           width='auto'>
           <template slot-scope="scope">
             <el-button type="text" size="mini" @click="onHandleEdit(scope.row)">编辑</el-button>
             <el-button type="text" accesskey=""size="mini" @click="onHandlePackageManage(scope.row)">包裹管理</el-button>
             <el-button type="text" size="mini" @click="onHandleReportExport(scope.row)">报表导出</el-button>
           </template>
         </el-table-column>
      </el-table>
      <div style="margin-top:10px;width:100%;display:inline-flex">
        <div style="width:100%">
          <el-button-group class="bottom-left-button-group">
           <el-button type="warning" size="small" @click="onHandleBatchPutting()">装柜中</el-button>
           <el-button type="success" size="small" @click="onHandleBatchPutFinish()">装柜完成</el-button>
          </el-button-group>
        </div>
        <div style="float:right;margin-top:10px">
          <el-pagination background layout="prev, pager,next,total,jumper"
           :total="pagination.totalCount" :page-count="pagination.totalPage"
           :current-page="pagination.pageNo" @current-change="pageNoChange"/>
        </div>
      </div>
      <el-dialog title="基本信息设置" width="400px"
        :visible.sync="addDialogVisible"
        :before-close="onHandleCreateDialogClose()">
          <el-form :model="createShipForm" ref="createShipForm" label-width="100px">
            <el-form-item label="船期" prop="ShipNo">
              <el-input v-model="createShipForm.ShipNo"></el-input>
            </el-form-item>
            <el-form-item label="地区" prop="SelectedRegionId">
                <el-select class="fw" v-model="createShipForm.SelectedRegionId" style="width:100%">
                    <el-option v-for="item in toShowRegionList"
                               :key="item.key"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="装柜时间" prop="LandTime">
              <el-date-picker
               v-model="createShipForm.LandTime"
               type="date"
               placement="bottom-start"
               placeholder="选择日期">
             </el-date-picker>
            </el-form-item>
            <el-form-item label="开船时间" prop="StartTime">
              <el-date-picker
                 v-model="createShipForm.StartTime"
                 type="date"
                 placement="bottom-start"
                 placeholder="选择日期">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="预计到港时间" prop="ReceiveTime">
              <el-date-picker
                 v-model="createShipForm.ReceiveTime"
                 type="date"
                 placement="bottom-start"
                 placeholder="选择日期">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="内部柜号" prop="InternalShipNo">
              <el-input v-model="createShipForm.InternalShipNo"/>
            </el-form-item>
            <el-form-item label="封条号" prop="SealShipNo">
              <el-input v-model="createShipForm.SealShipNo"/>
            </el-form-item>
            <el-form-item label="船运公司" prop="ShipCompany">
              <el-input v-model="createShipForm.ShipCompany"/>
            </el-form-item>
            <el-form-item label="调柜部门" prop="AdjustDepartment">
              <el-input v-model="createShipForm.AdjustDepartment"/>
            </el-form-item>
            <el-form-item label="清关部门" prop="Clearance">
              <el-input v-model="createShipForm.Clearance"/>
            </el-form-item>
            <el-form-item label="备注" prop="Remark">
              <el-input v-model="createShipForm.Remark" type="textarea" :rows="5"/>
            </el-form-item>
          </el-form>
          <div>
            <el-button type="primary" @click="onCreateShip">保存</el-button>
            <el-button type="primary" @click="onHandleCreateFormReset">重置</el-button>
          </div>
      </el-dialog>
      <el-dialog title="编辑"
         width="400px"
         :visible.sync="updateDialogVisible">
          <el-form
             :model="updateDialogForm"
             ref="updateDialogForm"
             label-width="100px">
            <el-form-item label="船期" prop="ShipNo">
              <el-input v-model="updateDialogForm.ShipNo" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="地区" prop="SelectedRegionId">
                <el-select class="updateDialogForm-input-control" v-model="updateDialogForm.SelectedRegionId">
                    <el-option v-for="item in toShowRegionList"
                               :key="item.key"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="装柜时间" prop="LandTime">
              <el-date-picker
               v-model="updateDialogForm.LandTime"
               type="date"
               placement="bottom-start"
               placeholder="选择日期"
               class="updateDialogForm-input-control">
             </el-date-picker>
            </el-form-item>
            <el-form-item label="开船时间" prop="StartTime">
              <el-date-picker
                 v-model="updateDialogForm.StartTime"
                 type="date"
                 placement="bottom-start"
                 placeholder="选择日期"
                 class="updateDialogForm-input-control">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="预计到港时间: " prop="ReceiveTime">
              <el-date-picker
                 v-model="updateDialogForm.ReceiveTime"
                 placement="bottom-start"
                 type="date"
                 placeholder="选择日期"
                 class="updateDialogForm-input-control">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="内部柜号" prop="InternalShipNo">
              <el-input v-model="updateDialogForm.InternalShipNo" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="封条号" prop="SealShipNo">
              <el-input v-model="updateDialogForm.SealShipNo" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="船运公司" prop="ShipCompany">
              <el-input v-model="updateDialogForm.ShipCompany" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="调柜部门" prop="AdjustDepartment">
              <el-input v-model="updateDialogForm.AdjustDepartment" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="清关部门" prop="Clearance">
              <el-input v-model="updateDialogForm.Clearance" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="进仓备注" prop="Remark">
              <el-input v-model="updateDialogForm.InStorageRemark" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="船期备注" prop="Remark">
              <el-input v-model="updateDialogForm.Remark" type="textarea" :rows="5" class="updateDialogForm-input-control"/>
            </el-form-item>
          </el-form>
          <div>
            <el-button type="primary" @click="onHandleUpdateDialogSubmit()">保存</el-button>
            <el-button type="primary">重置</el-button>
          </div>
      </el-dialog>
      <el-dialog title="报表导出"
         width="850px"
         :visible.sync="ReportExportDialog.Visible">
         <div class="dialog-body">
           <el-button type="primary" icon="el-icon-film" @click="onHandleReportExportDialogGenerate">生成报表</el-button>
           <el-table :data="ReportExportDialog.TableData"
             @selection-change="onHandleReportExportSelectionChange"
             style="width: 100%">
             <el-table-column type="selection" width="50"/>
             <el-table-column prop="fileName" label="报表名称" width='300px' :show-overflow-tooltip='true'/>
             <el-table-column prop="fileSize" label="报表大小">
               <template slot-scope="scope">
                 <span>{{scope.row.fileSize / 1024}}KB</span>
               </template>
             </el-table-column>
             <el-table-column prop="creationTime" label="创建时间"/>
             <el-table-column prop="-" label="操作">
               <template slot-scope="scope">
                 <el-button type="text" @click="onHandleReportExportDialogDownloadReport(scope.row.fileName)">下载</el-button>
               </template>
             </el-table-column>
           </el-table>
         </div>
         <div class="dialog-footer" style="margin-top:20px">
           <el-button type="danger" icon="el-icon-delete" @click="onHandleReportExportDialogBatchDelete">批量删除</el-button>
         </div>
      </el-dialog>
    </div>
  </el-card>
</template>
<script>
import { GetRegionList2 } from '@/api/services/packageLookupService'
import { GetShipList,CreateShip,ShipCheck,UpdateShip } from '@/api/services/merchandiseService'
import { Putting,IsFinishShip,PutFinish,GenerateReport,GetReportList,BatchDeleteReport } from '@/api/services/shipService'
export default{
  name:'MerchandiseShipCreate',
  data(){
    return{
      tableData:[],
      multipleSelection:[],
      pagination:{
        pageNo:1,
        pageSize:8,
        totalPage:1,
        totalCount:1,
      },
      addDialogVisible:false,
      toShowRegionList:[],
      createShipForm:{
        ShipNo:'',
        SelectedRegionId:0,
        LandTime:'',
        StartTime:'',
        ReceiveTime:'',
        InternalShipNo:'',
        SealShipNo:'',
        ShipCompany:'',
        AdjustDepartment:'',
        Clearance:'',
        Remark:'',
      },
      updateDialogVisible:false,
      updateDialogForm:{
        ExpectArrivedDate:'',
        ShipDate:'',
        ShipNo:'',
        SelectedRegionId:-1,
        LandTime:'',
        StartTime:'',
        ReceiveTime:'',
        InternalShipNo:'',
        SealShipNo:'',
        ShipCompany:'',
        AdjustDepartment:'',
        Clearance:'',
        Remark:''
      },
      ReportExportDialog:{
        Visible:false,
        ShipId:0,
        TableData:[],
        MultipleSelection:[],
      }
    }
  },
  created(){
    this.getTableData()
    GetRegionList2().then(res => {
      this.toShowRegionList = []
      this.toShowRegionList.push({
        key:0,
        value:0,
        label:'选择地区',
      })
      res.data.forEach((item, i) => {
        this.toShowRegionList.push({
          key:item.id,
          label:item.name,
          value:item.id
        })
      });

    })
  },
  methods:{
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    onHandleCreateFormReset(){
      this.$refs['createShipForm'].resetFields()
    },
    toggleSelection(rows){
      if(rows)
      {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      }
      else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    onHandleReportExportSelectionChange(val){
      this.ReportExportDialog.MultipleSelection = val
    },
    onHandleCreateDialogClose(done){

    },
    onHandlePackageManage({id}){
      this.$router.push('/ShipPackageManageList?ShipId=' + id)
    },
    onHandleReportExport({id}){
      this.ReportExportDialog.Visible = true
      this.ReportExportDialog.ShipId = id
      GetReportList().then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.ReportExportDialog.TableData = res.data.content
      })
    },
    onHandleReportExportDialogDownloadReport(fileName){
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/ships/DownloadReport?fileName=' + fileName;
      link.click();
    },
    onHandleReportExportDialogBatchDelete(){
      var names = []
      this.ReportExportDialog.MultipleSelection.forEach((item,i) => {
        names.push(item.fileName)
      });
      if(names.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      BatchDeleteReport({
        FileNames:names
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        GetReportList().then(res => {
          if(res.data.code != 200){
            this.$message.error(res.data.message)
            return
          }
          this.ReportExportDialog.TableData = res.data.content
        })
      })
    },
    onHandleBatchUpdateStatus({id}){

    },
    onHandleCheck({id}){
      ShipCheck({Id:id}).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
      })
    },
    getTableData(){
      GetShipList({
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize
      }).then(res => {
        this.pagination.pageNo = res.data.pageNo
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
        this.tableData = res.data.collection
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    onHandleCreateShip(){
      this.addDialogVisible = true
    },
    onCreateShip(){
      this.$refs['createShipForm'].validate((valid) => {
        if(!valid){
          console.log('error submit!!');
          return false;
        }
        const params = {
          ShipNo:this.createShipForm.ShipNo,
          LandTime:this.createShipForm.LandTime,
          StartTime:this.createShipForm.StartTime,
          ReceiveTime:this.createShipForm.ReceiveTime,
          Remark:this.createShipForm.Remark,
          RegionId:this.createShipForm.SelectedRegionId,
          InternalShipNo:this.createShipForm.InternalShipNo,
          SealShipNo:this.createShipForm.SealShipNo,
          ShipCompany:this.createShipForm.ShipCompany,
          AdjustDepartment:this.createShipForm.AdjustDepartment,
          Clearance:this.createShipForm.Clearance
        }
        console.log(`params: ${JSON.stringify(params)}`)
        CreateShip(params).then(res => {
          console.log(`res: ${JSON.stringify(res)}`)
          if(res.status == 200){
            this.$message({type:'success',message:'创建成功'})
            this.$refs['createShipForm'].resetFields()
            this.addDialogVisible = false
            this.getTableData()
          }else{
            this.$message({type:'error',message:'创建失败'})
          }
        })
      })
    },
    onHandleReportExportDialogGenerate(){
      GenerateReport({Id:this.ReportExportDialog.ShipId}).then(res => {
        if(res.data.code != 200){
          this.$message.warning(res.data.message)
          return
        }
        this.$message.success(res.data.message)
      })
    },
    onHandleEdit({shipNo,regionId,landTime,
      startTime,receiveTime,internalShipNo,
      sealShipNo,shipCompany,adjustDepartment,
      clearance,shipDateRemark,id
    }){
      this.updateDialogVisible = true
      this.updateDialogForm.Id = id
      this.updateDialogForm.ShipNo = shipNo
      this.updateDialogForm.SelectedRegionId = regionId
      this.updateDialogForm.LandTime = landTime
      this.updateDialogForm.StartTime = startTime
      this.updateDialogForm.ReceiveTime = receiveTime
      this.updateDialogForm.InternalShipNo = internalShipNo
      this.updateDialogForm.SealShipNo = sealShipNo
      this.updateDialogForm.ShipCompany = shipCompany
      this.updateDialogForm.AdjustDepartment = adjustDepartment
      this.updateDialogForm.Clearance = clearance
      this.updateDialogForm.Remark = shipDateRemark
    },
    onHandleUpdateDialogSubmit(){
      var params = {
        Id:this.updateDialogForm.Id,
        ShipNo:this.updateDialogForm.ShipNo,
        LandTime:this.updateDialogForm.LandTime,
        StartTime:this.updateDialogForm.StartTime,
        ReceiveTime:this.updateDialogForm.ReceiveTime,
        Remark:this.updateDialogForm.Remark,
        Clearance:this.updateDialogForm.Clearance,
        ShipDateRemark:this.updateDialogForm.Remark,
        AdjustDepartment:this.updateDialogForm.AdjustDepartment,
        ShipCompany:this.updateDialogForm.ShipCompany,
        SealShipNo:this.updateDialogForm.SealShipNo,
        InternalShipNo:this.updateDialogForm.InternalShipNo,
        RegionId:this.updateDialogForm.SelectedRegionId,
      }
      UpdateShip(params).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
        this.updateDialogVisible = false
      })
    },
    getItemStatusDisplayText({shipStatus}){
      const arr = ['计划装柜','装柜中','装柜完成']
      return arr[shipStatus]
    },
    onHandleBatchPutting(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      Putting(ids).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        if(res.data.content != 1){
          if(res.data.content != 2){
            this.openAlert(res.data.content)
            return
          }else{
            this.openAlert('请填写完整信息之后再执行该操作！')
            return
          }
        }
        this.getTableData()
      })
    },
    onHandleBatchPutFinish(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      IsFinishShip(ids).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        if(res.data.content != 1){
          if(res.data.content != 2){
            this.openAlert(res.data.content)
            return
          }
          this.openAlert('存在未检测通过的包裹！是否强制执行？',"提示",callback => {
            PutFinish(ids).then(res => {
              if(res.data.code != 200){
                this.$message.error(res.data.message)
                return
              }
              if(res.data.content != 1){
                if(res.data.content != 2){
                  this.openAlert(res.data.content)
                  return
                }else{
                  this.openAlert('请填写完整信息之后再执行该操作！')
                  return
                }
              }
              this.$message.success(res.data.message)
              this.getTableData()
            })
          })
        }else{
          PutFinish(ids).then(res => {
            if(res.data.code != 200){
              this.$message.error(res.data.message)
              return
            }
            if(res.data.content != 1){
              if(res.data.content != 2){
                this.openAlert(res.data.content)
                return
              }else{
                this.openAlert('请填写完整信息之后再执行该操作！')
                return
              }
            }
            this.$message.success(res.data.message)
            this.getTableData()
          })
        }
      })
    },
    openAlert(message,title = '提示',callback){
      this.$alert(message,title,{
          confirmButtonText: '确定',
          callback:callback,
      });
    }
  }
}
</script>
<style scoped>
.create-ship-button{
  float:left;
  margin-bottom:8px;
}
.bottom-left-button-group{
  float:left;
  margin-top:10px;
}
.ship-create-list-pagination{
  margin-top:10px;
}
.updateDialogForm-input-control{
  width:200px;
}
</style>
