<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-目的港库存</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user">
      <el-row>
        <el-row class="tool-bar">
          <div style="font-size:20px;color:red;font-weight:bold">
            库存体积:
            <el-tag type="danger" style="font-size:20px;color:red">{{TotalVolume}}</el-tag>
          </div>
        </el-row>
        <el-row class="tool-bar">
          <div style="font-size:20px;color:red;font-weight:bold">
            库存重量:
            <el-tag type="danger" style="font-size:20px;color:red">{{TotalWeight}}</el-tag>
          </div>
        </el-row>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedMerchandiseType" placeholder="选择类型">
          <el-option v-for="item in toShowMerchandiseTypeList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedUserId" placeholder="选择会员">
          <el-option
            v-for="item in toShowUserList"
            :key="item.key"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-row>
      <!--  -->
      <el-row class="tool-bar">
        <el-select v-model="selectedRouteId" placeholder="选择航线">
          <el-option v-for="item in toShowRouteList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedShipNo" placeholder="选择船次">
          <el-option v-for="item in toShowShipNoList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <!--  -->
      <el-row class="tool-bar">
        <el-select v-model="selectedRegionId" placeholder="选择地区">
          <el-option
            v-for="item in toShowRegionList"
            :key="item.key"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedMerchandise" placeholder="选择货物">
          <el-option v-for="item in toShowMerchandiseList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedMerchandise1" placeholder="选择货物">
          <el-option v-for="item in toShowMerchandiseList1"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-input v-model="ExpressNo" placeholder="请输入运输单号" clearable/>
      </el-row>
      <el-row class="tool-bar">
        <el-input v-model="Mark" placeholder="请输入唛头" clearable/>
        <div style="margin-left:10px;">
          <el-button type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>
          <el-button type="primary" icon="el-icon-help" @click="onHandleToExcel()">导出</el-button>
          <el-button type="warning" icon="el-icon-help" @click="onHandleSmallToExcel()">小包导出</el-button>
        </div>
      </el-row>
      <el-row style="margin-top:10px">
        <el-table id="toExportTable" border ref="multipleTable" tooltip-effect="dark"
            @selection-change="handleSelectionChange" style="width: 100%"
            :data="dataTable" :row-class-name="tableRowClassName">
            <el-table-column type="selection"width="50"/>
            <el-table-column prop="itemType" label="类型">
              <template slot-scope="scope">
                <span>{{getItemTypeDisplayText(scope.row)}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="expressNumber" label="运输单号" width="180"/>
            <el-table-column prop="mark" label="唛头"/>
            <el-table-column prop="userDisplay" label="会员"/>
            <el-table-column prop="containerNumber" label="柜号"/>
            <el-table-column prop="deliveryAddress" label="派送地区"/>
            <el-table-column prop="address" label="地址"/>
            <el-table-column prop="itemCount" label="件数"/>
            <el-table-column prop="weight" label="重量"/>
            <el-table-column prop="-" label="S/体积"/>
            <el-table-column prop="itemName" label="品名" width='120' :show-overflow-tooltip='true'/>
            <el-table-column prop="-" label="派送"/>
            <el-table-column
             fixed="right"
             label="操作"
             width='auto'>
             <template slot-scope="scope">
               <el-row>
                <el-button type="text" @click="deliveryOrderClick(scope.row)">派送单</el-button>
              </el-row>
             </template>
           </el-table-column>
        </el-table>
      </el-row>
      <el-row style="margin-top:20px;width:100%;display:inline-flex">
        <div style="width:100%;display:inline-flex">
          <el-button type="danger" icon="el-icon-help" @click="onHandleSignDone()">签收完成</el-button>&nbsp
          <el-button type="success" icon="el-icon-help" @click="onHandlePickupMerchandise()">第三方提货</el-button>&nbsp
          <el-button type="primary" icon="el-icon-help" @click="onHandleRouteDeliveryAddress()">线路派送地区处理</el-button>
        </div>
        <div style="float:right">
            <el-pagination background layout="prev, pager,next,total,jumper"
             :total="pagination.totalCount" :page-count="pagination.totalPage"
             :current-page="pagination.pageNo" @current-change="pageNoChange"/>
        </div>
      </el-row>
      <el-dialog
        title="提示"
        :visible.sync="deliveryOrderDialogVisible"
        width="50%">
        <div ref="toPrintArea">
          <PrintArea v-model="printAreaData"/>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button type="danger" @click="onHandlePrint()">打印</el-button>
          <el-button type="success" @click="deliveryOrderDialogVisible = false">确定</el-button>
        </span>
      </el-dialog>
      <el-dialog
        title="路线派送地区"
        width="600px"
        :visible.sync="routeDeliveryAddressVisible">
        <el-form id="custom_form" class="OpenOrderForm"
         label-width="auto" :model="RuleForm"
         :rules="FormRules" ref="RuleForm">
          <el-form-item label="派送地区" prop="DeliveryAddressValue">
            <el-cascader
              v-model="RuleForm.DeliveryAddressValue"
              :options="DeliveryAddressOptions"/>
          </el-form-item>
          <el-form-item label="备注" prop="DeliveryAddressRemark">
            <el-input type="textarea" style="margin-top:5px" :rows="2" v-model="RuleForm.DeliveryAddressRemark"/>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="onSubmitDeliveryRouteAddress">提交</el-button>
        </span>
      </el-dialog>
    </div>
  </el-card>
</template>
<script>
import { getTransitGatherPrintParams } from '@/api/services/packageTransitService'
import PrintArea from '@/views/components/PrintArea'
import { GetUsers,GetRoutes,GetShipNos,GetRegionList,GetDeliveryRegionDropdownList } from '@/api/services/packageLookupService'
import { GetMerchandiseStorageListExtraParams,GetDestKongStorageList
} from '@/api/services/merchandiseService'
import { DestKongSign,PickupMerchandise,DeliveryRegionProcess,
  SmallExportToExcel,ExportToExcel } from '@/api/services/merchandiseDestKongService'
import FileSaver from 'file-saver'
import XLSX from 'xlsx'
import print from 'print-js'
import { jsonToQueryParams } from '@/utils/convertUtil'

export default {
  name: 'MerchandiseDestKongStoreList',
  components:{
    PrintArea
  },
  data(){
    return {
      uploadHeaders:{
        Authorization : 'Bearer' + ' ' + localStorage.getItem('TOKEN'),
      },
      dataTable:[],
      multipleSelection: [],
      pagination:{
        pageNo:1,       // 当前页
        pageSize:8,     // 当前页数量
        totalPage:2,    // 总页数
        totalCount:10,   // 总条数
      },
      selectedMerchandiseType:-1,
      toShowMerchandiseTypeList:[
        {
          key:-1,
          value:-1,
          label:'选择类型'
        },
        {
          key:0,
          value:0,
          label:'TT'
        },
        {
          key:1,
          value:1,
          label:'JJ'
        },
        {
          key:2,
          value:2,
          label:'A'
        },
        {
          key:3,
          value:3,
          label:'B'
        },
        {
          key:4,
          value:4,
          label:'C'
        },
        {
          key:5,
          value:5,
          label:'F'
        },
        {
          key:6,
          value:6,
          label:'M'
        },
        {
          key:7,
          value:7,
          label:'MT'
        },
        {
          key:8,
          value:8,
          label:'MF'
        },
      ],
      selectedBalanceStatus:-1,
      toShowBalanceStatusList:[
        {
          key:-1,
          value:-1,
          label:'所有'
        },
        {
          key:0,
          value:0,
          label:'待结算'
        },
        {
          key:1,
          value:1,
          label:'已导出账单'
        },
        {
          key:2,
          value:2,
          label:'结算完成'
        },
        {
          key:3,
          value:3,
          label:'未付款'
        }
      ],
      selectedMerchandise:-1,
      toShowMerchandiseList:[
        {
          key:-1,
          value:-1,
          label:'所有货物'
        },
        {
          key:0,
          value:0,
          label:'未分配',
        },
        {
          key:1,
          value:1,
          label:'已分配',
        },
      ],
      selectedMerchandise1:-1,
      toShowMerchandiseList1:[
        {
          key:-1,
          value:-1,
          label:'所有货物'
        },
        {
          key:0,
          value:0,
          label:'扣货',
        }
      ],
      selectedShipNo:-1,
      toShowShipNoList:[
        {
          key:-1,
          value:-1,
          label:'选择船次'
        },
      ],
      selectedUserId:-1,
      selectedRegionId:-1,
      toShowRegionList:[],
      toShowUserList:[
        {
          key:-1,
          value:-1,
          label:'选择会员'
        },
      ],
      selectedRouteId:-1,
      toShowRouteList:[],
      ExpressNo:'',
      Mark:'',
      dialogRuleVisible:false,
      dialogUploadVisible:false,
      deliveryOrderDialogVisible:false,
      routeDeliveryAddressVisible:false,
      TotalVolume:0,
      TotalWeight:0,
      startTime:'',
      endTime:'',
      printAreaData:{},
      DeliveryAddressRemark:'',
      DeliveryAddressOptions:[],
      RuleForm: {
        DeliveryAddressValue:'',
        DeliveryAddressRemark:''
      },
      FormRules: {
        DeliveryAddressValue:{ required: true, message: '请选择派送地区', trigger: 'change' },
        DeliveryAddressRemark:{ required: true, message: '请输入备注', trigger:['change','blur'] },
      }
    }
  },
  created(){
    GetUsers().then(res => {
      res.data.forEach((item, i) => {
        this.toShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRoutes().then(res => {
      this.toShowRouteList = []
      this.toShowRouteList.push({
        key:-1,
        value:-1,
        label:'选择航线'
      })
      res.data.forEach((item, i) => {
        this.toShowRouteList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRegionList().then(res => {
      this.toShowRegionList = []
      this.toShowRegionList.push({
        key:-1,
        value:-1,
        label:'选择地区'
      })
      res.data.forEach((item, i) => {
        this.toShowRegionList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetShipNos().then(res => {
      res.data.forEach((item, i) => {
        this.toShowShipNoList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetDeliveryRegionDropdownList().then(res => {
      this.DeliveryAddressOptions = res.data
    })
    GetMerchandiseStorageListExtraParams({
      type:'destKong'
    }).then(res => {
      this.TotalVolume = res.data.totalVolume
      this.TotalWeight = res.data.totalWeight
    })
    this.getTableData()
  },
  methods:{
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    async getTableData(){
      var params = {
        ItemType:this.selectedMerchandiseType,
        UserId:this.selectedUserId,
        RouteId:this.selectedRouteId,
        ShipNo:this.selectedShipNo,
        RegionId:this.selectedRegionId,
        DeliveryStatus:this.selectedMerchandise,
        ExpressNo:this.ExpressNo,
        Mark:this.Mark,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['ShipNo'] == -1){
        delete params['ShipNo']
      }
      if(params['RegionId'] == -1){
        delete params['RegionId']
      }
      if(params['DeliveryStatus'] == -1){
        delete params['DeliveryStatus']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      GetDestKongStorageList(params).then(res => {
        this.dataTable = res.data.collection
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    deliveryOrderClick({id}){
      getTransitGatherPrintParams({
        id:id
      }).then(res => {
        this.printAreaData = res.data.content
        if(this.printAreaData.package != null){
          this.deliveryOrderDialogVisible = true
        }else{
          this.$message({type:'info',message:'没有包裹相关信息'})
        }
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    getItemTypeDisplayText({itemType}){
      var ele = this.toShowMerchandiseTypeList.find(x => x.value == itemType)
      return ele != null ? ele.label : ''
    },
    getPackingTypeDisplayText({packingType}){
      const list = [
        '-','纸箱','编织袋','木架','裸装','重货','超长','塑料桶','托盘'
      ]
      return list[packingType]
    },
    onHandleRouteDeliveryAddress(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message({type:'error',message:'请先选择欲提货项!'})
        return
      }
      this.routeDeliveryAddressVisible = true
    },
    onHandleSignDone(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message({type:'error',message:'请先选择欲签收项!'})
        return
      }
      this.openConfirm('是否确定客户已经自提完成？',() => {
        DestKongSign(ids).then(res => {
          if(res.status == 200){
            this.$message({type:'success',message:'操作成功!'})
            this.getTableData();
          }else{
            this.$message({type:'error',message:'操作失败!'})
          }
        })
      })
    },
    onHandlePickupMerchandise(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message({type:'error',message:'请先选择欲提货项!'})
        return
      }
      this.openConfirm('是否确认要把状态强制更改成[第三方提货]，该操作不可逆,请谨慎操作！',() => {
        PickupMerchandise(ids).then(res => {
          if(res.status == 200){
            this.$message({type:'success',message:'操作成功!'})
            this.getTableData();
          }else{
            this.$message({type:'error',message:'操作失败!'})
          }
        })
      })
    },
    onSubmitDeliveryRouteAddress(){
      this.$refs['RuleForm'].validate((valid) => {
        if(!valid){
          console.log('error submit!!');
          return false;
        }
        this.routeDeliveryAddressVisible = false
        var ids = []
        this.multipleSelection.forEach((item,i) => {
          ids.push(item.id)
        });
        if(ids.length < 1){
          this.$message({type:'error',message:'请先选择欲提货项!'})
          return
        }
        const param = {
          packageIds:ids,
          regionId:this.RuleForm.DeliveryAddressValue.shift(),
          remark:this.RuleForm.DeliveryAddressRemark,
        }
        console.log(`param: ${JSON.stringify(param)}`)
        DeliveryRegionProcess(param).then(res => {
          if(res.status == 200){
            this.$message({type:'success',message:'操作成功!'})
            this.getTableData();
            this.$refs['RuleForm'].resetFields()
          }else{
            this.$message({type:'error',message:'操作失败!'})
          }
        })
      })
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    },
    onHandleToExcel(){
      var params = {
        ItemType:this.selectedMerchandiseType,
        UserId:this.selectedUserId,
        RouteId:this.selectedRouteId,
        ShipNo:this.selectedShipNo,
        RegionId:this.selectedRegionId,
        DeliveryStatus:this.selectedMerchandise,
        ExpressNo:this.ExpressNo,
        Mark:this.Mark,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['ShipNo'] == -1){
        delete params['ShipNo']
      }
      if(params['RegionId'] == -1){
        delete params['RegionId']
      }
      if(params['DeliveryStatus'] == -1){
        delete params['DeliveryStatus']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      var encodeUrl = '?' + jsonToQueryParams(params)
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/PackageDestKongStorage/ExportToExcel' + encodeUrl;
      link.click();
    },
    onHandleSmallToExcel(){
      var params = {
        ItemType:this.selectedMerchandiseType,
        UserId:this.selectedUserId,
        RouteId:this.selectedRouteId,
        ShipNo:this.selectedShipNo,
        RegionId:this.selectedRegionId,
        DeliveryStatus:this.selectedMerchandise,
        ExpressNo:this.ExpressNo,
        Mark:this.Mark,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['ShipNo'] == -1){
        delete params['ShipNo']
      }
      if(params['RegionId'] == -1){
        delete params['RegionId']
      }
      if(params['DeliveryStatus'] == -1){
        delete params['DeliveryStatus']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      var encodeUrl = '?' + jsonToQueryParams(params)
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/PackageDestKongStorage/SmallBagExportToExcel' + encodeUrl;
      link.click();
    },
    onHandlePrint(){
      let newstr = this.$refs.toPrintArea.innerHTML;
      let newWindow = window.open('','');
      newWindow.document.write(newstr);
      newWindow.window.print();
      newWindow.window.close();
    }
  }
}
</script>
<style scoped>
.tool-bar{
  margin-right:5px;
  margin-top:15px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
</style>
