<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>小包-预报</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user">
      <el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedVipParams" placeholder="会员选择">
            <el-option
              v-for="item in filterParams.vipParams"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-select v-model="selectedRoutes" placeholder="航线选择">
            <el-option
              v-for="item in filterParams.routes"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-row>
        <el-row class="tool-bar">
          <el-input v-model="toSearchExpressNumber" placeholder="请输入面单号" clearable/>&nbsp
          <el-button class="btnSearch" type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>&nbsp
          <el-button class="btnSearch" type="primary" icon="el-icon-circle-plus" @click="onHandleToStoreImport()">预入库导入</el-button>
        </el-row>
      </el-row>
        <el-row style="margin-top:10px">
            <el-col>
                <el-table border ref="multipleTable" tooltip-effect="dark"
                    @selection-change="handleSelectionChange" style="width: 100%"
                    :data="dataTable" :row-class-name="tableRowClassName">
                    <el-table-column type="selection"width="50"/>
                    <el-table-column prop="expressNumber" label="运输单号" width="180"/>
                    <el-table-column prop="mark" label="唛头"/>
                    <el-table-column prop="address" label="地址">
                      <template slot-scope="scope">
                        <el-button type="text" v-if="scope.row.recipientAddress == null" @click="onHandleShowDetailAddress(scope.row)">未知</el-button>
                        <el-button type="text" v-else-if="scope.row.recipientAddress != null" @click="onHandleShowDetailAddress(scope.row)">{{scope.row.recipientAddress}}</el-button>
                      </template>
                    </el-table-column>
                    <el-table-column prop="userDisplay" label="会员编号"/>
                    <el-table-column prop="itemCount" label="件数"/>
                    <el-table-column prop="weight" label="重量"/>
                    <el-table-column prop="regionDisplay" label="地区"/>
                    <el-table-column prop="volume" label="S/体积"/>
                    <el-table-column prop="itemName" label="品名"/>
                    <el-table-column prop="statusDisplay" label="货物状态"/>
                    <el-table-column prop="itemType" label="类型">
                      <template slot-scope="scope">
                        <el-row>
                          <span>{{getItemTypeDisplayText(scope.row)}}</span>
                        </el-row>
                      </template>
                    </el-table-column>
                    <el-table-column prop="-" label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" icon="el-icon-printer" @click="onHandlePrintLabel(scope.row)">打印标签</el-button>
                      </template>
                    </el-table-column>
                </el-table>
                <div style="width:100%;inline-flex;margin-top:15px">
                  <el-button @click="batchDelete()">批量删除</el-button>
                  <div style="float:right">
                    <el-pagination background layout="prev, pager,next,total,jumper"
                     :total="pagination.totalCount" :page-count="pagination.totalPage"
                     :current-page="pagination.pageNo"
                     @current-change="pageNoChange"/>
                  </div>
                </div>
            </el-col>
        </el-row>
        <el-dialog title="预入库导入" width="80%" :close-on-click-modal="false" :visible.sync="ToStoreImportDialog.Visible">
          <div class="dialog-body">
            <div style="display:flex;align-items:center;margin-top:10px">
              <el-button-group style="display:flex">
                <el-button type="primary" icon="el-icon-download" @click="onHandleDownloadTemplate()">下载模板</el-button>&nbsp
                <el-upload
                   class="upload-demo"
                   ref="upload"
                   :headers="uploadHeaders"
                   :limit="10" multiple
                   accept=".xlsx,.xls,.xlsm"
                   :action="ImportLink"
                   :on-change="onHandleUploadChange"
                   :on-success="onHandleUploadSuccess"
                   :show-file-list="false"
                   :auto-upload="true">
                   <el-button slot="trigger" type="primary" icon="el-icon-upload">批量导入</el-button>
                 </el-upload>
              </el-button-group>
              <span style="color:red;margin-left:15px;font-weight:800">*请严格按照要求填写资料*</span>
            </div>
            <div style="white-space:nowrap;margin-top:10px;margin-top:10px">
              <el-table border ref="ImportTableRef" tooltip-effect="dark" style="width:100%;margin-top:10px"
                  :data="ToStoreImportDialog.DataTable" :row-class-name="tableRowClassName">
                  <el-table-column prop="mark" label="唛头" />
                  <el-table-column prop="userName" label="会员名" />
                  <el-table-column prop="itemName" label="品名" />
                  <el-table-column prop="route" label="航线" />
                  <el-table-column prop="itemCount" label="件数" />
                  <el-table-column prop="senderName" label="发货人" />
                  <el-table-column prop="senderTelephone" label="发货人电话" />
                  <el-table-column prop="remark" label="备注" />
                  <el-table-column prop="recipientName" label="收件人" />
                  <el-table-column prop="recipientTelephone" label="联系电话" />
                  <el-table-column prop="recipientPostcode" label="邮编" />
                  <el-table-column prop="recipientAddress" label="派送地址" />
              </el-table>
            </div>
          </div>
        </el-dialog>
        <el-dialog
          title=""
          :visible.sync="showDetailAddressDialogVisible"
          width="20%">
          <div>
            <el-row>
                <span>流水号:</span>
                <span>{{this.showDetailAddressDialogValues.expressNumber}}</span>
            </el-row>
            <el-row style="margin-top:10px">
                <span>唛头:</span>
                <span>{{this.showDetailAddressDialogValues.mark}}</span>
            </el-row>
            <el-row style="margin-top:10px">
                <span>收件人:</span>
                <span>{{this.showDetailAddressDialogValues.recipientName}}</span>
            </el-row>
            <el-row style="margin-top:10px">
                <span>公司:</span>
                <span>{{this.showDetailAddressDialogValues.recipentCompanyName}}</span>
            </el-row>
            <el-row style="margin-top:10px">
                <span>联系电话:</span>
                <span>{{this.showDetailAddressDialogValues.recipientTelephone}}</span>
            </el-row>
            <el-row style="margin-top:10px">
                <span>邮编:</span>
                <span>{{this.showDetailAddressDialogValues.recipientPostcode}}</span>
            </el-row>
            <el-row style="margin-top:10px">
                <span>派送地址:</span>
                <span>{{this.showDetailAddressDialogValues.deliveryAddress}}</span>
            </el-row>
          </div>
          <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="showDetailAddressDialogVisible = false">确定</el-button>
          </span>
        </el-dialog>
    </div>
  </el-card>
</template>

<script>
import { getSmallExpectStorageList,BatchDeleteExpectData } from '@/api/services/merchandiseService'
import { GetUsers,GetRoutes } from '@/api/services/packageLookupService'
export default {
  name: 'SmallBagStoring',
  data(){
      return {
          dataTable:[],
          ImportLink:process.env.BASE_URL + '/api/PackageExpectStore/BatchImportSmallBag',
          multipleSelection: [],
          pagination:{
            pageNo:1,       // 当前页
            pageSize:8,     // 当前页数量
            totalPage:1,    // 总页数
            totalCount:1,   // 总条数
          },
          filterParams:{
            vipParams:[],             // 会员
            routes:[],                // 航线
          },
          uploadHeaders:{
            Authorization : 'Bearer' + ' ' + localStorage.getItem('TOKEN'),
          },
          ToStoreImportDialog:{
            Visible:false
          },
          selectedVipParams:'',
          selectedRoutes:'',
          toShowMerchandiseTypeList:[
            {
              key:-1,
              value:-1,
              label:'所有'
            },
            {
              key:0,
              value:0,
              label:'TT'
            },
            {
              key:1,
              value:1,
              label:'JJ'
            },
            {
              key:2,
              value:2,
              label:'A'
            },
            {
              key:3,
              value:3,
              label:'B'
            },
            {
              key:4,
              value:4,
              label:'C'
            },
            {
              key:5,
              value:5,
              label:'F'
            },
            {
              key:6,
              value:6,
              label:'M'
            },
            {
              key:7,
              value:7,
              label:'MT'
            },
            {
              key:8,
              value:8,
              label:'MF'
            }
          ],
          toSearchExpressNumber:'',
          showDetailAddressDialogVisible:false,
          showDetailAddressDialogValues:{},
      }
  },
  created(){
    this.getTableData()
    GetUsers().then(res => {
      this.filterParams.vipParams.push({
        key:-1,
        value:-1,
        label:'选择会员'
      })
      res.data.forEach((item, i) => {
        this.filterParams.vipParams.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      })
    });
    GetRoutes().then(res => {
      this.filterParams.routes = []
      this.filterParams.routes.push({
        key:-1,
        value:-1,
        label:'选择航线'
      })
      res.data.forEach((item, i) => {
        this.filterParams.routes.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
  },
  methods:{
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    onHandleShowDetailAddress(values){
      this.showDetailAddressDialogVisible = true
      this.showDetailAddressDialogValues = values
    },
    getItemTypeDisplayText({itemType}){
      var ele = this.toShowMerchandiseTypeList.find(x => x.value == itemType)
      return ele.label
    },
    onHandlePrintLabel({id}){
      this.$router.push('/MerchandisePackageAdd?id=' + id)
    },
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    async getTableData(){
      var params = {
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
        UserId:this.selectedVipParams.toString().length > 0 ? this.selectedVipParams : -1,
        RouteId:this.selectedRoutes.toString().length > 0 ? this.selectedRoutes : -1,
        Keyword:this.toSearchExpressNumber.toString().length > 0 ? this.toSearchExpressNumber : ""
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['Keyword'] == ''){
        delete params['Keyword']
      }
      getSmallExpectStorageList(params).then(res => {
        this.dataTable = res.data.collection
        this.pagination.pageNo = res.data.pageNo
        this.pagination.pageSize = res.data.pageSize
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
      })
    },
    onHandleToStoreImport(){
      this.ToStoreImportDialog.Visible = true
      this.ToStoreImportDialog.DataTable = []
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    handleSelectionChange(val) {
        this.multipleSelection = val;
    },
    batchDelete(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      this.openConfirm('确认删除吗?',callback => {
        BatchDeleteExpectData(ids).then(res => {
          if(res.data.code != 200){
            this.$message.error(res.data.message)
            return
          }
          this.getTableData()
        })
      })
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    },
    onHandleUploadChange(file,fileList){
      //console.log(`file: ${JSON.stringify(file)},fileList: ${JSON.stringify(fileList)}`)
    },
    onHandleUploadSuccess(response, file, fileList){
      console.log(`response: ${JSON.stringify(response)}`)
      if(response.code != 200){
        this.$message.error(response.message)
        return
      }
      this.$message.success(response.message)
      this.ToStoreImportDialog.DataTable = response.content
      this.getTableData()
    },
    onHandleDownloadTemplate(){
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/PackageExpectStore/GetTemplateFile';
      link.click();
    }
  }
}

</script>

<style scoped>
.tool-bar{
  margin-right:5px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
.btnSearch{
  margin-left:10px;
}
</style>
