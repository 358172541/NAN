<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>Post机-拆柜检测</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
      <div style="width:300px">
        <el-input type="textarea" :rows="5" placeholder="请输入内容" v-model="InputData"/>
      </div>
      <div slot="footer" class="dialog-footer" style="margin-top:15px">
        <el-button @click="onHandleReset">重置</el-button>&nbsp
        <el-button type="primary" @click="onHandleSubmit()">提交</el-button>
      </div>
    </div>
  </el-card>
</template>
<script>
import { UnpackBoxSubmit } from '@/api/services/postService'
import { playAudio } from '@/utils/audio_util'

export default{
  name:'PostUnpackCheckList',
  data(){
    return{
      InputData:''
    }
  },
  methods:{
    onHandleReset(){
      this.InputData = ''
    },
    onHandleSubmit(){
      if(this.InputData == ''){
        this.$message.error("输入内容必填!")
        return
      }
      UnpackBoxSubmit({
        InputData:this.InputData
      }).then(res => {
        if(res.data.code != 200 || res.data.content != 1){
          this.$message.error(res.data.message)
          playAudio('audios/5051.wav')
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
        this.DialogCheckDialog.Visible = false
      })
    }
  }
}
</script>
