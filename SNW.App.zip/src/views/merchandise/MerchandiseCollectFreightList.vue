<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-代收运费</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user">
      <el-row>
        <el-col :span="5" style="font-size:20px;color:red;font-weight:bold">
          代收:
          <el-tag type="danger" style="font-size:20px;color:red">{{TotalCollection}}</el-tag>&nbsp元
        </el-col>
        <el-col :span="5" style="font-size:20px;color:red;font-weight:bold">
          代付:
          <el-tag type="danger" style="font-size:20px;color:red">{{TotalPayOnBehalf}}</el-tag>&nbsp元
        </el-col>
      </el-row>
      <el-row class="tool-bar">
        货物类型:&nbsp
        <el-select v-model="selectedMerchandiseType" placeholder="选择类型">
          <el-option v-for="item in toShowMerchandiseTypeList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        会员:&nbsp&nbsp
        <el-select v-model="selectedUserId" placeholder="选择会员">
          <el-option
            v-for="item in toShowUserList"
            :key="item.key"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-row>
      <!--  -->
      <el-row class="tool-bar">
        航线:&nbsp
        <el-select v-model="selectedRouteId" placeholder="状态">
          <el-option v-for="item in toShowRouteList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        船次:&nbsp
        <el-select v-model="selectedShipNo" placeholder="状态">
          <el-option v-for="item in toShowShipNoList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <!--  -->
      <el-row class="tool-bar">
        <el-select v-model="selectedStatus1" placeholder="所有状态">
          <el-option v-for="item in toShowStatus1List"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedStatus2" placeholder="所有">
          <el-option v-for="item in toShowStatus2List"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-date-picker
          v-model="startDate"
          type="date"
          placement="bottom-start"
          placeholder="开始时间">
        </el-date-picker>
      </el-row>
      <el-row class="tool-bar">
        <el-date-picker
          v-model="endDate"
          type="date"
          placement="bottom-start"
          placeholder="结束时间">
        </el-date-picker>
      </el-row>
      <el-row class="tool-bar">
        单号:&nbsp&nbsp
        <el-input v-model="ExpressNo" placeholder="请输入运输单号" clearable/>
      </el-row>
      <el-row class="tool-bar">
        唛头:&nbsp&nbsp
        <el-input v-model="Mark" placeholder="请输入唛头" clearable/>
        <div style="margin-left:10px;">
          <el-button type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>
          <el-button type="primary" icon="el-icon-help" @click="onHandleExport()">导出</el-button>
        </div>
      </el-row>
      <el-row style="margin-top:10px">
        <el-table border ref="multipleTable" tooltip-effect="dark"
            @selection-change="handleSelectionChange" style="width: 100%"
            :data="dataTable" :row-class-name="tableRowClassName">
            <el-table-column type="selection"width="50"/>
            <el-table-column prop="itemType" label="类型">
              <template slot-scope="scope">
                <span>{{getItemTypeDisplayText(scope.row)}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="expressNumber" label="运输单号" width="180"/>
            <el-table-column prop="mark" label="唛头"/>
            <el-table-column prop="userDisplay" label="会员编号"/>
            <el-table-column prop="containerName" label="柜号"/>
            <el-table-column prop="routeName" label="航线"/>
            <el-table-column prop="collection" label="代收"/>
            <el-table-column prop="customerConfirmedVolume" label="代付"/>
            <el-table-column prop="itemCount" label="件数"/>
            <el-table-column prop="weight" label="重量"/>
            <el-table-column prop="-" label="S/体积"/>
            <el-table-column prop="itemName" label="品名" width='120' :show-overflow-tooltip='true'/>
            <!-- <el-table-column prop="isPrinted" label="是否打印">
              <template slot-scope="scope">
                <el-tag type="success" v-if="scope.row.isPrinted">已打印</el-tag>
                <el-tag type="danger" v-else-if="scope.row.isPrinted == false">未打印</el-tag>
              </template>
            </el-table-column> -->
            <el-table-column
             fixed="right"
             label="操作"
             width='auto'>
             <template slot-scope="scope">
               <el-row>
                <el-button type="text" @click="printOrderClick(scope.row)">打印账单</el-button>
              </el-row>
             </template>
           </el-table-column>
        </el-table>
      </el-row>
      <div style="margin-top:20px;width:100%;display:inline-flex">
        <el-button-group style="width:100%">
          <el-button type="primary" dashed @click="onHandleProcDone">处理完成</el-button>
          &nbsp&nbsp&nbsp
          <el-button type="primary" @click="onHandleMatchBillDone">对账完成</el-button>
          &nbsp&nbsp&nbsp
          <el-button type="primary" @click="onHandleCanbeShipped">可出货</el-button>
        </el-button-group>
        <div style="float:right">
            <el-pagination background layout="prev, pager,next,total,jumper"
             :total="pagination.totalCount" :page-count="pagination.totalPage"
             :current-page="pagination.pageNo" @current-change="pageNoChange"/>
        </div>
      </div>
      <el-dialog
        title="提示"
        :visible.sync="printOrderDialogVisible"
        width="50%">
        <div id="toPrintArea">
          <BillPrintArea v-model="printAreaData"/>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button type="danger" @click="onHandlePrintBill()">打印</el-button>
          <el-button type="success" @click="printOrderDialogVisible = false">确定</el-button>
        </span>
      </el-dialog>
    </div>
  </el-card>
</template>
<script>
import { getTransitGatherPrintParams } from '@/api/services/packageTransitService'
import BillPrintArea from '@/views/components/BillPrintArea'
import { GetUsers,GetRoutes,GetShipNos,GetRegionList } from '@/api/services/packageLookupService'
import { GetMerchandiseSettlementList,
  GetPackageListExtraParam,GetCollectionPackageList
} from '@/api/services/merchandiseService'
import { ProcDone,MatchBillDone,CanBeShipped } from '@/api/services/packageCollectionService'
import { jsonToQueryParams } from '@/utils/convertUtil'
import printJs from 'print-js'

export default {
  name: 'MerchandiseCollectFreightList',
  components:{
    BillPrintArea
  },
  data(){
    return {
      uploadHeaders:{
        Authorization : 'Bearer' + ' ' + localStorage.getItem('TOKEN'),
      },
      dataTable:[],
      multipleSelection: [],
      pagination:{
        pageNo:1,       // 当前页
        pageSize:8,     // 当前页数量
        totalPage:2,    // 总页数
        totalCount:10,   // 总条数
      },
      selectedMerchandiseType:-1,
      toShowMerchandiseTypeList:[
        {
          key:-1,
          value:-1,
          label:'选择类型'
        },
        {
          key:0,
          value:0,
          label:'TT'
        },
        {
          key:1,
          value:1,
          label:'JJ'
        },
        {
          key:2,
          value:2,
          label:'A'
        },
        {
          key:3,
          value:3,
          label:'B'
        },
        {
          key:4,
          value:4,
          label:'C'
        },
        {
          key:5,
          value:5,
          label:'F'
        },
        {
          key:6,
          value:6,
          label:'M'
        },
        {
          key:7,
          value:7,
          label:'MT'
        },
        {
          key:8,
          value:8,
          label:'MF'
        },
      ],
      selectedBalanceStatus:-1,
      toShowBalanceStatusList:[
        {
          key:-1,
          value:-1,
          label:'所有'
        },
        {
          key:0,
          value:0,
          label:'待结算'
        },
        {
          key:1,
          value:1,
          label:'已导出账单'
        },
        {
          key:2,
          value:2,
          label:'结算完成'
        },
        {
          key:3,
          value:3,
          label:'未付款'
        }
      ],
      selectedRouteId:-1,
      toShowRouteList:[],
      selectedStatus1:-1,
      toShowStatus1List:[
        {
          key:-1,
          value:-1,
          label:'所有状态'
        },
        {
          key:0,
          value:0,
          label:'未处理',
        },
        {
          key:1,
          value:1,
          label:'已处理',
        },
        {
          key:3,
          value:3,
          label:'可出货',
        },
      ],
      selectedStatus2:0,
      toShowStatus2List:[
        {
          key:0,
          value:0,
          label:'所有'
        },
        {
          key:1,
          value:1,
          label:'客户备注',
        },
        {
          key:2,
          value:2,
          label:'管理备注',
        },
        {
          key:3,
          value:3,
          label:'代付',
        },
        {
          key:4,
          value:4,
          label:'代收',
        },
      ],
      selectedShipNo:-1,
      toShowShipNoList:[
        {
          key:-1,
          value:-1,
          label:'选择船次'
        },
      ],
      selectedUserId:-1,
      toShowUserList:[
        {
          key:-1,
          value:-1,
          label:'选择会员'
        },
      ],
      ExpressNo:'',
      Mark:'',
      dialogRuleVisible:false,
      dialogUploadVisible:false,
      printOrderDialogVisible:false,
      TotalCollection:0,
      TotalPayOnBehalf:0,
      startDate:'',
      endDate:'',
      printAreaData:{},
    }
  },
  created(){
    GetUsers().then(res => {
      res.data.forEach((item, i) => {
        this.toShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRoutes().then(res => {
      this.toShowRouteList = []
      this.toShowRouteList.push({
        key:-1,
        value:-1,
        label:'选择航线'
      })
      res.data.forEach((item, i) => {
        this.toShowRouteList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetShipNos().then(res => {
      res.data.forEach((item, i) => {
        this.toShowShipNoList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetPackageListExtraParam().then(res => {
      this.TotalCollection = res.data.totalCollection
      this.TotalPayOnBehalf = res.data.totalPayOnBehalf
    })
    this.getTableData()
  },
  methods:{
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    async getTableData(){
      var params = {
        ItemType:this.selectedMerchandiseType,
        UserId:this.selectedUserId,
        RouteId:this.selectedRouteId,
        ShipNo:this.selectedShipNo,
        RegionId:this.selectedRegionId,
        DeliveryStatus:this.selectedMerchandise,
        ExpressNumber:this.ExpressNo,
        Mark:this.Mark,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['ShipNo'] == -1){
        delete params['ShipNo']
      }
      if(params['RegionId'] == -1){
        delete params['RegionId']
      }
      if(params['DeliveryStatus'] == -1){
        delete params['DeliveryStatus']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      GetCollectionPackageList(params).then(res => {
        this.dataTable = res.data.collection
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    printOrderClick({id}){
      this.printOrderDialogVisible = true
      getTransitGatherPrintParams({
        id:id
      }).then(res => {
        this.printAreaData = res.data.content
      })
    },
    handleSelectionChange(val){
      this.multipleSelection = val;
    },
    getItemTypeDisplayText({itemType}){
      var ele = this.toShowMerchandiseTypeList.find(x => x.value == itemType)
      return ele != null ? ele.label : ''
    },
    getPackingTypeDisplayText({packingType}){
      const list = [
        '-','纸箱','编织袋','木架','裸装','重货','超长','塑料桶','托盘'
      ]
      return list[packingType]
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    },
    onHandleProcDone(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲要操作的列表项!')
        return
      }
      ProcDone({
        ids:ids.join(',')
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
      })
    },
    onHandleMatchBillDone(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲要操作的列表项!')
        return
      }
      MatchBillDone({
        ids:ids.join(',')
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
      })
    },
    onHandleCanbeShipped(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择欲要操作的列表项!')
        return
      }
      CanBeShipped({
        ids:ids.join(',')
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
      })
    },
    onHandleExport(){
      var params = {
        ItemType:this.selectedMerchandiseType,
        UserId:this.selectedUserId,
        RouteId:this.selectedRouteId,
        ShipNo:this.selectedShipNo,
        RegionId:this.selectedRegionId,
        DeliveryStatus:this.selectedMerchandise,
        ExpressNumber:this.ExpressNo,
        Mark:this.Mark,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['ShipNo'] == -1){
        delete params['ShipNo']
      }
      if(params['RegionId'] == -1){
        delete params['RegionId']
      }
      if(params['DeliveryStatus'] == -1){
        delete params['DeliveryStatus']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      var encodeUrl = '?' + jsonToQueryParams(params)
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/v1/PackageCollection/Export' + encodeUrl;
      link.click();
    },
    onHandlePrintBill(){
      printJS({
          printable:'toPrintArea',
          type:'html',
      })
    }
  }
}
</script>
<style scoped>
.tool-bar{
  margin-right:5px;
  margin-top:15px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
</style>
