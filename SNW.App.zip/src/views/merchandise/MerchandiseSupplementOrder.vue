<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-补单</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="box-card-container">
      <el-form label-width="102px" :model="FormFields" ref="formField">
        <el-form-item label="运输单号：" prop="InputExpressNo" :rules="{required:true,message:'运输单号必填'}">
          <el-input placeholder="请输入运输单号" clearable
            v-model="FormFields.InputExpressNo" style="width:100%"/>
        </el-form-item>
        <el-form-item label="属于第几个：" prop="InputNum" :rules="{required:true,message:'数字必填'}">
          <el-input placeholder="请输入数字" clearable
            v-model="FormFields.InputNum" style="width:100%"
            type="number"/>
        </el-form-item>
      </el-form>
      <div style="margin-top:40px">
        <el-button type="primary" icon="el-icon-printer" @click="onHandlePrint">打印</el-button>&nbsp
        <el-button type="warning" icon="el-icon-refresh" @click="onHandleReset">重置</el-button>
      </div>
    </div>
  </el-card>
</template>
<script>
import { SupplementAndPrint } from '@/api/services/supplementOrderService'
import print from 'print-js'
import { mmToPx } from '@/utils/screen_util'

export default{
  name:'MerchandiseSupplementOrder',
  data(){
    return{
      FormFields:{
        InputExpressNo:'',
        InputNum:''
      }
    }
  },
  methods:{
    onHandlePrint(){
      this.$refs['formField'].validate((valid) => {
        if(!valid){
          this.$message.error('请检查欲提交的表单是否正确!')
          return
        }
        SupplementAndPrint({
          ExpressNo:this.FormFields.InputExpressNo,
          Num:this.FormFields.InputNum,
          LabelWidth:parseInt(mmToPx(100)),
          LabelHeight:parseInt(mmToPx(70)),
        }).then(res => {
          if(res.data.code != 200) {
            this.$message.error(res.data.message)
            return
          }
          printJS({
              printable: res.data.content,
              type: 'pdf',
              base64: true
          })
        })
      })
    },
    onHandleReset(){
      this.$refs['formField'].resetFields()
    }
  }
}
</script>
<style scoped>
.box-card-container{
  width:300px;
}
</style>
