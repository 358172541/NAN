<template>
    <el-card>
      <div slot="header" class="clearfix">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
          <el-breadcrumb-item>包裹签收</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div>
          <el-form id="custom_form" class="OpenOrderForm"
              label-width="auto"
              :model="ruleForm"
              :rules="rules"
              ref="ruleForm"
              style="width:350px">
              <el-form-item label="用户编号:" prop="UserId">
                  <el-select class="fw" v-model="ruleForm.UserId" style="width:100%">
                      <el-option v-for="item in ruleForm.params.users"
                                 :key="item.key"
                                 :label="item.label"
                                 :value="item.value">
                      </el-option>
                  </el-select>
              </el-form-item>
              <el-form-item label="快递列表:" prop="ExpressList">
                  <el-input type="textarea" style="width:100%"
                   :autosize="{ minRows: 5, maxRows: 10}"
                   v-model="ruleForm.ExpressList"/>
              </el-form-item>
              <el-form-item>
                  <el-button icon="el-icon-printer" type="primary" @click="onSubmit('ruleForm')">保存并打印</el-button>
              </el-form-item>
          </el-form>
      </div>
    </el-card>
</template>

<script>
import print from 'print-js'
import { mmToPx } from '@/utils/screen_util'
import { get_package_signing_filter_params,ScanPackageSigning } from '@/api/services/merchandiseService'
export default {
    name: 'PackagSign',
    data() {
        return {
            ruleForm: {
                UserId:'',
                ExpressList:'',
                params: {
                    users: [],
                },
            },
            rules: {
                UserId: [
                    { required: true, message: '请选择用户', trigger: ['blur', 'change'] },
                ],
                ExpressList: [
                    { required: true, message: '请输入快递列表', trigger: 'blur' },
                    { message: '请输入快递列表', trigger: ['blur', 'change'] }
                ],
            }
        }
    },
    created() {
        this.getParams()
    },
    methods: {
        async getParams() {
            get_package_signing_filter_params().then(res => {
              res.data.clients.forEach((item, i) => {
                this.ruleForm.params.users.push({
                    label: item.name,
                    value: item.id,
                    key:item.id,
                });
              });
            })
        },
        onSubmit(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                  console.log(`UserId: ${this.ruleForm.UserId},ExpressList: ${this.ruleForm.ExpressList}`)
                  const _params = {
                    userId:this.ruleForm.UserId,
                    width:parseInt(mmToPx(100)),
                    height:parseInt(mmToPx(70)),
                    packageMessage:this.ruleForm.ExpressList
                  }
                  if(this.ruleForm.UserId.toString().length < 1){
                    delete _params['userId']
                  }
                  ScanPackageSigning(_params).then(res => {
                    if(res.data.code != 200){
                      this.$message.error(res.data.message)
                      return;
                    }
                    this.$alert(res.data.message,'提示',{
                      confirmButtonText:'确定',
                      callback: action => {
                        var toPintPdfFle = res.data.content.toPintPdfFle
                        if(toPintPdfFle != null && toPintPdfFle.length > 1) {
                          printJS({
                            type: 'pdf',
                            base64: true,
                            printable:toPintPdfFle
                          })
                        }
                      }
                    });
                  })
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });
        },
        onReset(formName) {
            this.$refs[formName].resetFields();
        },
    }
}
</script>

<style scoped>
    .OpenOrderForm {
        white-space: nowrap;
        align-items: center;
    }
</style>
