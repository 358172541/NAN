<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-运输信息</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user">
      <el-row>
        <el-col style="display:flex;display:inline-flex;">
          <div class="col01" style="display:flex;display:grid;margin-right:5px;">
            <el-select v-model="selectedRouteId" placeholder="航线选择" style="margin-bottom:5px">
              <el-option v-for="item in toShowRouteList"
               :key='item.key' :label='item.label' :value='item.value'/>
            </el-select>
            <el-select v-model="selectedShipNo" placeholder="选择柜号">
              <el-option v-for="item in toShowShipNoList"
               :key='item.key' :label='item.label' :value='item.value'/>
            </el-select>
          </div>
          <div class="col02" style="display:flex;display:grid;margin-right:5px">
            <el-date-picker
              v-model="startTime"
              type="date"
              placement="bottom-start"
              style="margin-bottom:5px"
              placeholder="开始时间">
            </el-date-picker>
            <el-date-picker
              placement="bottom-start"
              v-model="endTime"
              type="date"
              placeholder="结束时间">
            </el-date-picker>
          </div>
          <div class="col03" style="display:flex;display:grid;margin-right:5px">
            <el-select v-model="selectedInfoStatus" placeholder="信息状态" style="margin-bottom:5px">
              <el-option v-for="item in toShowInfoStatusList"
               :key='item.key' :label='item.label' :value='item.value'/>
            </el-select>
            <el-select v-model="selectedShipCang" placeholder="订舱">
              <el-option v-for="item in toShowShipCangList"
               :key='item.key' :label='item.label' :value='item.value'/>
            </el-select>
          </div>
          <div class="col04" style="display:flex;display:grid;">
            <span style="margin-bottom:5px;align-self: self-end;">已走柜总计: {{TotalGoway}}</span>
            <el-input placeholder="船次编号" style="align-self:self-end" v-model="InputShipNo" clearable/>
          </div>
          <div class="col04" style="display:flex;display:grid;margin-left:5px">
            <el-input placeholder="清关人" style="align-self:self-end" v-model="InputClearance" clearable/>
          </div>
          <div class="col04" style="align-self:self-end;margin-left:5px">
            <el-button type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>
          </div>
        </el-col>
      </el-row>
      <el-row style="margin-top:10px">
        <el-table border ref="multipleTable" tooltip-effect="dark"
            @selection-change="handleSelectionChange" style="width: 100%"
            :data="dataTable" :row-class-name="tableRowClassName">
            <el-table-column type="selection" width="50"/>
            <el-table-column prop="shipNo" label="船次编号"/>
            <el-table-column prop="landTime" label="装柜时间" width="160px"/>
            <el-table-column prop="startTime" label="开船时间" width="160px"/>
            <el-table-column prop="receiveTime" label="到港时间" width="160px"/>
            <el-table-column prop="internalShipNo" label="内部柜号" width="120px"/>
            <el-table-column prop="sealShipNo" label="封条号" width="120px"/>
            <el-table-column prop="shipCompany" label="船运公司"/>
            <el-table-column prop="adjustDepartment" label="调柜部门"/>
            <el-table-column prop="clearance" label="清关部门"/>
            <el-table-column prop="code" label="检测">
              <template slot-scope="scope">
                <el-tag type="danger" v-if="scope.row.code != 1">未通过</el-tag>
                <el-tag type="success" v-else-if="scope.row.code == 1">已通过</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="code" label="重量/体积">
              <template slot-scope="scope">
                <div style="display:grid">
                  <span style="white-space:nowrap">总体积:{{scope.row.totalVolume}}</span>
                  <span style="white-space:nowrap">总重量:{{scope.row.totalWeight}}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="shipStatus" label="状态">
              <template slot-scope="scope">
                <el-tag type="primary" v-if="scope.row.shipStatus == 0">新建船次</el-tag>
                <el-tag type="warning" v-else-if="scope.row.shipStatus == 1">装柜中</el-tag>
                <el-tag type="success" v-else-if="scope.row.shipStatus == 2">装柜完成</el-tag>
                <el-tag type="success" v-else-if="scope.row.shipStatus == 3">处理完成</el-tag>
                <el-tag v-else>处理完成</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="sta" label="信息" width="100px">
              <template slot-scope="scope">
                <div v-if="scope.row.sta != null">
                  <span v-if="scope.row.sta == 9" style="color:red;font-weight:bold">{{scope.row.staStr}}</span>
                  <span v-else-if="scope.row.sta != 8">{{getInfoTextDisplay(scope.row.shipStatus)}}</span>
                </div>
                <span v-if="scope.row.sta == null">{{getInfoTextDisplay(scope.row.shipStatus)}}</span>
              </template>
            </el-table-column>
            <el-table-column
             fixed="right"
             label="操作"
             height="50px"
             width='180px'>
             <template slot-scope="scope">
               <div style="align-items:center;">
                 <div style="display:flex;">
                   <el-button type="text" @click="onHandleItemEditShow(scope.row)">编辑</el-button>
                 </div>
                <div style="display:flex;">
                  <el-button type="text" @click="onHandleShowPackageManage(scope.row)">包裹管理</el-button>
                  <el-button type="text" @click="onHandleItemReportExport(scope.row)">整柜导出</el-button>
                </div>
                <div style="display:flex;">
                 <el-button type="text" @click="onHandleItemLinkToSurper(scope.row)">对接到Surper</el-button>
                 <el-button type="text" @click="onHandleItemChangeRegion(scope.row)">更改航线</el-button>
               </div>
               </div>
             </template>
           </el-table-column>
        </el-table>
      </el-row>
      <el-row style="margin-top:20px;width:100%;display:inline-flex">
        <div style="width:100%">
          <el-button-group>
            <el-button type="primary" style="margin-right:5px" @click="onHandleExpressInfo()">运输信息</el-button>
            <el-button type="primary" style="margin-right:5px" @click="onHandleFinished()">处理完成</el-button>
            <el-button type="primary" @click="onHandleBackCreateShip()">退回船次建立</el-button>
          </el-button-group>
        </div>
        <div style="float:right">
            <el-pagination background layout="prev, pager,next,total,jumper"
             :total="pagination.totalCount" :page-count="pagination.totalPage"
             :current-page="pagination.pageNo" @current-change="pageNoChange"/>
        </div>
      </el-row>
      <el-dialog title="运输信息"
        width="400px"
        :visible.sync="dialogExpressInfoVisible">
        <div class="body" style="align-items:center">
          <el-radio v-model="dialogExpressRadioButtonValue" label="0">选择</el-radio>
          <el-radio v-model="dialogExpressRadioButtonValue" label="1">自定义</el-radio>
          <div style="margin-top:20px;display:flex;">
            <span style="white-space:nowrap;align-self:center">状态</span>
            <div style="margin-left:10px;width:100%">
              <div v-if="dialogExpressRadioButtonValue == 0">
                <el-select v-model="dialogExpressChoiceSelectedValue"
                  placeholder="请选择" style="width:100%">
                  <el-option
                    v-for="item in toShowInfoStatusList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </div>
              <div v-else-if="dialogExpressRadioButtonValue == 1">
                <el-input v-model="dialogExpressInputStatus" placeholder="输入自定义状态" style="width:100%"/>
              </div>
            </div>
          </div>
          <div style="margin-top:20px;display:inline-flex;margin-top:18px;width:100% !important;">
            <span style="white-space:nowrap">备注</span>
            <div style="width: 100% !important;">
              <el-input
                :rows="4"
                type="textarea"
                style="margin-left:10px;"
                placeholder="请输入内容"
                v-model="dialogExpressChoiceRemark">
              </el-input>
            </div>
          </div>
          <div style="margin-top:20px;margin-top:18px;display:flex">
            <span style="white-space:nowrap;align-self:center">时间</span>
            <div style="width: 100% !important;">
              <el-date-picker
                v-model="dialogExpressChoiceDateTimeValues"
                type="datetime"
                placement="bottom-start"
                style="margin-left:10px;"
                placeholder="选择日期时间">
              </el-date-picker>
            </div>
          </div>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="onHandleDialogExpressSubmit()">提交</el-button>
        </span>
      </el-dialog>
      <el-dialog title="编辑"
         width="400px"
         :visible.sync="updateDialogVisible">
          <el-form
             :model="updateDialogForm"
             ref="editFormRef"
             label-width="100px">
            <el-form-item label="船期" prop="ShipNo">
              <el-input v-model="updateDialogForm.ShipNo" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="地区" prop="SelectedRegionId">
                <el-select class="updateDialogForm-input-control" v-model="updateDialogForm.SelectedRegionId">
                    <el-option v-for="item in toShowRegionList"
                               :key="item.key"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="装柜时间" prop="LandTime">
              <el-date-picker
               v-model="updateDialogForm.LandTime"
               type="date"
               placement="bottom-start"
               placeholder="选择日期"
               class="updateDialogForm-input-control">
             </el-date-picker>
            </el-form-item>
            <el-form-item label="开船时间" prop="StartTime">
              <el-date-picker
                 v-model="updateDialogForm.StartTime"
                 type="date"
                 placeholder="选择日期"
                 placement="bottom-start"
                 class="updateDialogForm-input-control">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="预计到港时间: " prop="ReceiveTime">
              <el-date-picker
                 v-model="updateDialogForm.ReceiveTime"
                 type="date"
                 placement="bottom-start"
                 placeholder="选择日期"
                 class="updateDialogForm-input-control">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="内部柜号" prop="InternalShipNo">
              <el-input v-model="updateDialogForm.InternalShipNo" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="封条号" prop="SealShipNo">
              <el-input v-model="updateDialogForm.SealShipNo" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="船运公司" prop="ShipCompany">
              <el-input v-model="updateDialogForm.ShipCompany" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="调柜部门" prop="AdjustDepartment">
              <el-input v-model="updateDialogForm.AdjustDepartment" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="清关部门" prop="Clearance">
              <el-input v-model="updateDialogForm.Clearance" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="进仓备注" prop="Remark">
              <el-input v-model="updateDialogForm.InStorageRemark" class="updateDialogForm-input-control"/>
            </el-form-item>
            <el-form-item label="船期备注" prop="Remark">
              <el-input v-model="updateDialogForm.Remark" type="textarea" :rows="5" class="updateDialogForm-input-control"/>
            </el-form-item>
          </el-form>
          <div>
            <el-button type="primary" @click="onHandleEditItemSave()">保存</el-button>
            <el-button type="primary" @click="onHandleEditItemReset()">重置</el-button>
          </div>
      </el-dialog>
      <el-dialog title="更改航线"
         width="400px"
         :visible.sync="changeRegionDialog.Visible">
         <div>
           <span>请选择地区</span>
           <el-select class="updateDialogForm-input-control"
               style="margin-left:5px"
               v-model="changeRegionDialog.SelectedRegionId">
               <el-option v-for="item in toShowRegionList"
                          :key="item.key"
                          :label="item.label"
                          :value="item.value">
               </el-option>
           </el-select>
         </div>
         <div style="margin-top:20px;text-align-last:center;">
          <el-button type="primary" @click="onHandleItemChangeRegionSave">确认保存</el-button>
         </div>
       </el-dialog>
      <el-dialog title="报表导出"
          width="850px"
          :visible.sync="ReportExportDialog.Visible">
          <span style="color:black">船号:  {{this.ReportExportDialog.ShipNo}}</span>
          <div class="dialog-body" style="margin-top:10px">
            <el-button type="primary" icon="el-icon-film" @click="onHandleReportExportDialogGenerate">生成报表</el-button>
            <el-table :data="ReportExportDialog.TableData"
              @selection-change="onHandleReportExportSelectionChange"
              style="width: 100%">
              <el-table-column type="selection" width="50"/>
              <el-table-column prop="fileName" label="报表名称" width='300px' :show-overflow-tooltip='true'/>
              <el-table-column prop="fileSize" label="报表大小">
                <template slot-scope="scope">
                  <span>{{scope.row.fileSize / 1024}}KB</span>
                </template>
              </el-table-column>
              <el-table-column prop="creationTime" label="创建时间"/>
              <el-table-column prop="-" label="操作">
                <template slot-scope="scope">
                  <el-button type="text" @click="onHandleReportExportDialogDownloadReport(scope.row.fileName)">下载</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="dialog-footer" style="margin-top:20px">
            <el-button type="danger" icon="el-icon-delete" @click="onHandleReportExportDialogBatchDelete">批量删除</el-button>
          </div>
      </el-dialog>
    </div>
  </el-card>
</template>
<script>
import { GetUsers,GetRoutes,GetShipNos,GetRegionList2,
  GetAdjustDepartments } from '@/api/services/packageLookupService'
import { GetExpressList,UpdateShipStatus,Edit,LinkToSurper,
  EditRegion,GetReportList ,BatchDeleteReport,GenerateReport,
  BatchUpdateTransitInfo
} from '@/api/services/merchandiseExpressService'

export default {
  name: 'MerchandiseExpressInfoList',
  data(){
      return {
          uploadHeaders:{
            Authorization : 'Bearer' + ' ' + localStorage.getItem('TOKEN'),
          },
          dataTable:[],
          multipleSelection: [],
          pagination:{
            pageNo:1,       // 当前页
            pageSize:5,     // 当前页数量
            totalPage:2,    // 总页数
            totalCount:10,   // 总条数
          },
          selectedShipNo:-1,
          toShowShipNoList:[],
          selectedUserId:-1,
          selectedRegionId:'',
          toShowRegionList:[],
          selectedShipNo:-1,
          toShowShipNoList:[],
          toShowUserList:[
            {
              key:-1,
              value:-1,
              label:'选择会员'
            },
          ],
          selectedRouteId:-1,
          toShowRouteList:[],
          ExpressNo:'',
          Mark:'',
          TotalGoway:23387,
          selectedInfoStatus:-1,
          toShowInfoStatusList:[
            {
              key:-1,
              value:-1,
              label:'选择信息状态'
            },
            {
              key:0,
              value:0,
              label:'中国报关中'
            },
            {
              key:1,
              value:1,
              label:'中国查柜'
            },
            {
              key:2,
              value:2,
              label:'海关放行'
            },
            {
              key:9,
              value:9,
              label:'已开船'
            },
            {
              key:10,
              value:10,
              label:'到港'
            },
            {
              key:5,
              value:5,
              label:'目的港查柜'
            },
            {
              key:7,
              value:7,
              label:'清关完成'
            },
          ],
          selectedShipCang:-1,
          toShowShipCangList:[
            {
              key:-1,
              value:-1,
              label:'选择船仓'
            }
          ],
          dialogRuleVisible:false,
          dialogUploadVisible:false,
          dialogExpressInfoVisible:false,
          dialogExpressRadioButtonValue:'0',
          dialogExpressChoiceSelectedValue:-1,
          dialogExpressChoiceRemark:'',
          dialogExpressChoiceDateTimeValues:'',
          dialogExpressInputStatus:'',
          startTime:'',
          endTime:'',
          InputShipNo:'',
          InputClearance:'',
          updateDialogVisible:false,
          updateDialogForm:{
            Id:0,
            ExpectArrivedDate:'',
            ShipDate:'',
            ShipNo:'',
            SelectedRegionId:-1,
            LandTime:'',
            StartTime:'',
            ReceiveTime:'',
            InternalShipNo:'',
            SealShipNo:'',
            ShipCompany:'',
            AdjustDepartment:'',
            Clearance:'',
            Remark:''
          },
          changeRegionDialog:{
            Id:0,
            Visible:false,
            SelectedRegionId:-1,
          },
          ReportExportDialog:{
            Visible:false,
            ShipId:0,
            ShipNo:'',
            TableData:[],
            MultipleSelection:[],
          }
      }
  },
  created(){
    GetUsers().then(res => {
      this.toShowUserList = []
      this.toShowUserList.push({
        key:-1,
        value:-1,
        label:'选择会员'
      })
      res.data.forEach((item, i) => {
        this.toShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRegionList2().then(res => {
      this.toShowRegionList = []
      this.toShowRegionList.push({
        key:-1,
        value:-1,
        label:'选择地区',
      })
      res.data.forEach((item, i) => {
        this.toShowRegionList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRoutes().then(res => {
      this.toShowRouteList = []
      this.toShowRouteList.push({
        key:-1,
        value:-1,
        label:'选择航线',
      })
      res.data.forEach((item, i) => {
        this.toShowRouteList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetShipNos().then(res => {
      this.toShowShipNoList = []
      this.toShowShipNoList.push({
        key:-1,
        value:-1,
        label:'选择柜号'
      })
      res.data.forEach((item, i) => {
        this.toShowShipNoList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetAdjustDepartments().then(res => {
      this.toShowShipCangList = []
      this.toShowShipCangList.push({
        key:-1,
        value:-1,
        label:'选择船仓'
      })
      res.data.forEach((item, i) => {
        this.toShowShipCangList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      })
    })
    this.getTableData()
  },
  methods:{
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    async getTableData(){
      var params = {
        RouteId:this.selectedRouteId,
        ContainerId:this.selectedShipNo,
        StartTime:this.startTime,
        EndTime:this.endTime,
        InfoStatus:this.selectedInfoStatus,
        AdjustDepartment:this.selectedShipCang,
        ShipNo:this.InputShipNo,
        Clearance:this.InputClearance,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['RouteId'] == -1){
        delete params['RouteId']
      }
      if(params['ContainerId'] == -1){
        delete params['ContainerId']
      }
      if(params['StartTime'] == ''){
        delete params['StartTime']
      }
      if(params['EndTime'] == ''){
        delete params['EndTime']
      }
      if(params['InfoStatus'] == -1){
        delete params['InfoStatus']
      }
      if(params['AdjustDepartment'] == -1){
        delete params['AdjustDepartment']
      }else if(params['AdjustDepartment'] > 0){
        var ele = this.toShowShipCangList.find(x => x.value == params['AdjustDepartment'])
        if(ele != null){
          params['AdjustDepartment'] = ele.label
        }
      }
      if(params['ShipNo'] == -1){
        delete params['ShipNo']
      }
      if(params.InputShipNo == ''){
        delete params['InputShipNo']
      }
      if(params.Clearance == ''){
        delete params['Clearance']
      }
      GetExpressList(params).then(res => {
        this.dataTable = res.data.collection
        this.pagination.pageNo = res.data.pageNo
        this.pagination.pageSize = res.data.pageSize
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
        this.TotalGoway = res.data.totalCount
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    handleSelectionChange(val) {
        this.multipleSelection = val;
    },
    getItemTypeDisplayText({itemType}){
      var ele = this.toShowMerchandiseTypeList.find(x => x.value == itemType)
      return ele != null ? ele.label : ''
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    },
    getInfoTextDisplay(sta){
      var ele = this.toShowInfoStatusList.find(x => x.key == sta)
      return (ele == null) ? '未知状态' : ele.label
    },
    onHandleFinished(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message({type:'error',message:'请先选择欲操作列表项!'})
        return
      }
      this.openConfirm('请注意!该操作完毕之后船次将不会再出现列表中！请谨慎操作!',() => {
        UpdateShipStatus({ids:ids,status:3}).then(res => {
          if(res.status == 200){
            this.$message({type:'success',message:'操作成功!'})
            this.getTableData();
          }else{
            this.$message({type:'error',message:'操作失败!'})
          }
        })
      })
    },
    onHandleBackCreateShip(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message({type:'error',message:'请先选择欲操作列表项!'})
        return
      }
      this.openConfirm('请注意!该操作完毕之后船次将返回到船次建立列表中！请谨慎操作!',() => {
        UpdateShipStatus({ids:ids,status:1}).then(res => {
          if(res.status == 200){
            this.$message({type:'success',message:'操作成功!'})
            this.getTableData();
          }else{
            this.$message({type:'error',message:'操作失败!'})
          }
        })
      })
    },
    onHandleExpressInfo(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message({type:'error',message:'请先选择欲操作列表项!'})
        return
      }
      this.dialogExpressInfoVisible = true
    },
    onHandleDialogExpressSubmit(){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      BatchUpdateTransitInfo({
        Type:this.dialogExpressRadioButtonValue,
        Ids:ids.join(','),
        SelectedStaValue:this.dialogExpressChoiceSelectedValue,
        CustomStaValue:this.dialogExpressInputStatus,
        Remark:this.dialogExpressChoiceRemark,
        Time:this.dialogExpressChoiceDateTimeValues
      }).then(res => {
        if(res.status != 200){
          this.$message({type:'error',message:'操作失败!'})
          return
        }
        this.dialogExpressInfoVisible = false
        this.getTableData();
        this.$message({type:'success',message:'操作成功!'})
      })
    },
    onHandleItemEditShow({id,shipNo,regionId,landTime,receiveTime,
      startTime,internalShipNo,sealShipNo,shipCompany,
      adjustDepartment,clearance,remark}){
      this.updateDialogVisible = true
      this.updateDialogForm.Id = id
      this.updateDialogForm.ShipNo = shipNo
      this.updateDialogForm.SelectedRegionId = regionId
      this.updateDialogForm.LandTime = landTime
      this.updateDialogForm.ReceiveTime = receiveTime
      this.updateDialogForm.StartTime = startTime
      this.updateDialogForm.InternalShipNo = internalShipNo
      this.updateDialogForm.SealShipNo = sealShipNo
      this.updateDialogForm.ShipCompany = shipCompany
      this.updateDialogForm.AdjustDepartment = adjustDepartment
      this.updateDialogForm.Clearance = clearance
      this.updateDialogForm.InStorageRemark = remark
      this.updateDialogForm.Remark = remark
    },
    onHandleEditItemReset(){
      this.$refs['editFormRef'].resetFields()
    },
    onHandleEditItemSave(){
      var params = this.updateDialogForm
      params.RegionId = this.updateDialogForm.SelectedRegionId
      Edit(params).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.updateDialogVisible = false
        this.getTableData()
      })
    },
    onHandleItemLinkToSurper({id}){
      LinkToSurper({id:id}).then(res => {
        if(res.data.code != 200){
          this.$message.warning(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.getTableData()
      })
    },
    onHandleItemChangeRegion({id,regionId}){
      this.changeRegionDialog.Id = id
      this.changeRegionDialog.SelectedRegionId = regionId
      this.changeRegionDialog.Visible = true
    },
    onHandleItemChangeRegionSave(){
      EditRegion({
        id:this.changeRegionDialog.Id,
        regionId:this.changeRegionDialog.SelectedRegionId
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        this.changeRegionDialog.Visible = false
        this.getTableData()
      })
    },
    onHandleItemReportExport({shipId,shipNo}){
      this.ReportExportDialog.Visible = true
      this.ReportExportDialog.ShipNo = shipNo
      GetReportList().then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.ReportExportDialog.TableData = res.data.content
      })
    },
    onHandleReportExportDialogGenerate(){
      GenerateReport({Id:this.ReportExportDialog.ShipId}).then(res => {
        if(res.data.code != 200){
          this.$message.warning(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        GetReportList().then(res2 => {
          if(res2.data.code != 200){
            this.$message.error(res2.data.message)
            return
          }
          this.ReportExportDialog.TableData = res2.data.content
        })
      })
    },
    onHandleReportExportDialogDownloadReport(fileName){
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/transit/DownloadReport?fileName=' + fileName;
      link.click();
    },
    onHandleReportExportSelectionChange(val){
      this.ReportExportDialog.MultipleSelection = val
    },
    onHandleReportExportDialogBatchDelete(){
      var names = []
      this.ReportExportDialog.MultipleSelection.forEach((item,i) => {
        names.push(item.fileName)
      });
      if(names.length < 1){
        this.$message.error('请先选择欲操作项!')
        return
      }
      BatchDeleteReport({
        FileNames:names
      }).then(res => {
        if(res.data.code != 200){
          this.$message.error(res.data.message)
          return
        }
        this.$message.success(res.data.message)
        GetReportList().then(res => {
          if(res.data.code != 200){
            this.$message.error(res.data.message)
            return
          }
          this.ReportExportDialog.TableData = res.data.content
        })
      })
    },
    onHandleShowPackageManage({id}){
      this.$router.push('/ExpressInfoPackageManageList?ShipId=' + id)
    }
  }
}
</script>
<style scoped>
.tool-bar{
  margin-right:5px;
  margin-top:15px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
</style>
