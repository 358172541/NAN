<template>
    <el-card>
      <div slot="header" class="clearfix">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
          <el-breadcrumb-item>包裹签收列表</a></el-breadcrumb-item>
          <el-breadcrumb-item>开单</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div>
        <el-form
          ref="RuleForm"
          :model="RuleForm"
          :rules="FormRules"
          style="width:100%"
          label-width="120px">
          <el-row>
            <el-col :span="5">
              <div class="grid-content bg-purple"></div>
              <el-form-item label="面单号:" prop="Mark">
                  <el-input v-model="RuleForm.Mark"></el-input>
              </el-form-item>
              <el-form-item label="用户编号:" prop="SelectedUserId">
                <el-select class="fw" v-model="RuleForm.SelectedUserId"
                    @change="onUserSelectChange"
                    style="width: 100%;">
                    <el-option v-for="item in RuleForm.ToShowUserList"
                               :key="item.key"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="地区:" prop="SelectedRegionId">
                  <el-select class="fw" v-model="RuleForm.SelectedRegionId"
                      @change="onRegionSelectChange" style="width: 100%;">
                      <el-option v-for="item in RuleForm.ToShowRegionList"
                                 :key="item.key"
                                 :label="item.label"
                                 :value="item.value">
                      </el-option>
                  </el-select>
              </el-form-item>
              <el-form-item label="运输单号:" prop="ExpressNumber">
                  <el-input v-model="RuleForm.ExpressNumber" clearable/>
              </el-form-item>
              <el-form-item label="件数:" prop="ItemCount">
                  <el-input :min="0" :max="10" v-model="RuleForm.ItemCount" clearable @focus="onFocusItemCountHandle()"/>
              </el-form-item>
              <el-form-item label="物品名称:" prop="ItemName">
                  <el-input clearable v-model="RuleForm.ItemName"/>
              </el-form-item>
              <el-form-item label="发货人:" prop="Shipper">
                  <el-input clearable v-model="RuleForm.Shipper"/>
              </el-form-item>
              <el-form-item label="联系人电话:" prop="ContactTelephone">
                  <el-input clearable v-model="RuleForm.ContactTelephone"/>
              </el-form-item>
              <el-form-item label="存放位置:" prop="StoringLocation">
                  <el-input clearable v-model="RuleForm.StoringLocation"/>
              </el-form-item>
            </el-col>
            <el-col :span="5"><div class="grid-content bg-purple-light"/>
              <el-form-item label="地址:" prop="Address">
                  <el-input clearable v-model="RuleForm.Address"/>
              </el-form-item>
              <el-form-item label="邮编:" prop="PostCode">
                  <el-input clearable v-model="RuleForm.PostCode"/>
              </el-form-item>
              <el-form-item label="公司:" prop="Company">
                  <el-input clearable v-model="RuleForm.Company"/>
              </el-form-item>
              <el-form-item label="收件人:" prop="RecipientName">
                  <el-input clearable v-model="RuleForm.RecipientName"/>
              </el-form-item>
              <el-form-item label="联系人电话:" prop="RecipientTelephone">
                  <el-input clearable v-model="RuleForm.RecipientTelephone"/>
              </el-form-item>
              <el-form-item label="货物重量:" prop="Weight">
                  <el-input :min="0.0" :max="99999999.99" clearable v-model="RuleForm.Weight" @focus="onFocusWeightHandle()">
                    <template slot="append">
                      <span style="color:black">KG</span>
                    </template>
                  </el-input>
              </el-form-item>
              <el-form-item label="货物体积:" prop="VolumeWeight">
                  <el-input :min="0.0" :max="99999999.99" clearable v-model="RuleForm.VolumeWeight" @focus="onFocusVolumeWeightHandle()">
                    <template slot="append">
                      <span style="color:black">KG</span>
                    </template>
                  </el-input>
              </el-form-item>
              <el-form-item label="每立方重:" prop="EachWeight">
                  <el-input :min="0.0" :max="99999999.99" clearable v-model="RuleForm.EachWeight" @focus="onFocusEachWeightHandle()">
                    <template slot="append">
                      <span style="color:black">KG</span>
                    </template>
                  </el-input>
              </el-form-item>
              <el-form-item label="材积重:" prop="MteritalWeight">
                  <el-input v-model="RuleForm.MateritalWeight" clearable @focus="onFocusMateritalWeightHandle()">
                    <template slot="append">
                      <span style="color:black">KG</span>
                    </template>
                  </el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <SizeEditor v-model="SizeInputData" style="width:41.8%;margin-top:15px"/>
        <div style="margin-top:50px">
          <el-button type="success" plain icon="el-icon-arrow-left" @click="onBack()">上一页</el-button>
          <el-button type="primary" plain icon="el-icon-printer" @click="onSubmit()">立即打印</el-button>
        </div>
        <!-- <div>
          <OpenOrderLabel :ExpressNo="123"/>
        </div> -->
      </div>
    </el-card>
</template>

<script>
import print from 'print-js'
import { mmToPx } from '@/utils/screen_util'
import SizeEditor from '@/views/components/SizeEditor'
import OpenOrderLabel from '@/views/components/OpenOrderLabel'
import { GetUsers,GetRegionList2 } from '@/api/services/packageLookupService'
import { get_open_order_filter_param, Print_GetLabel,
  PackageSignListOpenOrder,GetExpressNoByUserIdAndRegionId
} from '@/api/services/merchandiseService'

export default {
    name: 'PackageSignListItemOpenOrder',
    components:{
      SizeEditor,
      OpenOrderLabel
    },
    data() {
        return {
          SizeInputData:[
            {
              Id:1,
              Length:0,
              Width:0,
              Height:0,
              Weight:0,
              Count:0
            }
          ],
          RuleForm: {
            Mark: '',
            ItemName: '',
            ItemCount:1,
            ExpressNumber:'',
            Shipper:'',
            ContactTelephone:'',
            StoringLocation:'',
            Address:'',
            PostCode:'',
            Company:'',
            RecipientName:'',
            RecipientTelephone:'',
            Weight:0,
            VolumeWeight:0,
            EachWeight:0,
            MateritalWeight:0,


            ToShowUserList: [],
            ToShowRegionList: [],
            SelectedUserId:-1,
            SelectedRegionId:-1,
          },
          FormRules: {
            SelectedUserId: { required: true, message: '请选择用户', trigger: [ 'change','blur'] },
            SelectedRegionId: { required: false, message: '请选择地区', trigger: [ 'change','blur'] },
            ItemCount: { required: true, message: '请输入物品件数', trigger: [ 'change','blur'] },
            ExpressNumber: { required: true, message: '请输入运输单号', trigger: [ 'change','blur'] },
            ItemCount:{ required:true,pattern:/[1-9][0-9]*/,message:'请输入有效物品件数',trigger:['blur','change'] },
          }
        }
    },
    created() {
      this.RuleForm.Mark = this.$route.query.orderNo
      GetUsers().then(res => {
        this.RuleForm.ToShowUserList = []
        this.RuleForm.ToShowUserList.push({
          key:-1,
          value:-1,
          label:'选择用户'
        })
        res.data.forEach((item, i) => {
          this.RuleForm.ToShowUserList.push({
            key:item.id,
            value:item.id,
            label:item.name,
          })
        });
      })
      GetRegionList2().then(res => {
        this.RuleForm.ToShowRegionList = []
        this.RuleForm.ToShowRegionList.push({
          key:-1,
          value:-1,
          label:'选择地区'
        })
        res.data.forEach((item, i) => {
          this.RuleForm.ToShowRegionList.push({
            key:item.id,
            value:item.id,
            label:item.name,
          })
        });
      })
    },
    methods: {
      onBack(){
        this.$router.back()
      },
      onSubmit() {
        this.$refs['RuleForm'].validate((valid) => {
          if(!valid){
            console.error('error submit!!');
            return false;
          }else{
            console.log(`RuleForm: ${JSON.stringify(this.RuleForm)}`)
            console.log(`SizeInputData: ${JSON.stringify(this.SizeInputData)}`)
            const toSubmitParams = {
              mark:this.RuleForm.Mark,
              userId:this.RuleForm.SelectedUserId,
              regionId:this.RuleForm.SelectedRegionId,
              expressNumber:this.RuleForm.ExpressNumber,
              shipperName:this.RuleForm.Shipper,
              recipientPhoneNo:this.RuleForm.ContactTelephone,
              recipientTelephone:this.RuleForm.RecipientTelephone,
              recipientLocation:this.RuleForm.Address,
              recipientPostCode:this.RuleForm.PostCode,
              recipientCompanyName:this.RuleForm.RecipientName,
              itemName:this.RuleForm.ItemName,
              weight:this.RuleForm.Weight,
              volumeWeight:this.RuleForm.VolumnWeight,
              weightPercentage:this.RuleForm.EachWeight,
              itemCount:this.RuleForm.ItemCount,
              detailSize:this.SizeInputData
            }
            PackageSignListOpenOrder(toSubmitParams).then(res => {
              console.log(`PackageSignListOpenOrder: ${res.data}`)
              Print_GetLabel({
                  width:parseInt(mmToPx(100)),
                  height:parseInt(mmToPx(70)),
                  ExpressNumber:this.RuleForm.ExpressNumber,
                  Mark: this.RuleForm.Mark,
                  ItemCount: this.RuleForm.ItemCount
              }).then(res => {
                  if (res.data != null && res.data.length > 1) {
                      printJS({
                          printable: res.data,
                          type: 'pdf',
                          base64: true
                      })
                  }
              })
            })
          }
        });
      },
      onFocusItemCountHandle(){
        if(this.RuleForm.ItemCount === 0 || this.RuleForm.ItemCount === '0'){
          this.RuleForm.ItemCount = ''
        }
      },
      onFocusWeightHandle(){
        if(this.RuleForm.Weight === 0 || this.RuleForm.Weight === '0'){
          this.RuleForm.Weight = ''
        }
      },
      onFocusVolumeWeightHandle(){
        if(this.RuleForm.VolumeWeight === 0 || this.RuleForm.VolumeWeight === '0'){
          this.RuleForm.VolumeWeight = ''
        }
      },
      onFocusEachWeightHandle(){
        if(this.RuleForm.EachWeight === 0 || this.RuleForm.EachWeight === '0'){
          this.RuleForm.EachWeight = ''
        }
      },
      onFocusMateritalWeightHandle(){
        if(this.RuleForm.MateritalWeight === 0 || this.RuleForm.MateritalWeight === '0'){
          this.RuleForm.MateritalWeight = ''
        }
      },
      onRegionSelectChange(val){
        if(this.RuleForm.SelectedRegionId != -1 && this.RuleForm.SelectedUserId != -1){
          this.onGetExpressNo()
        }
      },
      onUserSelectChange(val){
        if(this.RuleForm.SelectedUserId == -1 || this.RuleForm.SelectedUserId == ''){
          return
        }
        if(this.RuleForm.SelectedRegionId == -1 || this.RuleForm.SelectedRegionId == ''){
          return
        }
        this.onGetExpressNo()
      },
      onGetExpressNo(){
        GetExpressNoByUserIdAndRegionId({
          userId:this.RuleForm.SelectedUserId,
          regionId:this.RuleForm.SelectedRegionId
        }).then(res => {
          if(res.data.code != 200){
            this.$message.error(res.data.message)
            return
          }
          this.RuleForm.ExpressNumber = res.data.content.split('|')[0]
        })
      }
    }
}
</script>

<style scoped>
.OpenOrderForm {
    white-space: nowrap;
    align-items: center;
}
</style>
