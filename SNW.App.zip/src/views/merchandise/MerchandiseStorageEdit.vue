<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>包裹管理</el-breadcrumb-item>
        <el-breadcrumb-item>编辑包裹</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
      <el-form ref="RuleForm" :model="RuleForm" :rules="FormRules" label-width="100px">
        <el-row>
          <el-col :span="5">
            <div class="grid-content bg-purple"></div>
            <el-form-item label="用户编号:" prop="SelectedUserId">
              <el-select class="fw" v-model="RuleForm.SelectedUserId">
                  <el-option v-for="item in RuleForm.ToShowUserList"
                             :key="item.key"
                             :label="item.label"
                             :value="item.value">
                  </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="地区:" prop="SelectedRegionId">
                <el-select class="fw" v-model="RuleForm.SelectedRegionId">
                    <el-option v-for="item in RuleForm.ToShowRegionList"
                               :key="item.key"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="运输单号:" prop="ExpressNumber">
                <el-input v-model="RuleForm.ExpressNumber" clearable/>
            </el-form-item>
            <el-form-item label="唛头:" prop="Mark">
                <el-input v-model="RuleForm.Mark"></el-input>
            </el-form-item>
            <el-form-item label="快递列表:" prop="ExpressList">
                <el-input type="textarea" :rows="3" style="white-space: pre-line" v-model="RuleForm.ExpressList" clearable />
            </el-form-item>
            <el-form-item label="件数:" prop="ItemCount">
                <el-input :min="0" :max="10" v-model="RuleForm.ItemCount" clearable @focus="onFocusItemCountHandle()"/>
            </el-form-item>
            <el-form-item label="物品名称:" prop="ItemName">
                <el-input clearable v-model="RuleForm.ItemName"/>
            </el-form-item>
            <el-form-item label="S/体积:" prop="Volume">
                <el-input :min="0.0" :max="99999999.99" clearable v-model="RuleForm.Volume" @focus="onFocusVolumeHandle()">
                  <template slot="append">
                    <span style="color:black">立方</span>
                  </template>
                </el-input>
            </el-form-item>
            <el-form-item label="重量:" prop="Weight">
                <el-input :min="0.0" :max="99999999.99" clearable v-model="RuleForm.Weight" @focus="onFocusWeightHandle()">
                  <template slot="append"><span style="color:black">KG</span></template>
                </el-input>
            </el-form-item>
            <el-form-item label="超重货体积：" prop="VolumeWeight">
                <el-input clearable v-model="RuleForm.VolumeWeight"/>
            </el-form-item>
            <el-form-item label="发货人:" prop="Shipper">
                <el-input clearable v-model="RuleForm.Shipper"/>
            </el-form-item>
            <el-form-item label="重量/比例:" prop="WeightPercentage">
                <el-input clearable v-model="RuleForm.WeightPercentage"/>
            </el-form-item>
            <el-form-item label="订单号(送货):" prop="OrderNumber">
                <el-input clearable v-model="RuleForm.OrderNumber"/>
            </el-form-item>
          </el-col>
          <el-col :span="0.5">&nbsp</el-col>
          <el-col :span="5"><div class="grid-content bg-purple-light"/>
            <el-form-item label="邮编:" prop="PostCode">
                <el-input clearable v-model="RuleForm.PostCode"/>
            </el-form-item>
            <el-form-item label="公司:" prop="Company">
                <el-input clearable v-model="RuleForm.Company"/>
            </el-form-item>
            <el-form-item label="收件人:" prop="RecipientName">
                <el-input clearable v-model="RuleForm.RecipientName"/>
            </el-form-item>
            <el-form-item label="联系人电话:" prop="RecipientTelephone">
                <el-input clearable v-model="RuleForm.RecipientTelephone"/>
            </el-form-item>
            <el-form-item label="地址:" prop="RecipientAddress">
              <el-input type="textarea" :rows="3" clearable v-model="RuleForm.RecipientAddress"/>
            </el-form-item>
            <el-form-item label="派送地区:" prop="SelectedDeliveryRegionId">
                <el-select class="fw" v-model="RuleForm.SelectedDeliveryRegionId">
                    <el-option v-for="item in RuleForm.ToShowDeliveryRegionList"
                               :key="item.key"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="存放位置:" prop="Location">
                <el-input clearable v-model="RuleForm.Location"/>
            </el-form-item>
            <el-form-item label="杂费:" prop="Misc">
                <el-input clearable v-model="RuleForm.Misc"/>
            </el-form-item>
            <el-form-item label="派送人电话:" prop="DeliverPhoneNumber">
                <el-input clearable v-model="RuleForm.DeliverPhoneNumber"/>
            </el-form-item>
            <el-form-item label="代收:" prop="ReceivedFreight">
                <el-input clearable v-model="RuleForm.ReceivedFreight"/>
            </el-form-item>
            <el-form-item label="包装类型:" prop="SelectedPackType">
                <el-select class="fw"
                           v-model="RuleForm.SelectedPackType"
                           filterable
                           allow-create
                           default-first-option
                           placeholder="包装类型">
                    <el-option v-for="item in RuleForm.ToShowPackTypeList"
                               :key="item.key"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="管理备注:" prop="Remark">
                <el-input type="textarea" :rows="3" clearable v-model="RuleForm.Remark"/>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div>
        <div>
          <span style="width:100px;margin-left:35px;margin-bottom:20px;color:#777;font-size:13px">货物类型:&nbsp</span>
          <el-radio-group v-model="RuleForm.SelectedMarchandiseType">
              <el-radio :label="0">TT</el-radio>
              <el-radio :label="1">JJ</el-radio>
              <el-radio :label="2">A</el-radio>
              <el-radio :label="3">B</el-radio>
              <el-radio :label="4">C</el-radio>
              <el-radio :label="5">F</el-radio>
              <el-radio :label="6">M</el-radio>
              <el-radio :label="7">MT</el-radio>
          </el-radio-group>
        </div>
        <SizeEditor v-model="SizeInputData" style="width:20%;display:inline-flex;margin-top:20px"/>
      </div>
      <div style="margin-top:50px">
        <el-button type="success" plain icon="el-icon-arrow-left" @click="onBack()">上一页</el-button>
        <el-button type="primary" plain icon="el-icon-printer" @click="onSubmit()">确认保存</el-button>
      </div>
    </div>
  </el-card>
</template>
<script>
import print from 'print-js'
import { mmToPx } from '@/utils/screen_util'
import SizeEditor from '@/views/components/SizeEditor'
import { Print_GetLabel,
  LoadExistAddress,
  GetInfoSupplementAndCheckGetPackageEditParam,
  GetInfoSupplementAndCheckGetPackageUpdatePackage,
  PackageSignListOpenOrder } from '@/api/services/merchandiseService'
import { GetUsers,GetRegionList2,GetDeliveryRegionDropdownList
} from '@/api/services/packageLookupService'

export default {
    name: 'MerchandiseStorageEdit',
    components:{
      SizeEditor
    },
    data(){
        return {
          PackageId:0,
          SizeInputData:[],
          RuleForm: {
            Mark: '',
            ItemName: '',
            ItemCount:1,
            ExpressNumber:'',
            Shipper:'',
            ContactTelephone:'',
            Location:'',
            Address:'',
            PostCode:'',
            Company:'',
            RecipientName:'',
            RecipientPhoneNo:'',
            RecipientTelephone:'',
            RecipientAddress:'',
            Weight:0,
            Volume:0,
            VolumeWeight:0,
            EachWeight:0,
            SenderOrderNumber:'',
            ExpressList:'',
            PackingType:0,
            ReceivedFreight:0,
            DeliverPhoneNumber:'',
            OrderNumber:'',
            Misc:0,
            Remark:'',
            WeightPercentage:'',
            ToShowUserList: [],
            ToShowRegionList: [],
            SelectedUserId:-1,
            SelectedRegionId:-1,
            SelectedMarchandiseType:0,
            SelectedPackType: 0,
            SelectedDeliveryRegionId:-1,
            ToShowDeliveryRegionList:[],
            ToShowPackTypeList: [
                {
                    key: 0,
                    value: 0,
                    label: '纸箱'
                },
                {
                    key: 1,
                    value: 1,
                    label: '编织袋'
                },
                {
                    key: 2,
                    value: 2,
                    label: '木架'
                },
                {
                    key: 3,
                    value: 3,
                    label: '裸装'
                },
                {
                    key: 4,
                    value: 4,
                    label: '重货'
                },
                {
                    key: 5,
                    value: 5,
                    label: '超长'
                },
                {
                    key: 6,
                    value: 6,
                    label: '塑料桶'
                },
                {
                    key: 7,
                    value: 7,
                    label: '托盘'
                }
            ]
          },
          FormRules: {
            SelectedUserId: { required: true, message: '请选择用户', trigger: [ 'change','blur'] },
            SelectedRegionId: { required: false, message: '请选择地区', trigger: [ 'change','blur'] },
            ItemCount: { required: true, message: '请输入物品件数', trigger: [ 'change','blur'] },
            ExpressNumber: { required: true, message: '请输入运输单号', trigger: [ 'change','blur'] },
            ItemCount:{ required:true,pattern:/[1-9][0-9]*/,message:'请输入有效物品件数',trigger:['blur','change'] },
          }
        }
    },
    created(){
      this.PackageId = this.$route.query.id
      this.RuleForm.Mark = this.$route.query.orderNo
      GetUsers().then(res => {
        this.RuleForm.ToShowUserList = []
        this.RuleForm.ToShowUserList.push({
          key:-1,
          value:-1,
          label:'选择用户',
        })
        res.data.forEach((item, i) => {
          this.RuleForm.ToShowUserList.push({
            key:item.id,
            value:item.id,
            label:item.name,
          })
        });
      })
      GetRegionList2().then(res => {
        this.RuleForm.ToShowRegionList = []
        this.RuleForm.ToShowRegionList.push({
          key:-1,
          value:-1,
          label:'选择地区',
        })
        res.data.forEach((item, i) => {
          this.RuleForm.ToShowRegionList.push({
            key:item.id,
            value:item.id,
            label:item.name,
          })
        });
      })
      GetDeliveryRegionDropdownList().then(res => {
        this.RuleForm.ToShowDeliveryRegionList = []
        this.RuleForm.ToShowDeliveryRegionList.push({
          key:-1,
          value:-1,
          label:'选择地区',
        })
        res.data.forEach((item, i) => {
          this.RuleForm.ToShowDeliveryRegionList.push({
            key:item.key,
            value:item.value,
            label:item.label,
          })
        });
      })
      this.getEditParam()
    },
    methods: {
      getEditParam(){
        GetInfoSupplementAndCheckGetPackageEditParam({id:this.PackageId}).then(res => {
          this.RuleForm.SelectedDeliveryRegionId = res.data.content.deliveryRegionId != null ? res.data.content.deliveryRegionId.toString() : ''
          this.RuleForm.SelectedUserId = res.data.content.userId
          this.RuleForm.SelectedRegionId = res.data.content.regionId
          this.RuleForm.SelectedPackType = res.data.content.packingType
          this.RuleForm.Mark = res.data.content.mark
          this.RuleForm.ItemName = res.data.content.itemName
          this.RuleForm.ItemCount = res.data.content.itemCount
          this.RuleForm.ExpressNumber = res.data.content.expressNumber
          this.RuleForm.ExpressList = res.data.content.expressList
          this.RuleForm.Shipper = res.data.content.rhipper
          this.RuleForm.Weight = res.data.content.weight
          this.RuleForm.EachWeight = res.data.content.weightPercentage,
          this.RuleForm.Volume = res.data.content.volume,
          this.RuleForm.VolumeWeight = res.data.content.volumeWeight,
          this.RuleForm.Shipper = res.data.content.shipperName
          this.RuleForm.ContactTelephone = res.data.content.shipperTelephone
          this.RuleForm.RecipientAddress = res.data.content.recipientAddress
          this.RuleForm.Address = res.data.content.recipientDetailAddress
          this.RuleForm.PostCode = res.data.content.recipientPostcode
          this.RuleForm.Company = res.data.content.recipientCompanyName
          this.RuleForm.SenderOrderNumber = res.data.content.senderOrderNumber
          this.RuleForm.SelectedMarchandiseType = res.data.content.itemType
          this.RuleForm.PackingType = res.data.content.packingType
          this.RuleForm.ReceivedFreight = res.data.content.receivedFreight
          this.RuleForm.DeliverPhoneNumber = res.data.content.deliverPhoneNumber
          this.RuleForm.ReceivedFreight = res.data.content.receivedFreight
          this.RuleForm.OrderNumber = res.data.content.orderNumber
          this.RuleForm.Misc = res.data.content.misc
          this.RuleForm.Remark = res.data.content.remark
          this.RuleForm.WeightPercentage = res.data.content.weightPercentage
          this.RuleForm.Location = res.data.content.location
          this.RuleForm.RecipientAddress = res.data.content.recipientAddress
          this.RuleForm.RecipientName = res.data.content.recipientName
          this.RuleForm.RecipientPhoneNo = res.data.content.recipientPhoneNo
          this.RuleForm.RecipientTelephone = res.data.content.recipientTelephone
          if(res.data.content.sizeList != null){
            res.data.content.sizeList.forEach((item, i) => {
              this.SizeInputData.push({
                Id:this.SizeInputData.Length,
                Length:item.length,
                Width:item.width,
                Height:item.height,
                Weight:item.weight,
                Count:item.count
              })
            });
          }
        })
      },
      onBack(){
        this.$router.back()
      },
      onSubmit(val = 0){
        this.$refs['RuleForm'].validate((valid) => {
          if(!valid){
            console.error('error submit!!');
            return false;
          }
          var params = {
            Id:this.PackageId,
            ExpressNumber:this.RuleForm.ExpressNumber,
            Mark:this.RuleForm.Mark,
            UserId:this.RuleForm.SelectedUserId,
            ItemCount:this.RuleForm.ItemCount,
            ItemName:this.RuleForm.ItemName,
            RegionId:this.RuleForm.SelectedRegionId,
            Volume:this.RuleForm.Volume,
            Weight:this.RuleForm.Weight,
            ItemType:this.RuleForm.SelectedMarchandiseType,
            WeightPercentage:this.RuleForm.EachWeight,
            VolumeWeight:this.RuleForm.VolumeWeight,
            ShipperName:this.RuleForm.Shipper,
            ShipperAddress:this.RuleForm.Address,
            RecipientName:this.RuleForm.RecipientName,
            RecipientPhoneNo:this.RuleForm.RecipientPhoneNo,
            RecipientTelephone:this.RuleForm.RecipientTelephone,
            RecipientCompanyName:this.RuleForm.Company,
            RecipientAddress:this.RuleForm.RecipientAddress,
            Location:this.RuleForm.Location,
            RecipientPostcode:this.RuleForm.PostCode,
            SizeList:this.SizeInputData,
            ExpressList:this.RuleForm.ExpressList,
            PackingType:this.RuleForm.SelectedPackType,
            ReceivedFreight:this.RuleForm.ReceivedFreight,
            DeliverPhoneNumber:this.RuleForm.DeliverPhoneNumber,
            OrderNumber:this.RuleForm.OrderNumber,
            Misc:this.RuleForm.Misc,
            Remark:this.RuleForm.Remark,
            WeightPercentage:this.RuleForm.WeightPercentage,
            DeliveryRegionId:this.RuleForm.SelectedDeliveryRegionId
          }
          GetInfoSupplementAndCheckGetPackageUpdatePackage(params).then(res => {
            if(res.data.code == 200){
              if(val == 0)this.onBack()
            }
            this.$message({type:res.data.code == 200 ? 'success' : 'error',message:res.data.message})
          })
        });
      },
      onFocusItemCountHandle(){
        if(this.RuleForm.ItemCount === 0 || this.RuleForm.ItemCount === '0'){
          this.RuleForm.ItemCount = ''
        }
      },
      onFocusWeightHandle(){
        if(this.RuleForm.Weight === 0 || this.RuleForm.Weight === '0'){
          this.RuleForm.Weight = ''
        }
      },
      onFocusVolumeHandle(){
        if(this.RuleForm.VolumeWeight === 0 || this.RuleForm.VolumeWeight === '0'){
          this.RuleForm.VolumeWeight = ''
        }
      },
      onFocusEachWeightHandle(){
        if(this.RuleForm.EachWeight === 0 || this.RuleForm.EachWeight === '0'){
          this.RuleForm.EachWeight = ''
        }
      },
      onFocusMateritalWeightHandle(){
        if(this.RuleForm.VolumeWeight === 0 || this.RuleForm.VolumeWeight === '0'){
          this.RuleForm.VolumeWeight = ''
        }
      },
    }
}
</script>
<style scoped>
.fw{
  width:100%;
}
.OpenOrderForm {
    white-space: nowrap;
    align-items: center;
}
</style>
