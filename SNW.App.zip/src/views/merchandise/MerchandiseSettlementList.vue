<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-结算</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user">
      <el-row style="font-weight: bold;">
        <el-col :span="5" style="font-size:20px;color:red">
          计划装柜体积:
          <el-tag type="danger" style="font-size:20px;color:red">{{TotalVolume}}</el-tag>
        </el-col>
        <el-col :span="5" style="font-size:20px;color:red">
          计划装柜重量:
          <el-tag type="danger" style="font-size:20px;color:red">{{TotalWeight}}</el-tag>
        </el-col>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedMerchandiseType" placeholder="货物类型">
          <el-option v-for="item in toShowMerchandiseTypeList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedUserId" placeholder="选择会员">
          <el-option
            v-for="item in toShowUserList"
            :key="item.key"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedBalanceStatus" placeholder="选择状态">
          <el-option v-for="item in toShowBalanceStatusList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-select v-model="selectedRegionId" placeholder="选择地区">
          <el-option
            v-for="item in toShowRegionList"
            :key="item.key"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-row>
      <el-row class="tool-bar">
        <el-input v-model="ExpressNo" placeholder="请输入运输单号" clearable/>
      </el-row>
      <el-row class="tool-bar">
        <el-input v-model="Mark" placeholder="请输入唛头" clearable/>
      </el-row>
      <el-row class="tool-bar">
        <el-date-picker
        placement="bottom-start"
          v-model="startTime"
          type="date"
          placeholder="开始时间">
        </el-date-picker>
      </el-row>
      <el-row class="tool-bar">
        <el-date-picker
        placement="bottom-start"
          v-model="endTime"
          type="date"
          placeholder="结束时间">
        </el-date-picker>
      </el-row>
      <div class="tool-bar" style="display:inline-block;margin-top:15px;vertical-align: bottom;">
        <el-button type="primary" icon="el-icon-search" @click="onHandleSearch()">查询</el-button>
        <el-button type="primary" icon="el-icon-search" @click="onHandleExport">导出账单</el-button>
        <el-button type="primary" @click="onHandleExportSmallBag">导出小包账单</el-button>
      </div>
      <el-row style="margin-top:10px">
        <el-table border ref="multipleTable" tooltip-effect="dark"
            @selection-change="handleSelectionChange" style="width: 100%"
            :data="dataTable" :row-class-name="tableRowClassName">
            <el-table-column type="selection"width="50"/>
            <el-table-column prop="itemType" label="类型">
              <template slot-scope="scope">
                <span>{{getItemTypeDisplayText(scope.row)}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="expressNumber" label="运输单号" width='180':show-overflow-tooltip='true'/>
            <el-table-column prop="mark" label="唛头"/>
            <el-table-column prop="containerNumber" label="柜号"/>
            <el-table-column prop="userDisplay" label="会员编号"/>
            <el-table-column prop="weight" label="重量"/>
            <el-table-column prop="regionDisplay" label="地区"/>
            <el-table-column prop="volume" label="实体积"/>
            <el-table-column prop="customerConfirmedVolume" label="客体积"/>
            <el-table-column prop="itemName" label="品名"/>
            <el-table-column prop="itemCount" label="件数"/>
            <el-table-column prop="statusDisplay" label="状态" width="150"/>
            <el-table-column prop="balanceStatusDisplay" label="结算状态"/>
            <el-table-column
             fixed="right"
             label="操作"
             width='auto'>
             <template slot-scope="scope">
               <el-row>
                <el-button type="primary" size="small" icon="el-icon-edit" @click="editHandle(scope.row)">编辑</el-button>
              </el-row>
             </template>
           </el-table-column>
        </el-table>
      </el-row>
      <el-row style="margin-top:20px;display:inline-flex;width:100%">
        <div style="width:100%">
          <el-button type="primary" @click="onHandleBatchUpdateBalanceStatus(2)">结算完成</el-button>
          <el-button type="primary" @click="onHandleBatchUpdateBalanceStatus(3)">未付款</el-button>
          <el-button type="primary" @click="onHandleUpdateStatus(7)">目的港扣货</el-button>
          <el-button type="primary" @click="onHandleUpdateStatus(5)">可出货</el-button>
        </div>
        <div style="float:right">
          <el-pagination background layout="prev, pager,next,total,jumper"
           :total="pagination.totalCount" :page-count="pagination.totalPage"
           :current-page="pagination.pageNo" @current-change="pageNoChange"/>
        </div>
      </el-row>
    </div>
  </el-card>
</template>

<script>
import { GetUsers,GetRoutes,GetShipNos,GetRegionList2 } from '@/api/services/packageLookupService'
import { GetMerchandiseSettlementList,BatchUpdateBalanceStatus,
  GetMerchandiseStorageListExtraParams
} from '@/api/services/merchandiseService'
import { BatchUpdateItemStatus
 } from '@/api/services/merchandiseStoreService'
import { jsonToQueryParams } from '@/utils/convertUtil'

export default {
  name: 'MerchandiseSettlementList',
  data(){
      return {
          uploadHeaders:{
            Authorization : 'Bearer' + ' ' + localStorage.getItem('TOKEN'),
          },
          dataTable:[],
          multipleSelection: [],
          pagination:{
            pageNo:1,       // 当前页
            pageSize:8,     // 当前页数量
            totalPage:2,    // 总页数
            totalCount:10,   // 总条数
          },
          selectedMerchandiseType:-1,
          toShowMerchandiseTypeList:[
            {
              key:-1,
              value:-1,
              label:'选择类型'
            },
            {
              key:0,
              value:0,
              label:'TT'
            },
            {
              key:1,
              value:1,
              label:'JJ'
            },
            {
              key:2,
              value:2,
              label:'A'
            },
            {
              key:3,
              value:3,
              label:'B'
            },
            {
              key:4,
              value:4,
              label:'C'
            },
            {
              key:5,
              value:5,
              label:'F'
            },
            {
              key:6,
              value:6,
              label:'M'
            },
            {
              key:7,
              value:7,
              label:'MT'
            },
            {
              key:8,
              value:8,
              label:'MF'
            },
          ],
          selectedBalanceStatus:-1,
          toShowBalanceStatusList:[
            {
              key:-1,
              value:-1,
              label:'选择状态'
            },
            {
              key:0,
              value:0,
              label:'待结算'
            },
            {
              key:1,
              value:1,
              label:'已导出账单'
            },
            {
              key:2,
              value:2,
              label:'未付款'
            }
          ],
          selectedShipNo:-1,
          toShowShipNoList:[
            {
              key:-1,
              value:-1,
              label:'选择船次'
            },
          ],
          selectedUserId:-1,
          selectedRegionId:'',
          toShowRegionList:[],
          toShowUserList:[
            {
              key:-1,
              value:-1,
              label:'选择会员'
            },
          ],
          ExpressNo:'',
          Mark:'',
          dialogRuleVisible:false,
          dialogUploadVisible:false,
          TotalVolume:0,
          TotalWeight:0,
          startTime:'',
          endTime:''
      }
  },
  created(){
    GetUsers().then(res => {
      res.data.forEach((item, i) => {
        this.toShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRegionList2().then(res => {
      this.toShowRegionList = []
      this.toShowRegionList.push({
        key:-1,
        value:-1,
        label:'选择地区',
      })
      res.data.forEach((item, i) => {
        this.toShowRegionList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetShipNos().then(res => {
      res.data.forEach((item, i) => {
        this.toShowShipNoList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetMerchandiseStorageListExtraParams({type:'settlementList'}).then(res => {
      this.TotalVolume = res.data.totalVolume
      this.TotalWeight = res.data.totalWeight
    })
    this.getTableData()
  },
  methods:{
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    tableRowClassName({row, rowIndex}) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    async getTableData(){
      var params = {
        ItemType:this.selectedMerchandiseType,
        UserId:this.selectedUserId,
        SettlementStatus:this.selectedBalanceStatus,
        RegionId:this.selectedRegionId,
        ExpressNo:this.ExpressNo,
        BoxNumber:this.selectedShipNo,
        Mark:this.Mark,
        StartTime:this.startTime,
        EndTime:this.endTime,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['SettlementStatus'] == -1){
        delete params['SettlementStatus']
      }
      if(params['SettlementStatus'] == -1){
        delete params['SettlementStatus']
      }
      if(params['RegionId'] == -1 || params['RegionId'] == ''){
        delete params['RegionId']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['BoxNumber'] == -1){
        delete params['BoxNumber']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      if(params['StartTime'] == ''){
        delete params['StartTime']
      }
      if(params['EndTime'] == ''){
        delete params['EndTime']
      }
      GetMerchandiseSettlementList(params).then(res => {
        this.dataTable = res.data.collection
        //this.pagination.pageNo = res.data.pageNo
        //this.pagination.pageSize = res.data.pageSize
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    handleSelectionChange(val) {
        this.multipleSelection = val;
    },
    editHandle({id}){
      this.$router.push('/MerchandiseStorageEdit?id=' + id)
    },
    getItemTypeDisplayText({itemType}){
      var ele = this.toShowMerchandiseTypeList.find(x => x.value == itemType)
      return ele != null ? ele.label : ''
    },
    getPackingTypeDisplayText({packingType}){
      const list = [
        '-','纸箱','编织袋','木架','裸装','重货','超长','塑料桶','托盘'
      ]
      return list[packingType]
    },
    openConfirm(message,onConfirm){
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => onConfirm()).catch(() => {})
    },
    onHandleUpdateStatus(itemStatus){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择要更改状态的列表项!')
        return
      }
      BatchUpdateItemStatus({
        Ids:ids,
        ItemStatus:itemStatus,
      }).then(res => {
        if(res.status != 200){
          this.$message.error('更新状态出错!')
          return
        }else{
          this.$message.success('更新状态成功!')
        }
        this.getTableData()
      })
    },
    onHandleBatchUpdateBalanceStatus(val){
      var ids = []
      this.multipleSelection.forEach((item,i) => {
        ids.push(item.id)
      });
      if(ids.length < 1){
        this.$message.error('请先选择要更改状态的列表项!')
        return
      }
      BatchUpdateBalanceStatus({
        ids:ids.join(','),
        status:val
      }).then(res => {
        if(res.status != 200){
          this.$message.error('更新状态出错!')
          return
        }else{
          this.$message.success('更新状态成功!')
        }
        this.getTableData()
      })
    },
    onHandleExportSmallBag(){
      var params = {
        ItemType:this.selectedMerchandiseType,
        UserId:this.selectedUserId,
        SettlementStatus:this.selectedBalanceStatus,
        RegionId:this.selectedRegionId,
        ExpressNo:this.ExpressNo,
        BoxNumber:this.selectedShipNo,
        Mark:this.Mark,
        StartTime:this.startTime,
        EndTime:this.endTime,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['SettlementStatus'] == -1){
        delete params['SettlementStatus']
      }
      if(params['SettlementStatus'] == -1){
        delete params['SettlementStatus']
      }
      if(params['RegionId'] == -1 || params['RegionId'] == ''){
        delete params['RegionId']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['BoxNumber'] == -1){
        delete params['BoxNumber']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      if(params['StartTime'] == ''){
        delete params['StartTime']
      }
      if(params['EndTime'] == ''){
        delete params['EndTime']
      }
      var encodeUrl = '?' + jsonToQueryParams(params)
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/PackageSettlement/GetSmallBillFile' + encodeUrl;
      link.click();
    },
    onHandleExport(){
      var params = {
        ItemType:this.selectedMerchandiseType,
        UserId:this.selectedUserId,
        SettlementStatus:this.selectedBalanceStatus,
        RegionId:this.selectedRegionId,
        ExpressNo:this.ExpressNo,
        BoxNumber:this.selectedShipNo,
        Mark:this.Mark,
        StartTime:this.startTime,
        EndTime:this.endTime,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize,
      }
      if(params['ItemType'] == -1){
        delete params['ItemType']
      }
      if(params['UserId'] == -1){
        delete params['UserId']
      }
      if(params['SettlementStatus'] == -1){
        delete params['SettlementStatus']
      }
      if(params['SettlementStatus'] == -1){
        delete params['SettlementStatus']
      }
      if(params['RegionId'] == -1 || params['RegionId'] == ''){
        delete params['RegionId']
      }
      if(params['ExpressNo'] == ''){
        delete params['ExpressNo']
      }
      if(params['BoxNumber'] == -1){
        delete params['BoxNumber']
      }
      if(params['Mark'] == ''){
        delete params['Mark']
      }
      if(params['StartTime'] == ''){
        delete params['StartTime']
      }
      if(params['EndTime'] == ''){
        delete params['EndTime']
      }
      var encodeUrl = '?' + jsonToQueryParams(params)
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/PackageSettlement/GetBillFile' + encodeUrl;
      link.click();
    },
  }
}
</script>

<style scoped>
.tool-bar{
  margin-right:5px;
  margin-top:15px;
  display:inline-flex;
  white-space:nowrap;
  align-items:center;
}
</style>
