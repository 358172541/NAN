<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-运输信息</el-breadcrumb-item>
        <el-breadcrumb-item>货物-包裹管理</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
      <div class="create-ship-control-group" style="display:inline-flex;align-items:baseline;">
        <span style="font-size:20px">柜号：CS-5997</span>
        <div style="margin-left:20px;display:inline-flex;">
          <div style="color:red;font-size:20px">
            柜体积:
            <el-tag type="danger" style="font-size:20px">0 m³</el-tag>
          </div>
          <div style="margin-left:20px;color:red;font-size:20px">
            柜重量:
            <el-tag type="danger" style="font-size:20px">0 KG</el-tag>
          </div>
        </div>
      </div>
      <div class="create-ship-control-group" style="margin-top:10px">
        <el-button type='danger' icon="el-icon-back" @click="onHandleBack">上一步</el-button>
        <el-input v-model="Mark" placeholder="唛头" style="width:215px" clearable/>
        <el-input v-model="ExpressNo" placeholder="运单号" style="width:215px" clearable/>
        <el-select v-model="selectedUserId" placeholder="选择会员">
          <el-option
            v-for="item in toShowUserList"
            :key="item.key"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="selectedMerchandiseType" placeholder="货物类型">
          <el-option v-for="item in toShowMerchandiseTypeList"
           :key='item.key' :label='item.label' :value='item.value'/>
        </el-select>
        <el-button type="primary" icon="el-icon-search" @click="onHandleSearch">查询</el-button>
        <el-button type="primary" icon="el-icon-search" @click="onHandleExportSmallBag">导出小包</el-button>
      </div>
      <el-table border ref="multipleTable" tooltip-effect="dark"
          @selection-change="handleSelectionChange" style="width:100%;margin-top:8px"
          :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column type="selection" width="50"/>
          <el-table-column prop="itemType" label="类型" width="auto">
            <template slot-scope="scope">
              <el-row>
                <span>{{getItemTypeDisplayText(scope.row)}}</span>
              </el-row>
            </template>
          </el-table-column>
          <el-table-column prop="expressNumber" label="运单号" width="160"/>
          <el-table-column prop="mark" label="唛头"/>
          <el-table-column prop="-" label="地址"/>
          <el-table-column prop="-" label="会员" :show-overflow-tooltip='true'/>
          <el-table-column prop="-" label="品名"/>
          <el-table-column prop="-" label="地区"/>
          <el-table-column prop="itemCount" label="件数"/>
          <el-table-column prop="weight" label="重量"/>
          <el-table-column prop="-" label="材积重/体积"/>
          <el-table-column prop="-" label="S/体积"/>
          <el-table-column prop="-" label="包装类型"/>
          <el-table-column prop="-" label="排序"/>
          <el-table-column prop="-" label="位置"/>
          <el-table-column prop="-" label="操作"/>
      </el-table>
      <el-pagination background layout="prev, pager,next,total,jumper"
       style="margin-top:10px" :total="pagination.totalCount"
       :page-count="pagination.totalPage" :current-page="pagination.pageNo"
       @current-change="pageNoChange"/>
    </div>
  </el-card>
</template>
<script>
import { GetRegionList,GetUsers } from '@/api/services/packageLookupService'
import { GetPackageManageInfoList } from '@/api/services/merchandiseExpressService'

export default{
  name:'ShipPackageManageList',
  data(){
    return{
      ShipId:'',
      tableData:[],
      multipleSelection:[],
      pagination:{
        pageNo:1,
        pageSize:8,
        totalPage:1,
        totalCount:1,
      },
      ShipId:-1,
      Mark:'',
      ExpressNo:'',
      toShowRegionList:[],
      selectedUserId:-1,
      toShowUserList:[],
      selectedMerchandiseType:-1,
      toShowMerchandiseTypeList:[
        {
          key:-1,
          value:-1,
          label:'选择类型'
        },
        {
          key:0,
          value:0,
          label:'TT'
        },
        {
          key:1,
          value:1,
          label:'JJ'
        },
        {
          key:2,
          value:2,
          label:'A'
        },
        {
          key:3,
          value:3,
          label:'B'
        },
        {
          key:4,
          value:4,
          label:'C'
        },
        {
          key:5,
          value:5,
          label:'F'
        },
        {
          key:6,
          value:6,
          label:'M'
        },
        {
          key:7,
          value:7,
          label:'MT'
        },
        {
          key:8,
          value:8,
          label:'MF'
        }
      ],
    }
  },
  created(){
    this.ShipId = this.$route.query.ShipId
    this.getTableData()
    GetUsers().then(res => {
      this.toShowUserList = []
      this.toShowUserList.push({
        key:-1,
        value:-1,
        label:'选择会员',
      })
      res.data.forEach((item, i) => {
        this.toShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRegionList().then(res => {
      this.toShowRegionList = []
      this.toShowRegionList.push({
        key:-1,
        value:-1,
        label:'选择地区',
      })
      res.data.forEach((item, i) => {
        this.toShowRegionList.push({
          key:item.id,
          label:item.name,
          value:item.id
        })
      });
    })
  },
  methods:{
    tableRowClassName({row,rowIndex}){
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    toggleSelection(rows){
      if(rows)
      {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      }
      else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    getTableData(){
      var params = {
        ShipId:this.ShipId,
        UserId:this.selectedUserId,
        Mark:this.Mark,
        ExpressNo:this.ExpressNo,
        ItemType:this.selectedMerchandiseType,
        PageNo:this.pagination.pageNo,
        PageSize:this.pagination.pageSize
      }
      if(params.UserId == -1){
        delete params['UserId']
      }
      if(params.ItemType == -1){
        delete params['ItemType']
      }
      if(params.ExpressNo == ''){
        delete params['ExpressNo']
      }
      if(params.Mark == ''){
        delete params['Mark']
      }
      GetPackageManageInfoList(params).then(res => {
        this.pagination.pageNo = res.data.pageNo
        this.pagination.totalPage = res.data.totalPage
        this.pagination.totalCount = res.data.totalCount
        this.tableData = res.data.collection
      })
    },
    pageNoChange(val){
      console.log('val: ' + val)
      this.pagination.pageNo = val
      this.getTableData()
    },
    onHandleBack(){
      this.$router.back()
    },
    onHandleSearch(){
      this.pagination.pageNo = 1
      this.getTableData()
    },
    handleSelectionChange(val){
      this.multipleSelection = val;
    },
    getItemTypeDisplayText({itemType}){
      var ele = this.toShowMerchandiseTypeList.find(x => x.value == itemType)
      return ele.label
    },
    onHandleExportSmallBag(){
      let link = document.createElement("a");
      link.href = process.env.BASE_URL + '/api/transit/PackageManageInfoListExportSmallBag?shipId=' + this.ShipId;
      link.target = '_blank'
      link.click();
    }
  }
}
</script>
<style scoped>
.create-ship-button{
  float:left;
  margin-bottom:8px;
}
.bottom-left-button-group{
  float:left;
  margin-top:10px;
}
.ship-create-list-pagination{
  margin-top:10px;
}
.updateDialogForm-input-control{
  width:200px;
}
</style>
