<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>入库-小包慢递</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
      <div>
        <span>包裹信息:</span>
        <div class='form-panel-1' id='form-panel-1'>
          <el-input v-model="InputMark" placeholder="请输入面单号" @input="onHandleExpressNoInput" clearable/>&nbsp&nbsp&nbsp
          <el-button type='primary' icon="el-icon-arrow-left" plain @click="onBack">返回</el-button>&nbsp&nbsp
          <el-button type='warning' icon="el-icon-printer" @click="onSearch()">查询</el-button>
        </div>
      </div>
      <div class='form-panel-2' id='form-panel-2' style="margin-top:20px">
        <el-form ref="RuleForm" :model="RuleForm" :rules="FormRules">
          <el-row>
            <el-col :span="4">
              <el-form-item label="运输单号:" prop="ExpressNumber">
                  <el-input v-model="RuleForm.ExpressNumber" clearable/>
              </el-form-item>
              <el-form-item label="用户编号:" prop="SelectedUserId">
                <el-select class="fw" v-model="RuleForm.SelectedUserId">
                    <el-option v-for="item in RuleForm.ToShowUserList"
                               :key="item.key"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="地区:" prop="SelectedRegionId">
                  <el-select class="fw" v-model="RuleForm.SelectedRegionId">
                      <el-option v-for="item in RuleForm.ToShowRegionList"
                                 :key="item.key"
                                 :label="item.label"
                                 :value="item.value">
                      </el-option>
                  </el-select>
              </el-form-item>
              <el-form-item label="唛头:" prop="Mark">
                  <el-input v-model="RuleForm.Mark" clearable/>
              </el-form-item>
              <el-form-item label="件数:" prop="ItemCount">
                  <el-input v-model="RuleForm.ItemCount" clearable/>
              </el-form-item>
              <el-form-item label="物品名称:" prop="ItemName">
                  <el-input v-model="RuleForm.ItemName" clearable/>
              </el-form-item>
              <el-form-item label="包装类型:" prop="SelectedPackType">
                <el-select
                  v-model="RuleForm.SelectedPackType"
                  class="fw"
                  filterable
                  allow-create
                  default-first-option
                  placeholder="包装类型">
                  <el-option
                    v-for="item in RuleForm.ToShowPackTypeList"
                    :key="item.key"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="快递列表:" prop="ExpressList">
                <el-input type="textarea" :rows="5" v-model="RuleForm.ExpressList" clearable/>
              </el-form-item>
              <el-form-item label="货物类型" prop="SelectedMarchandiseType">
                <el-radio-group v-model="RuleForm.SelectedMarchandiseType">
                  <el-radio :label="0">TT</el-radio>
                  <el-radio :label="1">JJ</el-radio>
                  <el-radio :label="2">A</el-radio>
                  <el-radio :label="3">B</el-radio>
                  <el-radio :label="4">C</el-radio>
                  <el-radio :label="5">F</el-radio>
                  <el-radio :label="6">MT</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="尺寸:" prop="SizeInputData">
                <SizeEditor v-model="SizeInputData" style="display: inline-flex;width:100%"/>
              </el-form-item>
              <el-form-item>
                <div>
                  <el-button type='primary' icon="el-icon-arrow-left" plain @click="onBack">上一页</el-button>&nbsp&nbsp
                  <el-button type='warning' icon="el-icon-printer" plain @click="onSubmit">立即提交</el-button>
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="1">&nbsp</el-col>
            <el-col :span="4">
              <el-form-item label="联系人电话:" prop="ContactTelephone">
                  <el-input v-model="RuleForm.ContactTelephone" clearable/>
              </el-form-item>
              <el-form-item label="订单号(送货):" prop="OderNoShipper">
                  <el-input v-model="RuleForm.OderNoShipper" clearable/>
              </el-form-item>
              <el-form-item label="存放位置:" prop="StoreLocation">
                  <el-input v-model="RuleForm.StoreLocation" clearable/>
              </el-form-item>
              <el-form-item label="重量:" prop="Weight">
                  <el-input v-model="RuleForm.Weight" clearable/>
              </el-form-item>
              <el-form-item label="S/体积:" prop="VolumeWeight">
                  <el-input v-model="RuleForm.VolumeWeight" clearable/>
              </el-form-item>
              <el-form-item label="重量/比例:" prop="WeightScale">
                  <el-input v-model="RuleForm.WeightScale" clearable/>
              </el-form-item>
              <el-form-item label="超重货物体积:" prop="MoreThanVolumeWeight">
                  <el-input v-model="RuleForm.MoreThanVolumeWeight" clearable/>
              </el-form-item>
              <el-form-item label="杂费:" prop="MiscPrice">
                  <el-input v-model="RuleForm.MiscPrice" clearable/>
              </el-form-item>
              <el-form-item label="发货人/发货公司:" prop="ShipperName">
                  <el-input v-model="RuleForm.ShipperName" clearable/>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </div>
  </el-card>
</template>
<script>
import SizeEditor from '@/views/components/SizeEditor'
import { GetUsers,GetRegionList} from '@/api/services/packageLookupService'
import { PackageStoringSave,PackageStoringSaveGetMerchandise,
  CargoStorageSmallSlowExpressQuery } from '@/api/services/merchandiseService'
export default {
  name:'PackageStoringSmallBagSlowExpress',
  components:{
    SizeEditor
  },
  data(){
    return{
      SizeInputData:[
        {
          Id:1,
          Length:0,
          Width:0,
          Height:0,
          Weight:0,
          Count:0
        }
      ],
      SearchResult:{},
      InputMark:'',
      RuleForm:{
        Mark:'',
        ItemCount:0,
        ItemName:'',
        ExpressNumber:'',
        ExpressList:'',
        ContactTelephone:'',
        OderNoShipper:'',
        StoreLocation:'',
        Weight:0,
        VolumeWeight:0,
        WeightScale:0,
        MoreThanVolumeWeight:0,
        MiscPrice:0,
        ShipperName:'',
        SelectedUserId:-1,
        SelectedRegionId:-1,
        SelectedPackType:0,
        SelectedMarchandiseType:0,
        ToShowUserList:[],
        ToShowRegionList:[],
        ToShowPackTypeList:[
          {
            key:0,
            value:0,
            label:'纸箱'
          },
          {
            key:1,
            value:1,
            label:'编织袋'
          },
          {
            key:2,
            value:2,
            label:'木架'
          },
          {
            key:3,
            value:3,
            label:'裸装'
          },
          {
            key:4,
            value:4,
            label:'重货'
          },
          {
            key:5,
            value:5,
            label:'超长'
          },
          {
            key:6,
            value:6,
            label:'塑料桶'
          },
          {
            key:7,
            value:7,
            label:'托盘'
          }
        ]
      },
      FormRules: {
        SelectedUserId: { required: true, message: '请选择用户', trigger: [ 'change','blur'] },
        SelectedRegionId: { required: true, message: '请选择地区', trigger: [ 'change','blur'] },
        SelectedMarchandiseType:{ required: true, message: '请选择货物类型', trigger: [ 'change','blur'] },
        ItemCount: { required: true, message: '请输入物品件数', trigger: [ 'change','blur'] },
        ExpressNumber: { required: true, message: '请输入运输单号', trigger: [ 'change','blur'] },
        ItemCount:{ required:true,pattern:/[1-9][0-9]*/,message:'请输入有效物品件数',trigger:['blur','change'] },
      }
    }
  },
  created(){
    GetUsers().then(res => {
      this.RuleForm.ToShowUserList.push({
        key:-1,
        value:-1,
        label:'选择编号'
      })
      res.data.forEach((item, i) => {
        this.RuleForm.ToShowUserList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
    GetRegionList().then(res => {
      this.RuleForm.ToShowRegionList.push({
        key:-1,
        value:-1,
        label:'选择地区'
      })
      res.data.forEach((item, i) => {
        this.RuleForm.ToShowRegionList.push({
          key:item.id,
          value:item.id,
          label:item.name,
        })
      });
    })
  },
  methods:{
    onBack(){
      this.$router.back()
    },
    onSearch(){
      var Mark = this.InputMark
      if(Mark == '' || Mark == null || Mark.toString().Length < 5){
        this.$message({type:'error',message:'请输入面单号'})
        return;
      }
      const params = {
        Mark:Mark,
      }
      CargoStorageSmallSlowExpressQuery(params).then(res => {
        console.log(JSON.stringify(res))
        if(res.data.code == 200){
          document.getElementById('form-panel-2').style.visibility = 'visible'
          this.SearchResult = res.data.content
        }else{
          this.$message({type:'error',message:res.data.message})
        }
      })
    },
    onHandleExpressNoInput(){
      this.InputMark = this.InputMark.trim()
    },
    onSubmit(){
      this.$refs['RuleForm'].validate((valid) => {
        if(!valid){
          this.$message({type:'error',message:'提交信息有误,请检查!'})
          return false;
        }else{
          console.log(`RuleForm： ${JSON.stringify(this.RuleForm)}`)
          const params = {
            Id:this.SearchResult.Id,
            ExpressNumber:this.RuleForm.ExpressNumber,
            UserId:this.RuleForm.SelectedUserId,
            RegionId:this.RuleForm.SelectedRegionId,
            Mark:this.RuleForm.Mark,
            ItemCount:this.RuleForm.ItemCount,
            ItemName:this.RuleForm.ItemName,
            PackingType:this.RuleForm.SelectedPackType,
            ExpressList:this.RuleForm.ExpressList,
            ItemType:this.RuleForm.SelectedMarchandiseType,
            SenderName:this.RuleForm.ShipperName,
            DeliverPhoneNumber:this.RuleForm.ContactTelephone,
            OrderNumber:this.RuleForm.OderNoShipper,
            Location:this.RuleForm.StoreLocation,
            Weight:this.RuleForm.Weight,
            Volume:this.RuleForm.VolumeWeight,
            WeightPercentage:this.RuleForm.WeightScale,
            VolumeWeight:this.RuleForm.MoreThanVolumeWeight,
            Misc:this.RuleForm.MiscPrice,
            DetailSize:this.SizeInputData,
          }
          PackageStoringSave(params).then(res => {
            if(res.data.code == 200)this.$refs['RuleForm'].resetFields()
            this.$message({type:res.data.code !== 200 ? 'error' : 'success',message:res.data.message})
          })
        }
      })
    }
  }
}
</script>
<style scoped>
.el-radio{
  margin:0;
}
.fw{
  width:100%;
}
.form-panel-1{
  display: inline-flex;
  visibility:visible;
}
.form-panel-2{
  visibility:hidden;
}
</style>
