<template>
    <div class="login">
        <el-form :model="loginFormModel" :rules="loginFormRules" ref="loginFormRef" class="form">
            <el-row style="margin-bottom:18px" type="flex" justify="space-between">
                <h3 class="title">云第海运</h3>
                <el-button type="text"></el-button>
            </el-row>
            <el-form-item prop="account">
                <el-input prefix-icon="el-icon-user"
                          type="text"
                          size="medium"
                          v-model="loginFormModel.account"></el-input>
            </el-form-item>
            <el-form-item prop="password">
                <el-input prefix-icon="el-icon-lock"
                          type="password"
                          size="medium"
                          v-model="loginFormModel.password"></el-input>
            </el-form-item>
            <el-form-item>
                <el-checkbox border
                             size="medium"
                             v-model="loginFormModel.remember">记住密码</el-checkbox>
            </el-form-item>
            <el-button class="width-100-percent"
                       icon="el-icon-map-location"
                       size="medium"
                       type="primary"
                       :loading="loading"
                       @click="login">登录</el-button>
        </el-form>
    </div>
</template>

<script>

    import {
        authsToken4Admin
    } from '@/api/services/authService'

    export default {
        name: 'Login',
        data() {
            return {
                loading: false,
                loginFormModel: {
                    account: 'YD',
                    password: '123456',
                    remember: false
                },
                loginFormRules: {
                    account: [
                        { required: true, message: '请输入账号', trigger: 'change' }
                    ],
                    password: [
                        { required: true, message: '请输入密码', trigger: 'change' }
                    ]
                }
            }
        },
        methods: {
            login() {
                this.$refs['loginFormRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.loading = true
                    authsToken4Admin(this.loginFormModel).then(resp => {
                        this.$store.commit('TOKEN', resp.data.token)
                        this.$store.commit('TOKEN_EXPIRE_TIME', resp.data.tokenExpireTime)
                        this.$store.commit('TOKEN_REFRESH_EXPIRE_TIME', resp.data.tokenRefreshExpireTime)
                    }).then(_ => {
                        this.$router.push({ name: 'home' })
                    }).catch(_ => {
                        this.loading = false
                        this.loginFormModel.password = ''
                    })
                })
            }
        }
    }
</script>
<style lang="scss" scoped>
    .login {
        display: grid;
        height: 100vh;
        place-items: center;

        .form {
            box-shadow: 1px 1px 3px 3px gray;
            background: white;
            padding: 20px;
            width: 275px;

            .title {
                font-size: 1.375em;
            }
        }
    }
</style>
