<template>
    <div class="quillEditorExample">

        <el-row :gutter="8">

            <el-col :sm="6">

                <el-upload id="uploader"
                           style="display:none"
                           :action="uploadUrl"
                           :before-upload="uploaderBeforeUpload"
                           :multiple="false"
                           :on-success="uploaderOnSuccess"
                           :show-file-list="false" />

                <quill-editor ref="quillEditor"
                              v-model="content"
                              :options="editorOptions"
                              @blur="quillEditorBlur($event)"
                              @change="quillEditorChange($event)"
                              @focus="quillEditorFocus($event)"
                              @ready="quillEditorReady($event)" />

            </el-col>

            <el-col :sm="6" style="padding-top:42px">

                <div class="ql-container ql-snow"
                     style="border:unset">

                    <div class="ql-editor"
                         v-html="content">
                    </div>

                </div>

            </el-col>

        </el-row>

    </div>
</template>

<script>
    export default {
        name: 'QuillEditorExample', // https://quilljs.com/docs/

        data() {
            return {
                content: '<h1>HELLO WORLD</h1><p><br></p><p><span style="background-color: rgb(255, 255, 255); ">Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies. Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volutpat a, convallis ac, laoreet enim. Phasellus fermentum in, dolor. Pellentesque facilisis. Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac</span></p><p><br></p><p><img src="http://localhost:8000/uploads/6C825ED7EA4CD25657288AB4F7D0227F.png"></p><p><br></p><p><span style="background-color: rgb(255, 255, 255); ">Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies. Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volutpat a, convallis ac, laoreet enim. Phasellus fermentum in, dolor. Pellentesque facilisis. Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac</span></p>',

                editorOptions: {
                    placeholder: '',
                    modules: {
                        toolbar: {
                            container: [
                                [
                                    {
                                        header: [1, 2, 3, false]
                                    }
                                ],
                                ['bold', 'italic', 'underline'],
                                ['image']
                            ],
                            handlers: {
                                image: function (value) {
                                    if (value) {
                                        document.querySelector('#uploader input').click()
                                    } else {
                                        this.quill.format('image', false)
                                    }
                                }
                            }
                        }
                    }
                },

                uploadUrl: process.env.BASE_URL + '/api/uploads'
            }
        },

        methods: {
            uploaderBeforeUpload(file) {
                //
            },
            uploaderOnSuccess(resp) {
                let quill = this.$refs['quillEditor'].quill
                if (resp) {
                    let length = quill.getSelection().index;
                    quill.insertEmbed(length, 'image', process.env.BASE_URL + resp)
                    quill.setSelection(length + 1)
                } else {
                    //
                }
            },
            quillEditorBlur(editor) {
                //
            },
            quillEditorFocus(editor) {
                //
            },
            quillEditorReady(editor) {
                //
            },
            quillEditorChange(editor) {
                //
            }
        }
    }
</script>

<style lang="scss" scoped>
    .quillEditorExample {
    }
</style>
