<template>
    <div class="exportExample">

        <el-button icon="el-icon-tickets"
                   type="primary"
                   @click="getExcel">基于模板导出</el-button>

    </div>
</template>

<script>
    import {
        saveAs
    } from 'file-saver'

    import {
        excel
    } from '@/api/services/exampleService'

    export default {
        name: 'ExportExample',
        data() {
            return {
                
            }
        },
        methods: {
            getExcel() {
                excel().then(resp => {
                    console.log(resp.data.type)
                    let blob = new Blob([resp.data], {
                        type: resp.data.type
                    })
                    let filename = resp.headers['x-filename']
                    saveAs(blob, filename)
                }).catch(_ => {
                    //
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .exportExample {
    }
</style>
