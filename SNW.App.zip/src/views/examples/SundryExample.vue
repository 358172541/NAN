<template>
    <div class="sundryExample">
        <el-button icon="el-icon-tickets"
                   type="primary"
                   @click="getBarcode">条形码</el-button>

        <el-button icon="el-icon-tickets"
                   type="primary"
                   @click="getQrcode">二维码</el-button>

        <img :src="barcodeSrc" alt="" />

        <img :src="qrcodeSrc" alt="" />
    </div>
</template>

<script>
    import {
        barcode,
        qrcode
    } from '@/api/services/exampleService'

    export default {
        name: 'SundryExample',
        data() {
            return {
                barcodeSrc: '',
                qrcodeSrc: ''
            }
        },
        methods: {
            getBarcode() {
                barcode().then(resp => {
                    this.barcodeSrc = resp.data
                }).catch(_ => {
                    //
                })
            },
            getQrcode() {
                qrcode().then(resp => {
                    this.qrcodeSrc = resp.data
                }).catch(_ => {
                    //
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .sundryExample {
    }
</style>
