<template>
    <div class="printExample">

        <el-button icon="el-icon-tickets"
                   type="primary"
                   @click="print">打印</el-button>

        <div class="a4 box-shadow margin-top">
            <div id="printElement">

                <hr />
                <br />
                <div>Lorem ipsum dolor sit amet enim.</div>
                <br />
                <hr />
                <br />
                <div>
                    Lorem ipsum dolor sit amet enim.
                    Etiam ullamcorper.
                    Suspendisse a pellentesque dui, non felis.
                    Maecenas malesuada elit lectus felis, malesuada ultricies.
                    Curabitur et ligula.
                    Ut molestie a, ultricies porta urna.
                    Vestibulum commodo volutpat a, convallis ac, laoreet enim.
                    Phasellus fermentum in, dolor.
                    Pellentesque facilisis.
                    Nulla imperdiet sit amet magna.
                    Vestibulum dapibus, mauris nec malesuada fames ac
                </div>
                <br />
                <hr />
                <br />
                <div>
                    Lorem ipsum dolor sit amet enim.
                    Etiam ullamcorper.
                    Suspendisse a pellentesque dui, non felis.
                    Maecenas malesuada elit lectus felis, malesuada ultricies.
                    Curabitur et ligula.
                    Ut molestie a, ultricies porta urna.
                    Vestibulum commodo volutpat a, convallis ac, laoreet enim.
                    Phasellus fermentum in, dolor.
                    Pellentesque facilisis.
                    Nulla imperdiet sit amet magna.
                    Vestibulum dapibus, mauris nec malesuada fames ac
                </div>
                <br />
                <hr />
                <br />
                <div>
                    Lorem ipsum dolor sit amet enim.
                    Etiam ullamcorper.
                    Suspendisse a pellentesque dui, non felis.
                    Maecenas malesuada elit lectus felis, malesuada ultricies.
                    Curabitur et ligula.
                    Ut molestie a, ultricies porta urna.
                    Vestibulum commodo volutpat a, convallis ac, laoreet enim.
                    Phasellus fermentum in, dolor.
                    Pellentesque facilisis.
                    Nulla imperdiet sit amet magna.
                    Vestibulum dapibus, mauris nec malesuada fames ac
                </div>
                <br />
                <hr />
                <br />
                <div>
                    Lorem ipsum dolor sit amet enim.
                    Etiam ullamcorper.
                    Suspendisse a pellentesque dui, non felis.
                    Maecenas malesuada elit lectus felis, malesuada ultricies.
                    Curabitur et ligula.
                    Ut molestie a, ultricies porta urna.
                    Vestibulum commodo volutpat a, convallis ac, laoreet enim.
                    Phasellus fermentum in, dolor.
                    Pellentesque facilisis.
                    Nulla imperdiet sit amet magna.
                    Vestibulum dapibus, mauris nec malesuada fames ac
                </div>
                <br />
                <hr />
                <br />
                <div>
                    Lorem ipsum dolor sit amet enim.
                    Etiam ullamcorper.
                    Suspendisse a pellentesque dui, non felis.
                    Maecenas malesuada elit lectus felis, malesuada ultricies.
                    Curabitur et ligula.
                    Ut molestie a, ultricies porta urna.
                    Vestibulum commodo volutpat a, convallis ac, laoreet enim.
                    Phasellus fermentum in, dolor.
                    Pellentesque facilisis.
                    Nulla imperdiet sit amet magna.
                    Vestibulum dapibus, mauris nec malesuada fames ac
                </div>
                <br />
                <hr />
                <br />
                <div>
                    Lorem ipsum dolor sit amet enim.
                    Etiam ullamcorper.
                    Suspendisse a pellentesque dui, non felis.
                    Maecenas malesuada elit lectus felis, malesuada ultricies.
                    Curabitur et ligula.
                    Ut molestie a, ultricies porta urna.
                    Vestibulum commodo volutpat a, convallis ac, laoreet enim.
                    Phasellus fermentum in, dolor.
                    Pellentesque facilisis.
                    Nulla imperdiet sit amet magna.
                    Vestibulum dapibus, mauris nec malesuada fames ac
                </div>
                <br />
                <hr />
                <br />
                <div>
                    Lorem ipsum dolor sit amet enim.
                    Etiam ullamcorper.
                    Suspendisse a pellentesque dui, non felis.
                    Maecenas malesuada elit lectus felis, malesuada ultricies.
                    Curabitur et ligula.
                </div>
                <br />
                <hr />

            </div>
        </div>

    </div>
</template>

<script>
    import printJS from 'print-js'

    export default {
        name: 'PrintExample', // https://printjs.crabbly.com/
        data() {
            return {

            }
        },
        methods: {
            print() {
                printJS({
                    printable: 'printElement',
                    type: 'html',
                    scanStyles: true,
                    targetStyles: ['*']
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .printExample {
        .a4 {
            width: 19cm;
            max-height: 27.7cm;
            padding: 1cm;
        }
    }
</style>
