<template>
    <div class="drawerExample">

        <el-drawer title="外层"
                   size="384px"
                   style="margin-top:55px"
                   z-index="1"
                   :append-to-body="true"
                   :modal-append-to-body="false"
                   :visible.sync="drawer"
                   :wrapperClosable="false">
            <el-scrollbar>

                <div style="margin: 20px">
                    <el-button @click="innerDrawer = true">打开内层</el-button>
                    <el-drawer title="内层"
                               size="320px"
                               style="margin-top:55px"
                               z-index="1"
                               :append-to-body="true"
                               :visible.sync="innerDrawer"
                               :wrapperClosable="false">

                        <div style="margin:20px">
                            _(:зゝ∠)_
                        </div>

                    </el-drawer>
                </div>

            </el-scrollbar>

        </el-drawer>

    </div>
</template>

<script>
    export default {
        name: 'DrawerExample',
        data() {
            return {
                drawer: true,
                innerDrawer: false
            }
        }
    }
</script>

<style lang="scss" scoped>
    .drawerExample {
    }
</style>
