<template>
    <div class="importExample">

        <el-row type="flex" justify="space-between">
            <div style="align-items:center;display:flex">
                <el-upload :action="importUrl"
                           :on-success="onSuccess"
                           :show-file-list="false">
                    <el-button type="primary">选择文件</el-button>
                </el-upload>
                <span style="margin-left:4px">{{fileName}}</span>
            </div>

            <el-button type="success" v-if="fileName!==''">开始导入</el-button>
        </el-row>

        <el-table border
                  class="margin-top"
                  :data="data"
                  :row-key="'id'">

            <el-table-column align="center" type="index" width="40">
                <template slot="header">
                    <i class="el-icon-s-operation" />
                </template>
            </el-table-column>

            <el-table-column align="left" label="Col A" prop="colA"></el-table-column>

            <el-table-column align="left" label="Col B" prop="colB"></el-table-column>

            <el-table-column align="left" label="Col C" prop="colC"></el-table-column>

        </el-table>

    </div>
</template>

<script>
    export default {
        name: 'ImportExample',
        data() {
            return {
                data: [],
                fileName: '',
                importUrl: process.env.BASE_URL + '/api/examples/import'
            }
        },
        methods: {
            onSuccess(data, file, _) {
                this.data = data
                this.fileName = file.name;
            }
        }
    }
</script>

<style lang="scss" scoped>
    .importExample {
    }
</style>
