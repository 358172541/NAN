<template>
    <div class="param">
        Param
    </div>
</template>

<script>
    export default {
        name: 'Param',
        data() {
            return {

            }
        }
    }
</script>

<style lang="scss" scoped>
    .param {
    }
</style>
