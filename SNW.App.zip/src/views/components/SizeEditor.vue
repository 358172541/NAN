<template>
  <div class="app-container home">
    <el-form ref="historyForm" :model="formModel" size="small">
      <el-table
        :data="value"
        style="min-width:600px;width:100%;"
        class="list-table"
        size="mini"
        border>
        <el-table-column label="长/厘米" align="center" prop="Length">
          <template slot-scope="scope">
            <el-input class="text-input-control"
              v-model="scope.row.Length"
              :clearable="clearable"
              @focus="onFocusLengthHandle(scope.row.Id)"
              @change="onHandleLengthChange"/>
          </template>
        </el-table-column>
        <el-table-column label="宽/厘米" align="center" prop="Width">
          <template slot-scope="scope">
            <el-input class="text-input-control"
              :min="0" :max="99999"
              v-model="scope.row.Width"
              :clearable="clearable"
              @focus="onFocusWidthHandle(scope.row.Id)"
              @change="onHandleWidthChange"/>
          </template>
        </el-table-column>
        <el-table-column label="高/厘米" align="center" prop="Height">
          <template slot-scope="scope">
            <el-input class="text-input-control" :min="0"
              :max="99999" v-model="scope.row.Height" :clearable="clearable"
              @focus="onFocusHeightHandle(scope.row.Id)"
              @change="onHandleHeightChange"/>
          </template>
        </el-table-column>
        <el-table-column label="体积" align="center" prop="Weight">
          <template slot-scope="scope">
            <span>{{scope.row.Weight}}</span>
          </template>
        </el-table-column>
        <el-table-column label="件数" align="center" prop="Count">
          <template slot-scope="scope">
            <el-input size="mini"
            class="text-input-control"
            :min="0" :max="99999" v-model="scope.row.Count"
            :clearable="clearable" @focus="onFocusCountHandle(scope.row.Id)"/>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button class="text-input-control" type="primary" size="small" @click.native.prevent="deleteRow(scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="group-controls">
        <el-button type='primary' plain @click="addRow(1)">增加一行</el-button>
        <div class="group-controls-batch-input">
          <el-input-number class="text-input-control" v-model="batchCount" :min="0" :max="9999" style="margin-right:15px"/>
          <el-button type='primary' plain @click="addBatchRow()">批量增加</el-button>
        </div>
      </div>
    </el-form>
  </div>
</template>
<script>
export default {
  name: "SizeEditor",
  props:{
    clearable:{
      type:Boolean,
      default:false
    },
    value:{
      default:[]
    }
  },
  data(){
    return{
      batchCount:1,
      formModel:{},
    };
  },
  methods:{
    changeVal(val){
      this.value = val
      this.$emit('input',this.value)
    },
    addRow() {
      this.value.push({
        id:this.value.Length,
        Length:0,
        Width:0,
        Height:0,
        Weight:0,
        Count:0
      })
    },
    deleteRow (index) {
      this.value.splice(index, 1)
    },
    addBatchRow(){
      var count = this.batchCount;
      for(var i = 0;i < count;i++){
        this.value.push({
          id:this.value.Length,
          Length:0,
          Width:0,
          Height:0,
          Weight:0,
          Count:0
        })
      }
    },
    onFocusLengthHandle(Id){
      var ele = this.value.find(v => v.Id == Id);
      if(ele != null && ele.Length === 0 || ele.Length === '0'){
        ele.Length = ''
      }
    },
    onFocusWidthHandle(Id){
      var ele = this.value.find(v => v.Id == Id);
      if(ele != null && ele.Width === 0 || ele.Width === '0'){
        ele.Width = ''
      }
    },
    onFocusHeightHandle(Id){
      var ele = this.value.find(v => v.Id == Id);
      if(ele != null && ele.Height === 0 || ele.Height === '0'){
        ele.Height = ''
      }
    },
    onFocusCountHandle(Id){
      var ele = this.value.find(v => v.Id == Id);
      if(ele != null && ele.Count === 0 || ele.Count === '0'){
        ele.Count = ''
      }
    },
    onShowVolume(){
      for(var i = 0;i < this.value.length;i++){
        var ele = this.value[i]
        ele.Weight = ele.Length * ele.Width * ele.Height / 1000000
        ele.Weight = ele.Weight.toFixed(6)
      }
    },
    onHandleLengthChange(){
      this.onShowVolume()
    },
    onHandleWidthChange(){
      this.onShowVolume()
    },
    onHandleHeightChange(){
      this.onShowVolume()
    }
  }
};
</script>
<style>
.group-controls{
  display: flex;
  margin-top:20px;
}
.group-controls-batch-input{
  margin-left: 20px;
}
.text-input-control .el-input__inner{
  text-align:center
}
</style>
