<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>货物-派送中</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="packageDelivering">

        <el-row :gutter="8">

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="类型"
                           v-model="packageDeliveringTable.searchParams.itemType">
                    <el-option v-for="item in lookupItemTypes"
                               :key="item.key"
                               :label="item.value"
                               :value="item.key">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="会员"
                           v-model="packageDeliveringTable.searchParams.memberId">
                    <el-option v-for="item in lookupMembers"
                               :key="item.id"
                               :label="item.account"
                               :value="item.id">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="地区"
                           v-model="packageDeliveringTable.searchParams.regionId">
                    <el-option v-for="item in lookupRegions"
                               :key="item.id"
                               :label="item.number"
                               :value="item.id">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="货柜"
                           v-model="packageDeliveringTable.searchParams.containerId">
                    <el-option v-for="item in lookupContainers"
                               :key="item.id"
                               :label="item.number"
                               :value="item.id">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="派送路线"
                           v-model="packageDeliveringTable.searchParams.deliveryRouteId">
                    <el-option v-for="item in lookupDeliveryRoutes"
                               :key="item.id"
                               :label="item.number"
                               :value="item.id">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="派送地区"
                           v-model="packageDeliveringTable.searchParams.deliveryRegionId">
                    <el-option v-for="item in lookupDeliveryRegions"
                               :key="item.id"
                               :label="item.number"
                               :value="item.id">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-input placeholder="运单号"
                          v-model="packageDeliveringTable.searchParams.expressNumber">
                </el-input>
            </el-col>

            <el-col :span="2">
                <el-input placeholder="唛头"
                          v-model="packageDeliveringTable.searchParams.mark">
                </el-input>
            </el-col>

            <el-col :span="4">
                <el-button icon="el-icon-search"
                           type="primary"
                           @click="searchPackageDelivering">查询</el-button>
            </el-col>

        </el-row>

        <el-table border
                  class="margin-top"
                  :data="packageDeliveringTable.pagedResult.items"
                  :row-key="'id'"
                  :row-style="packageDeliveringTableRowStyle">

            <el-table-column align="center" type="selection" width="40"></el-table-column>

            <el-table-column align="left" label="类型" prop="itemTypeDisplay"></el-table-column>

            <el-table-column align="left" label="流水号" prop="expressNumber"></el-table-column>

            <el-table-column align="left" label="唛头" prop="mark"></el-table-column>

            <el-table-column align="center" label="会员编号" prop="memberAccount"></el-table-column>

            <el-table-column align="center" label="柜号" prop="containerNumber"></el-table-column>

            <el-table-column align="left" label="地区" prop="regionNumber"></el-table-column>

            <el-table-column align="left" label="派送地区" prop="deliveryRegionNumber"></el-table-column>

            <el-table-column align="center" label="地址" prop="detailAddress">
                <template slot-scope="scope">
                    <el-popover placement="bottom" trigger="click" width="300">
                        <el-descriptions border :column="1" :labelStyle="{ width: '70px' }">
                            <el-descriptions-item label="收件人">{{scope.row.name}}</el-descriptions-item>
                            <el-descriptions-item label="公司名称">{{scope.row.companyName}}</el-descriptions-item>
                            <el-descriptions-item label="电话号码">{{scope.row.phoneNumber}}</el-descriptions-item>
                            <el-descriptions-item label="手机号码">{{scope.row.mobilePhoneNumber}}</el-descriptions-item>
                            <el-descriptions-item label="邮编">{{scope.row.postalCode}}</el-descriptions-item>
                            <el-descriptions-item label="详细地址">{{scope.row.detailAddress}}</el-descriptions-item>
                        </el-descriptions>
                        <el-link type="primary" slot="reference" :underline="false">查看</el-link>
                    </el-popover>
                </template>
            </el-table-column>

            <el-table-column align="left" label="派送路线" prop="deliveryRouteNumber"></el-table-column>

            <el-table-column align="center" label="件数" prop="itemCount"></el-table-column>

            <el-table-column align="center" label="重量" prop="weight"></el-table-column>

            <el-table-column align="center" label="体积" prop="volume"></el-table-column>

            <el-table-column align="left" label="物品名称" prop="itemName"></el-table-column>

            <el-table-column align="center" label="提货时间" prop="pickupTime"></el-table-column>
        </el-table>

        <el-pagination background
                       class="margin-top"
                       layout="prev, pager, next, total"
                       :current-page="packageDeliveringTable.pagedParams.page"
                       :page-size="packageDeliveringTable.pagedParams.pageSize"
                       :pager-count="5"
                       :total="packageDeliveringTable.pagedResult.totalCount"
                       @current-change="searchPackageDeliveringPageChange"
                       @size-change="searchPackageDeliveringPageSizeChange">
        </el-pagination>

    </div>
  </el-card>
</template>

<script>
    import {
        getLookupContainers,
        getLookupDeliveryRegions,
        getLookupDeliveryRoutes,
        getLookupItemTypes,
        getLookupMembers,
        getLookupRegions,
    } from '@/api/services/lookupService';

    import {
        packageDeliveringSearch
    } from '@/api/services/packageDeliveringService'

    export default {
        name: 'PackageDelivering',
        data() {
            return {
                lookupContainers: [],
                lookupDeliveryRegions: [],
                lookupDeliveryRoutes: [],
                lookupItemTypes: [],
                lookupMembers: [],
                lookupRegions: [],
                packageDeliveringTable: {
                    searchParams: {
                        itemType: null,
                        memberId: null,
                        balanceStatus: null,
                        regionId: null,
                        createTimeFrom: '',
                        createTimeTo: '',
                        expressNumber: '',
                        containerNumber: '',
                        mark: ''
                    },
                    pagedParams: {
                        itemType: null,
                        memberId: null,
                        balanceStatus: null,
                        regionId: null,
                        createTimeFrom: '',
                        createTimeTo: '',
                        expressNumber: '',
                        containerNumber: '',
                        mark: '',
                        page: 1,
                        pageSize: 15
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                }
            }
        },

        methods: {
            searchPackageDelivering() {
                let table = this.packageDeliveringTable
                table.pagedParams.itemType = table.searchParams.itemType
                table.pagedParams.memberId = table.searchParams.memberId
                table.pagedParams.balanceStatus = table.searchParams.balanceStatus
                table.pagedParams.regionId = table.searchParams.regionId
                table.pagedParams.createTimeFrom = table.searchParams.createTimeFrom
                table.pagedParams.createTimeTo = table.searchParams.createTimeTo
                table.pagedParams.expressNumber = table.searchParams.expressNumber
                table.pagedParams.containerNumber = table.searchParams.containerNumber
                table.pagedParams.mark = table.searchParams.mark
                table.pagedParams.page = 1
                packageDeliveringSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchPackageDeliveringPageChange(page) {
                let table = this.packageDeliveringTable
                table.pagedParams.page = page
                packageDeliveringSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchPackageDeliveringPageSizeChange(pageSize) {
                let table = this.packageDeliveringTable
                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize
                packageDeliveringSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            exportPackageDelivering() {

            },
            exportPackageDeliveringM() {

            },
            packageDeliveringTableRowStyle({ row }) {
                return {
                    'background': row.Background
                }
            }
        },

        created() {
            getLookupContainers().then(resp => {
                this.lookupContainers = resp.data
            }).catch(_ => {
                //
            })
            getLookupDeliveryRegions().then(resp => {
                this.lookupDeliveryRegions = resp.data
            }).catch(_ => {
                //
            })
            getLookupDeliveryRoutes().then(resp => {
                this.lookupDeliveryRoutes = resp.data
            }).catch(_ => {
                //
            })
            getLookupItemTypes().then(resp => {
                this.lookupItemTypes = resp.data
            }).catch(_ => {
                //
            })
            getLookupMembers().then(resp => {
                this.lookupMembers = resp.data
            }).catch(_ => {
                //
            })
            getLookupRegions().then(resp => {
                this.lookupRegions = resp.data
            }).catch(_ => {
                //
            })
            this.searchPackageDelivering();
        }
    }
</script>

<style lang="scss" scoped>
    .packageDelivering {
    }
</style>
