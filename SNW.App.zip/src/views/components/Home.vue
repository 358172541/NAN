<template>
  <div class="home-index-box">


    <div style="width: 100%; height: 20vh;">

      <el-card class="card">
        <i class="el-icon-s-custom" style="font-size: 150px; background-color: white; border: 0; color: #409EFF; " />
      </el-card>

      <el-card class="card">
        <i class="el-icon-s-comment" style="font-size: 150px; background-color: white; border: 0; color: #67C23A; " />
      </el-card>

      <el-card class="card">
        <i class="el-icon-s-shop" style="font-size: 150px; background-color: white; border: 0; color: #E6A23C; " />
      </el-card>

      <el-card class="card">
        <i class="el-icon-message-solid" style="font-size: 150px; background-color: white; border: 0; color: #F56C6C; " />
      </el-card>
    </div>

    <div style="width:100%;height:35vh;margin-top:1vh;">
      <div style="float: left; width: 49.8%; height: 100%; ">
        <!--饼状图and环形图-->
        <el-card>
          <div class="graph-pie-warp">
            <el-row :gutter="30">
              <el-col :span="12">
                <div id="home_gathering_source"
                     style="height:30vh; "></div>
              </el-col>
            </el-row>
          </div>
        </el-card>
      </div>
      <div style="float: left; width: 49.8%; height: 100%;">
        <!--卡片视图区域-->
        <el-card>
          <!-- 2.为ECharts准备一个具备大小（宽高）的Dom -->
          <div id="main" style="width:100%;height:30vh;"></div>
        </el-card>

      </div>
    </div>


    <div style="width:100%;height:40vh;">
      <el-card>
        <div id="main" style="width: 100%;height:40vh;" ref="main">
        </div>
      </el-card>

    </div>

  </div>
</template>

<script>
  import * as ECharts from 'echarts'
  let gatheringSourceOption = {
    title: {
      text: '最近7日占比图:',
      left: 'left'
    },
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    legend: {
      type: 'scroll',
      orient: 'vertical',
      right: 0,
      top: 'center',
      icon: 'circle',
      selectedMode: 'multiple',
      formatter: (name) => { //legend显示数据格式化,每一个 legend 渲染都会回调这个函数
        let data = gatheringSourceOption.series[0].data //获取当前对象的series.data
        let total = 0 //数据对象总和存放
        let tarValue = 0 // 当前对象的value 值
        for (let i = 0, l = data.length; i < l; i++) { //循环饼状图数据对象
          total += data[i].value  //计算出当前对象总和
          if (data[i].name == name) {
            tarValue = data[i].value //存放当前渲染的legend 对象
          }
        }
        let p = (tarValue / total * 100).toFixed(2) //百分比保留小数点后两位
        return `${name}  |  ${p}%  `
      }
    },
    series: [
      {
        name: '最近7日占比',
        type: 'pie',
        radius: '60%',
        center: ['25%', '55%'],
        selectedMode: 'single',
        data: [],
        label: {
          show: false
        },
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  }



  export default {
    name: 'HelloWorld',

    data() {
      return {
        gatheringSourceOption,
      }
    },
    mounted() {
      this.getProportionData();//收款的饼图的数据

      var myChart = ECharts.init(document.getElementById('main'));

      // 4.指定图表的配置项和数据
      var option = {
        title: {
          text: 'ECharts入门'
        },
        tooltip: {},
        legend: {
          data: ['销量']
        },
        xAxis: {
          data: ['苹果', '草莓', '西瓜', '桔子', '葡萄', '柿子']
        },
        yAxis: {},
        series: [{
          name: '销量',
          type: 'bar',
          data: [7.14, 14.29, 14.29, 21.43, 14.29, 28.57]
        }]
      };

      // 5.使用刚指定的配置项和数据显示图表。
      myChart.setOption(option);
      this.test();
    },
    methods: {
      eChartsInit(domId, theme, opt) {
        ECharts.init(document.getElementById(domId), theme).setOption(opt)
        window.addEventListener('resize', () => {
          ECharts.init(document.getElementById(domId), theme).resize()
        })
      },
      //获取收款饼图的数据
      getProportionData() {
        let _this = this;
        var sourceList = [
          { value: 1, name: '苹果' },
          { value: 2, name: '草莓' },
          { value: 2, name: '西瓜' },
          { value: 3, name: '桔子' },
          { value: 2, name: '葡萄' },
          { value: 4, name: '柿子' }
        ]
        this.gatheringSourceOption.series[0].data = sourceList
        this.eChartsInit('home_gathering_source', 'light', this.gatheringSourceOption)

      },
      //折线图
      test() {
        // 官方示例 var myChart = echarts.init(document.getElementById('main'));
        const myChart = ECharts.init(this.$refs.main); // 我们可以这样写
        //
        const time = (function () { // 立即执行函数
          let now = new Date();  // 获得当前的时间
          let res = []; // 存放时间的数组
          let len = 5; // 要存几个时间？
          while (len--) {
            res.unshift(now.toLocaleTimeString().replace(/^\D*/, '')); // 转换时间，大家可以打印出来看一下
            now = new Date(+now - 2000) // 延迟几秒存储一次？
          }
          return res;
        })();
        const dataOne = (function () { // 5个随机数，大家可随意定义
          let res = [];
          let len = 5;
          while (len--) {
            res.push(Math.round(Math.random() * 1000));
          }
          return res;
        })();
        const dataTwo = (function () { // 5个随机数
          let res = [];
          let len = 5;
          while (len--) {
            res.push(Math.round(Math.random() * 1000));
          }
          return res;
        })();
        //配置项，可以去查一下官方文档
        let options = {
          title: {
            text: '动态',
            textStyle: {
              color: 'black'
            }
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross',
              label: {
                backgroundColor: '#283b56'
              }
            }
          },
          legend: {},
          xAxis: {
            type: 'category',
            data: time, // 把时间组成的数组接过来，放在x轴上
            boundaryGap: true
          },
          yAxis: {
            type: 'value'
          },
          series: [
            {
              data: dataOne,
              type: 'line',
              name: '测试一',
              markPoint: {
                data: [
                  { type: 'max', name: '最大值' },
                  { type: 'min', name: '最小值' }
                ]
              },
              markLine: {
                data: [{ type: 'average', name: '平均值' }]
              }
            },
            {
              data: dataTwo,
              name: '测试二',
              type: 'line',
              markPoint: {
                data: [
                  { type: 'max', name: '最大值' },
                  { type: 'min', name: '最小值' }
                ]
              },
              markLine: {
                data: [{ type: 'average', name: '平均值' }]
              }
            }
          ]
        }
        setInterval(function () {
          let nowTime = new Date().toLocaleTimeString().replace(/^\D*/, '');
          time.shift()
          time.push(nowTime)
          dataOne.shift()
          dataOne.push(Math.round(Math.random() * 1000))
          dataTwo.shift()
          dataTwo.push(Math.round(Math.random() * 1000))
          console.log(dataOne)
          //很多朋友可能要接后端接口,把数据替换下来既可以了
          // axios.get('你的url').then(res => {
          //   console.log(res)
          // })
          myChart.setOption({
            xAxis: [
              {
                data: time
              }
            ],
            series: [
              {
                data: dataOne
              },
              {
                data: dataTwo
              }
            ]
          })
        }, 2000)
        myChart.setOption(options)
      },

    }
  }




</script>

<style scoped>
  .card {
    width: 24.8%;
    height: 20vh;
    float: left;
  }
</style>
