<template>
    <div class="memberType">
        Member Type
    </div>
</template>

<script>
    export default {
        name: 'MemberType',
        data() {
            return {

            }
        }
    }
</script>

<style lang="scss" scoped>
    .memberType {
    }
</style>
