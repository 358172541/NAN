<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>基础信息</el-breadcrumb-item>
              <el-breadcrumb-item>权限</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="permission">

          <el-button icon="el-icon-circle-plus-outline"
                     type="success"
                     @click="createPermission">新增</el-button>

          <el-table border
                    class="margin-top"
                    :data="structureLevel4Permissions"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" prop="display">
                  <template slot="header">
                      <i class="el-icon-view" />
                  </template>
                  <template slot-scope="scope">
                      <span :style="{ marginLeft: (scope.row.level - 1) * 20 + 'px' }">
                          <i :class="[scope.row.icon]" />
                          <span>{{ scope.row.display }}</span>
                      </span>
                  </template>
              </el-table-column>

              <el-table-column align="center" label="类型" prop="typeDisplay"></el-table-column>

              <el-table-column align="left" label="编号" prop="number"></el-table-column>

              <el-table-column align="left" label="图标" prop="icon"></el-table-column>

              <el-table-column align="left" label="标题" prop="display"></el-table-column>

              <el-table-column align="center" label="排序" prop="sort"></el-table-column>

              <el-table-column align="center" label="是否启用" prop="enabled">
                  <template slot-scope="scope">
                      <el-switch nocursor
                                 :value="scope.row.enabled">
                      </el-switch>
                  </template>
              </el-table-column>

              <el-table-column align="left" label="备注" prop="remark"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit-outline"
                                 size="mini"
                                 type="warning"
                                 @click="updatePermission(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                 size="mini"
                                 type="danger"
                                 @click="deletePermission(scope.row)">删除</el-button>
                  </template>
              </el-table-column>

          </el-table>

          <!---->

          <el-dialog title="新增"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="createPermissionDialog.visible">

              <el-form label-width="64px"
                       ref="createPermissionRef"
                       :model="createPermissionDialog.formModel"
                       :rules="createPermissionDialog.formRules">

                  <el-form-item label="所属父级"
                                prop="parentId">
                      <el-select clearable
                                 v-model="createPermissionDialog.formModel.parentId">
                          <el-option v-for="item in structureLevel4LookupPermissions"
                                     :key="item.id"
                                     :label="item.display"
                                     :value="item.id">
                              <span :style="{ marginLeft: (item.level - 1) * 20 + 'px' }">
                                  <i :class="item.icon" />
                                  <span>{{ item.display }}</span>
                              </span>
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="类型"
                                prop="type">
                      <el-select clearable
                                 v-model="createPermissionDialog.formModel.type">
                          <el-option v-for="item in lookupPermissionTypes"
                                     :key="item.value"
                                     :label="item.display"
                                     :value="item.value">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="编号"
                                prop="number">
                      <el-input v-model="createPermissionDialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="图标"
                                prop="icon">
                      <el-input v-model="createPermissionDialog.formModel.icon">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="标题"
                                prop="display">
                      <el-input v-model="createPermissionDialog.formModel.display">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="排序"
                                prop="sort">
                      <el-input-number controls-position="right"
                                       v-model="createPermissionDialog.formModel.sort"
                                       :min="111"
                                       :max="999">
                      </el-input-number>
                  </el-form-item>

                  <el-form-item label="是否可用"
                                prop="enabled">
                      <el-switch v-model="createPermissionDialog.formModel.enabled">
                      </el-switch>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createPermissionDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="createPermissionDialog.saveLoading"
                                 @click="createPermissionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="createPermissionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="updatePermissionDialog.visible">

              <el-form label-width="64px"
                       ref="updatePermissionRef"
                       :model="updatePermissionDialog.formModel"
                       :rules="updatePermissionDialog.formRules">

                  <el-form-item label="所属父级"
                                prop="parentId">
                      <el-select clearable
                                 v-model="updatePermissionDialog.formModel.parentId">
                          <el-option v-for="item in structureLevel4LookupPermissions"
                                     :key="item.id"
                                     :label="item.display"
                                     :value="item.id">
                              <span :style="{ marginLeft: (item.level - 1) * 20 + 'px' }">
                                  <i :class="item.icon" />
                                  <span>{{ item.display }}</span>
                              </span>
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="类型"
                                prop="type">
                      <el-select clearable
                                 v-model="updatePermissionDialog.formModel.type">
                          <el-option v-for="item in lookupPermissionTypes"
                                     :key="item.value"
                                     :label="item.display"
                                     :value="item.value">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="编号"
                                prop="number">
                      <el-input v-model="updatePermissionDialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="图标"
                                prop="icon">
                      <el-input v-model="updatePermissionDialog.formModel.icon">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="标题"
                                prop="display">
                      <el-input v-model="updatePermissionDialog.formModel.display">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="排序"
                                prop="sort">
                      <el-input-number controls-position="right"
                                       v-model="updatePermissionDialog.formModel.sort"
                                       :min="111"
                                       :max="999">
                      </el-input-number>
                  </el-form-item>

                  <el-form-item label="是否可用"
                                prop="enabled">
                      <el-switch v-model="updatePermissionDialog.formModel.enabled">
                      </el-switch>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updatePermissionDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="updatePermissionDialog.saveLoading"
                                 @click="updatePermissionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="updatePermissionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>
      </div>
    </el-card>
</template>

<script>
    import {
        getLookupPermissions,
        getLookupPermissionTypes
    } from '@/api/services/lookupService'

    import {
        permissionSearch,
        permissionSingle,
        permissionCreate,
        permissionUpdate,
        permissionDelete
    } from '@/api/services/permissionService'

    export default {
        name: 'Permission',

        computed: {
            structureLevel4Permissions() {
                let structureLevel = (structure, source, value = null, level = 0) => {
                    level++
                    let items = source.filter(x => x.parentId === value)
                    for (let i in items) {
                        let item = items[i]
                        item.level = level
                        structure.push(item)
                        structureLevel(structure, source, item.id, level)
                    }
                }
                let structure = []
                structureLevel(structure, JSON.parse(JSON.stringify(this.permissionTable.items)))
                return structure
            },
            structureLevel4LookupPermissions() {
                let structureLevel = (structure, source, value = null, level = 0) => {
                    level++
                    let items = source.filter(x => x.parentId === value)
                    for (let i in items) {
                        let item = items[i]
                        item.level = level
                        structure.push(item)
                        structureLevel(structure, source, item.id, level)
                    }
                }
                let structure = []
                structureLevel(structure, JSON.parse(JSON.stringify(this.lookupPermissions)))
                return structure
            },
        },

        data() {
            return {
                lookupPermissionTypes: [],
                lookupPermissions: [],

                permissionTable: {
                    items: []
                },

                createPermissionDialog: {
                    errorMessage: '',
                    formModel: {
                        type: null,
                        parentId: null,
                        number: '',
                        icon: '',
                        display: '',
                        sort: 111,
                        enabled: true,
                        remark: ''
                    },
                    formRules: {
                        type: [
                            { required: true, message: '类型', trigger: 'change' }
                        ],
                        number: [
                            { required: true, message: '编号', trigger: 'change' }
                        ],
                        icon: [
                            { required: true, message: '图标', trigger: 'change' }
                        ],
                        display: [
                            { required: true, message: '标题', trigger: 'change' }
                        ],
                        sort: [
                            { required: true, message: '排序', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },

                updatePermissionDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        type: [
                            { required: true, message: '类型', trigger: 'change' }
                        ],
                        number: [
                            { required: true, message: '编号', trigger: 'change' }
                        ],
                        icon: [
                            { required: true, message: '图标', trigger: 'change' }
                        ],
                        display: [
                            { required: true, message: '标题', trigger: 'change' }
                        ],
                        sort: [
                            { required: true, message: '排序', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                }
            }
        },

        methods: {
            searchPermission() {
                let table = this.permissionTable

                permissionSearch().then(resp => {
                    table.items = resp.data
                }).catch(_ => {
                    //
                })
            },
            createPermission() {
                let dialog = this.createPermissionDialog

                getLookupPermissions().then(resp => {
                    this.lookupPermissions = resp.data
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            createPermissionSave() {
                let dialog = this.createPermissionDialog

                this.$refs['createPermissionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    permissionCreate(dialog.formModel).then(_ => {
                        this.searchPermission()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                        this.$refs['createPermissionRef'].resetFields()
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            updatePermission({ id }) {
                let dialog = this.updatePermissionDialog

                Promise.all(
                    [
                        getLookupPermissions(),
                        permissionSingle(id)
                    ]
                ).then(resp => {
                    this.lookupPermissions = resp[0].data
                    dialog.formModel = resp[1].data
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updatePermissionSave() {
                let dialog = this.updatePermissionDialog

                this.$refs['updatePermissionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    permissionUpdate(dialog.formModel.id, dialog.formModel).then(_ => {
                        this.searchPermission()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            deletePermission({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    permissionDelete(id).then(_ => {
                        this.searchPermission()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            getLookupPermissionTypes().then(resp => {
                this.lookupPermissionTypes = resp.data
            }).catch(_ => {
                //
            })
            this.searchPermission()
        }
    }
</script>

<style lang="scss" scoped>
    .permission {
    }
</style>
