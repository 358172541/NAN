<template>
    <div class="dashboard">
        Dashboard
    </div>
</template>

<script>
    export default {
        name: 'Dashboard',
        data() {
            return {

            }
        }
    }
</script>

<style lang="scss" scoped>
    .dashboard {
    }
</style>
