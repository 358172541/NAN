<template>
    <div class="deliveringInspection">
        <el-row class="wrap"
                justify="center"
                type="flex">
            <el-col :span="24">

                <el-table class="margin-bottom-8"
                          v-if="visible"
                          :data="table.pagedResult.items"
                          :row-key="'id'">

                    <el-table-column align="center"
                                     label="#"
                                     prop="number">
                    </el-table-column>

                    <el-table-column align="center"
                                     label="#">
                        <template slot-scope="scope">
                            <el-link type="primary"
                                     @click="inspect(scope.row)">检测</el-link>
                        </template>
                    </el-table-column>

                </el-table>

                <el-pagination background
                               layout="prev, pager, next, sizes, total"
                               v-if="visible"
                               :current-page="table.pagedParams.page"
                               :page-size="table.pagedParams.pageSize"
                               :page-sizes="[10]"
                               :pager-count="5"
                               :total="table.pagedResult.totalCount"
                               @current-change="searchPageChange"
                               @size-change="searchPageSizeChange">
                </el-pagination>

                <el-form ref="formRef"
                         v-if="!visible"
                         :model="formModel"
                         :rules="formRules">

                    <el-form-item>
                        <div>{{shift.number}}</div>
                    </el-form-item>

                    <el-form-item>
                        <el-row justify="space-between"
                                type="flex">
                            <div>出货检测</div>
                            <el-link type="primary" @click="back">返回列表</el-link>
                        </el-row>
                    </el-form-item>

                    <el-form-item prop="inputs">

                        <el-input type="textarea"
                                  v-model="formModel.inputs"
                                  :rows="8">
                        </el-input>

                    </el-form-item>

                    <el-form-item>
                        <el-button size="medium"
                                   type="primary"
                                   :loading="loading"
                                   @click="submit">提交</el-button>
                        <el-button size="medium"
                                   type="info"
                                   @click="reset">重置</el-button>
                        <div class="el-form-item__error">
                            {{errorMessage}}
                        </div>
                    </el-form-item>

                </el-form>

            </el-col>
        </el-row>
    </div>
</template>

<script>
    import {
        deliveringInspectionSearch
    } from '@/api/services/deliveringInspectionService'

    export default {
        name: 'DeliveringInspection',

        computed: {
            visible() {
                return this.shift.id == null
            }
        },

        data() {
            return {
                shift: {
                    id: null,
                    number: ''
                },
                table: {
                    searchParams: {},
                    pagedParams: {
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },
                loading: false,
                errorMessage: '',
                formModel: {
                    inputs: ''
                },
                formRules: {
                    inputs: [
                        { required: true, message: '请输入运单号', trigger: 'change' }
                    ]
                }
            }
        },
        methods: {
            search() {
                this.table.pagedParams.page = 1
                deliveringInspectionSearch(this.table.pagedParams).then(resp => {
                    this.table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchPageChange(page) {
                this.table.pagedParams.page = page
                deliveringInspectionSearch(this.table.pagedParams).then(resp => {
                    this.table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchPageSizeChange(pageSize) {
                this.table.pagedParams.page = 1
                this.table.pagedParams.pageSize = pageSize
                deliveringInspectionSearch(this.table.pagedParams).then(resp => {
                    this.table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            inspect({ id, number }) {
                this.shift.id = id
                this.shift.number = number
            },
            back() {
                this.shift.id = null
                this.shift.number = ''
            },
            submit() {
                this.$refs['formRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    // this.loading = true
                    console.log(this.shift.id)
                    console.log(this.shift.number)
                    window.alert(this.formModel.inputs.trimEnd('\n').split('\n'))
                })
            },
            reset() {
                this.$refs['formRef'].resetFields()
            }
        },

        created() {
            this.search()
        }
    }
</script>

<style lang="scss" scoped>
    .deliveringInspection {
        height: 100vh;
        margin: auto;
        max-width: 335px;
        padding: 0px 20px;

        .wrap {
            position: relative;
            top: 50%;
            transform: translateY(-50%);
        }
    }
</style>
