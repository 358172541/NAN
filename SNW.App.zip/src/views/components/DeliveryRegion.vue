<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>基础信息</el-breadcrumb-item>
              <el-breadcrumb-item>派送地区</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="deliveryRegion">

          <el-row :gutter="8">
              <el-col :span="3">
                  <el-input placeholder="编号"
                            v-model="deliveryRegionTable.searchParams.number">
                  </el-input>
              </el-col>
              <el-col :span="3">
                  <el-select class="width-100-percent"
                             clearable
                             placeholder="所属地区"
                             v-model="deliveryRegionTable.searchParams.regionId">
                      <el-option v-for="item in lookupRegions"
                                 :key="item.id"
                                 :label="item.number"
                                 :value="item.id">
                      </el-option>
                  </el-select>
              </el-col>
              <el-col :span="14">
                  <el-button icon="el-icon-search"
                             type="primary"
                             @click="searchDeliveryRegion">查询</el-button>
                  <el-button icon="el-icon-circle-plus-outline"
                             type="success"
                             @click="createDeliveryRegion">新增</el-button>
              </el-col>
          </el-row>

          <el-table border
                    class="margin-top"
                    :data="deliveryRegionTable.pagedResult.items"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" label="编号" prop="number"></el-table-column>

              <el-table-column align="left" label="所属地区" prop="regionNumber"></el-table-column>

              <el-table-column align="left" label="备注" prop="remark"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit-outline"
                                 size="mini"
                                 type="warning"
                                 @click="updateDeliveryRegion(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                 size="mini"
                                 type="danger"
                                 @click="deleteDeliveryRegion(scope.row)">删除</el-button>
                      <el-button icon="el-icon-edit-outline"
                                 size="mini"
                                 type="primary"
                                 @click="deliveryRegion2(scope.row)">管理子地区</el-button>
                  </template>
              </el-table-column>
          </el-table>

          <el-pagination background
                         class="margin-top"
                         layout="prev, pager, next, total"
                         :current-page="deliveryRegionTable.pagedParams.page"
                         :page-size="deliveryRegionTable.pagedParams.pageSize"
                         :pager-count="5"
                         :total="deliveryRegionTable.pagedResult.totalCount"
                         @current-change="searchDeliveryRegionPageChange"
                         @size-change="searchDeliveryRegionPageSizeChange">
          </el-pagination>

          <!---->

          <el-dialog title="新增"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="createDeliveryRegionDialog.visible">

              <el-form :model="createDeliveryRegionDialog.formModel"
                       :rules="createDeliveryRegionDialog.formRules"
                       ref="createDeliveryRegionRef"
                       label-width="76px">

                  <el-form-item label="编号" prop="number">
                      <el-input v-model="createDeliveryRegionDialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="所属地区" prop="regionId">
                      <el-select clearable
                                 v-model="createDeliveryRegionDialog.formModel.regionId">
                          <el-option v-for="item in lookupRegions"
                                     :key="item.id"
                                     :label="item.number"
                                     :value="item.id">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="备注" prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createDeliveryRegionDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="createDeliveryRegionDialog.saveLoading"
                                 @click="createDeliveryRegionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="createDeliveryRegionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="updateDeliveryRegionDialog.visible">

              <el-form label-width="76px"
                       ref="updateDeliveryRegionRef"
                       :model="updateDeliveryRegionDialog.formModel"
                       :rules="updateDeliveryRegionDialog.formRules">

                  <el-form-item label="编号"
                                prop="account">
                      <el-input v-model="updateDeliveryRegionDialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="所属地区"
                                prop="regionId">
                      <el-select clearable
                                 v-model="updateDeliveryRegionDialog.formModel.regionId">
                          <el-option v-for="item in lookupRegions"
                                     :key="item.id"
                                     :label="item.number"
                                     :value="item.id">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateDeliveryRegionDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="updateDeliveryRegionDialog.saveLoading"
                                 @click="updateDeliveryRegionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="updateDeliveryRegionDialog.visible=false">取消</el-button>
                  </el-form-item>
              </el-form>

          </el-dialog>

          <!---->

          <el-dialog title="管理子地区"
                     width="768px"
                     :close-on-click-modal="false"
                     :visible.sync="deliveryRegion2Dialog.visible">

              <el-row :gutter="8">
                  <el-col :span="6">
                      <el-input placeholder="编号"
                                v-model="deliveryRegion2Dialog.deliveryRegion2Table.searchParams.number">
                      </el-input>
                  </el-col>
                  <el-col :span="18">
                      <el-button icon="el-icon-search"
                                 type="primary"
                                 @click="searchDeliveryRegion2">查询</el-button>
                      <el-button icon="el-icon-circle-plus-outline"
                                 type="success"
                                 @click="createDeliveryRegion2">新增</el-button>
                  </el-col>
              </el-row>

              <el-table border
                        class="margin-top"
                        :data="deliveryRegion2Dialog.deliveryRegion2Table.pagedResult.items"
                        :row-key="'id'">
                  <el-table-column align="center" type="index" width="40">
                      <template slot="header">
                          <i class="el-icon-s-operation" />
                      </template>
                  </el-table-column>

                  <el-table-column align="left" label="编号" prop="number"></el-table-column>

                  <el-table-column align="left" label="备注" prop="remark"></el-table-column>

                  <el-table-column align="center" label="操作项">
                      <template slot-scope="scope">
                          <el-button icon="el-icon-edit-outline"
                                     size="mini"
                                     type="warning"
                                     @click="updateDeliveryRegion2(scope.row)">编辑</el-button>
                          <el-button icon="el-icon-delete"
                                     size="mini"
                                     type="danger"
                                     @click="deleteDeliveryRegion2(scope.row)">删除</el-button>
                      </template>
                  </el-table-column>
              </el-table>

              <el-pagination background
                             class="margin-top"
                             layout="prev, pager, next, total"
                             :current-page="deliveryRegion2Dialog.deliveryRegion2Table.pagedParams.page"
                             :page-size="deliveryRegion2Dialog.deliveryRegion2Table.pagedParams.pageSize"
                             :pager-count="5"
                             :total="deliveryRegion2Dialog.deliveryRegion2Table.pagedResult.totalCount"
                             @current-change="searchDeliveryRegion2PageChange"
                             @size-change="searchDeliveryRegion2PageSizeChange">
              </el-pagination>

          </el-dialog>

          <el-dialog append-to-body
                     title="新增"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="deliveryRegion2Dialog.createDeliveryRegion2Dialog.visible">

              <el-form label-width="50px"
                       ref="createDeliveryRegion2Ref"
                       :model="deliveryRegion2Dialog.createDeliveryRegion2Dialog.formModel"
                       :rules="deliveryRegion2Dialog.createDeliveryRegion2Dialog.formRules">

                  <el-form-item label="编号"
                                prop="number">
                      <el-input v-model="deliveryRegion2Dialog.createDeliveryRegion2Dialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="deliveryRegion2Dialog.createDeliveryRegion2Dialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="deliveryRegion2Dialog.createDeliveryRegion2Dialog.saveLoading"
                                 @click="createDeliveryRegion2Save">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="deliveryRegion2Dialog.createDeliveryRegion2Dialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog append-to-body
                     title="编辑"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="deliveryRegion2Dialog.updateDeliveryRegion2Dialog.visible">

              <el-form label-width="50px"
                       ref="updateDeliveryRegion2Ref"
                       :model="deliveryRegion2Dialog.updateDeliveryRegion2Dialog.formModel"
                       :rules="deliveryRegion2Dialog.updateDeliveryRegion2Dialog.formRules">

                  <el-form-item label="编号"
                                prop="account">
                      <el-input v-model="deliveryRegion2Dialog.updateDeliveryRegion2Dialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="deliveryRegion2Dialog.updateDeliveryRegion2Dialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="deliveryRegion2Dialog.updateDeliveryRegion2Dialog.saveLoading"
                                 @click="updateDeliveryRegion2Save">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="deliveryRegion2Dialog.updateDeliveryRegion2Dialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        getLookupRegions
    } from '@/api/services/lookupService'

    import {
        deliveryRegionSearch,
        deliveryRegionSearch2,
        deliveryRegionSingle,
        deliveryRegionCreate,
        deliveryRegionUpdate,
        deliveryRegionDelete
    } from '@/api/services/deliveryRegionService'

    export default {
        name: 'DeliveryRegion',

        data() {
            return {
                lookupRegions: [],

                deliveryRegionTable: {
                    searchParams: {
                        number: '',
                        regionId: null
                    },
                    pagedParams: {
                        number: '',
                        regionId: null,
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },
                createDeliveryRegionDialog: {
                    errorMessage: '',
                    formModel: {
                        number: '',
                        parentId: null,
                        regionId: null,
                        remark: ''
                    },
                    formRules: {
                        number: [
                            { required: true, message: '编号', trigger: 'change' }
                        ],
                        regionId: [
                            { required: true, message: '所属地区', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateDeliveryRegionDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        number: [
                            { required: true, message: '编号', trigger: 'change' }
                        ],
                        regionId: [
                            { required: true, message: '所属地区', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },

                deliveryRegion2Dialog: {
                    id: null,
                    regionId: null,
                    visible: false,
                    deliveryRegion2Table: {
                        searchParams: {
                            number: ''
                        },
                        pagedParams: {
                            number: '',
                            page: 1,
                            pageSize: 10
                        },
                        pagedResult: {
                            items: [],
                            totalCount: 0
                        }
                    },
                    createDeliveryRegion2Dialog: {
                        errorMessage: '',
                        formModel: {
                            number: '',
                            parentId: null,
                            regionId: null,
                            remark: ''
                        },
                        formRules: {
                            number: [
                                { required: true, message: '编号', trigger: 'change' }
                            ]
                        },
                        saveLoading: false,
                        visible: false
                    },
                    updateDeliveryRegion2Dialog: {
                        errorMessage: '',
                        formModel: {},
                        formRules: {
                            number: [
                                { required: true, message: '编号', trigger: 'change' }
                            ]
                        },
                        saveLoading: false,
                        visible: false
                    }
                }
            }
        },

        methods: {
            searchDeliveryRegion() {
                let table = this.deliveryRegionTable

                table.pagedParams.number = table.searchParams.number
                table.pagedParams.regionId = table.searchParams.regionId

                table.pagedParams.page = 1

                deliveryRegionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchDeliveryRegionPageChange(page) {
                let table = this.deliveryRegionTable

                table.pagedParams.page = page

                deliveryRegionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchDeliveryRegionPageSizeChange(pageSize) {
                let table = this.deliveryRegionTable

                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize

                deliveryRegionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createDeliveryRegion() {
                let dialog = this.createDeliveryRegionDialog

                dialog.visible = true
            },
            createDeliveryRegionSave() {
                let dialog = this.createDeliveryRegionDialog

                this.$refs['createDeliveryRegionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    deliveryRegionCreate(dialog.formModel).then(_ => {
                        this.searchDeliveryRegion()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                        this.$refs['createDeliveryRegionRef'].resetFields()
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            updateDeliveryRegion({ id }) {
                let dialog = this.updateDeliveryRegionDialog

                deliveryRegionSingle(id).then(resp => {
                    dialog.formModel = resp.data
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateDeliveryRegionSave() {
                let dialog = this.updateDeliveryRegionDialog

                this.$refs['updateDeliveryRegionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    deliveryRegionUpdate(dialog.formModel.id, dialog.formModel).then(_ => {
                            this.searchDeliveryRegion()
                        }).then(_ => {
                            dialog.visible = false
                            dialog.saveLoading = false
                        }).catch(_ => {
                            dialog.saveLoading = false
                            //
                        })
                })
            },
            deleteDeliveryRegion({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    deliveryRegionDelete(id).then(_ => {
                        this.searchDeliveryRegion()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            },

            deliveryRegion2({ id, regionId }) {
                let dialog = this.deliveryRegion2Dialog

                dialog.id = id
                dialog.regionId = regionId

                this.searchDeliveryRegion2(true)
            },
            searchDeliveryRegion2(showDialog = false) {
                let dialog = this.deliveryRegion2Dialog
                let table = dialog.deliveryRegion2Table

                table.pagedParams.number = table.searchParams.number

                table.pagedParams.page = 1

                deliveryRegionSearch2(dialog.id, table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                    if (showDialog === true) {
                        dialog.visible = true
                    }
                }).catch(_ => {
                    //
                })
            },
            searchDeliveryRegion2PageChange(page) {
                let dialog = this.deliveryRegion2Dialog
                let table = dialog.deliveryRegion2Table

                table.pagedParams.page = page

                deliveryRegionSearch2(dialog.id, table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchDeliveryRegion2PageSizeChange(pageSize) {
                let dialog = this.deliveryRegion2Dialog
                let table = dialog.deliveryRegion2Table

                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize

                deliveryRegionSearch2(dialog.id, table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createDeliveryRegion2() {
                let dialog = this.deliveryRegion2Dialog
                let dialog2 = dialog.createDeliveryRegion2Dialog

                dialog2.visible = true
            },
            createDeliveryRegion2Save() {
                let dialog = this.deliveryRegion2Dialog
                let dialog2 = dialog.createDeliveryRegion2Dialog

                this.$refs['createDeliveryRegion2Ref'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }

                    dialog2.saveLoading = true
                    dialog2.formModel.parentId = dialog.id
                    dialog2.formModel.regionId = dialog.regionId

                    deliveryRegionCreate(dialog2.formModel).then(_ => {
                        this.searchDeliveryRegion2()
                    }).then(_ => {
                        dialog2.visible = false
                        dialog2.saveLoading = false
                        this.$refs['createDeliveryRegion2Ref'].resetFields()
                    }).catch(_ => {
                        dialog2.saveLoading = false
                        //
                    })
                })
            },
            updateDeliveryRegion2({ id }) {
                let dialog = this.deliveryRegion2Dialog
                let dialog2 = dialog.updateDeliveryRegion2Dialog

                deliveryRegionSingle(id).then(resp => {
                    dialog2.formModel = resp.data
                }).then(_ => {
                    dialog2.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateDeliveryRegion2Save() {
                let dialog = this.deliveryRegion2Dialog
                let dialog2 = dialog.updateDeliveryRegion2Dialog

                this.$refs['updateDeliveryRegion2Ref'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog2.saveLoading = true
                    deliveryRegionUpdate(dialog2.formModel.id, dialog2.formModel).then(_ => {
                        this.searchDeliveryRegion2()
                    }).then(_ => {
                        dialog2.visible = false
                        dialog2.saveLoading = false
                    }).catch(_ => {
                        dialog2.saveLoading = false
                        //
                    })
                })
            },
            deleteDeliveryRegion2({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    deliveryRegionDelete(id).then(_ => {
                        this.searchDeliveryRegion2()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            getLookupRegions().then(resp => {
                this.lookupRegions = resp.data
            }).catch(_ => {
                //
            })
            this.searchDeliveryRegion()
        }
    }
</script>

<style lang="scss" scoped>
    .deliveryRegion {
    }
</style>
