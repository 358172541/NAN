<template>
  <el-card>
    <div slot="header" class="clearfix">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>货物管理</a></el-breadcrumb-item>
        <el-breadcrumb-item>历史包裹</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="packageHistory">

        <el-row :gutter="8">

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="类型"
                           v-model="packageHistoryTable.searchParams.itemType">
                    <el-option v-for="item in lookupItemTypes"
                               :key="item.key"
                               :label="item.value"
                               :value="item.key">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="会员"
                           v-model="packageHistoryTable.searchParams.memberId">
                    <el-option v-for="item in lookupMembers"
                               :key="item.id"
                               :label="item.account"
                               :value="item.id">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="结算状态"
                           v-model="packageHistoryTable.searchParams.balanceStatus">
                    <el-option v-for="item in lookupBalanceStatuses"
                               :key="item.key"
                               :label="item.value"
                               :value="item.key">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="2">
                <el-select placeholder="地区" v-model="packageHistoryTable.searchParams.regionId"
                           clearable
                           class="width-100-percent">
                    <el-option v-for="item in lookupRegions"
                               :key="item.id"
                               :label="item.number"
                               :value="item.id">
                    </el-option>
                </el-select>
            </el-col>

            <el-col :span="3">
                <el-date-picker placement="bottom-start"
                                placeholder="开始时间"
                                type="date"
                                v-model="packageHistoryTable.searchParams.createTimeFrom">
                </el-date-picker>
            </el-col>

            <el-col :span="3">
                <el-date-picker placement="bottom-start"
                                placeholder="结束时间"
                                type="date"
                                v-model="packageHistoryTable.searchParams.createTimeTo">
                </el-date-picker>
            </el-col>

            <el-col :span="2">
                <el-input placeholder="流水号"
                          v-model="packageHistoryTable.searchParams.expressNumber">
                </el-input>
            </el-col>

            <el-col :span="2">
                <el-input placeholder="柜号"
                          v-model="packageHistoryTable.searchParams.containerNumber">
                </el-input>
            </el-col>

            <el-col :span="2">
                <el-input placeholder="唛头"
                          v-model="packageHistoryTable.searchParams.mark">
                </el-input>
            </el-col>

            <el-col :span="4">
                <el-button icon="el-icon-search"
                           type="primary"
                           @click="searchPackageHistory">查询</el-button>
                <el-button icon="el-icon-circle-plus-outline"
                           type="info"
                           @click="exportPackageHistory">导出</el-button>
                <el-button icon="el-icon-edit-outline"
                           type="info"
                           @click="exportPackageHistoryM">导出小包</el-button>
            </el-col>
        </el-row>

        <el-table border
                  class="margin-top"
                  :data="packageHistoryTable.pagedResult.items"
                  :row-key="'id'"
                  :row-style="packageHistoryTableRowStyle">

            <el-table-column align="center" type="index" width="40">
                <template slot="header" slot-scope="scope">
                    <i class="el-icon-s-operation" />
                </template>
            </el-table-column>

            <el-table-column align="left" label="类型" prop="itemTypeDisplay"></el-table-column>

            <el-table-column align="left" label="流水号" prop="expressNumber" width="180"></el-table-column>

            <el-table-column align="left" label="唛头" prop="mark"></el-table-column>

            <el-table-column align="left" label="柜号" prop="containerNumberDisplay"></el-table-column>

            <el-table-column align="center" label="地址">
                <template slot-scope="scope">
                    <el-popover placement="bottom" trigger="click" width="300">
                        <el-descriptions border :column="1" :labelStyle="{ width: '70px' }">
                            <el-descriptions-item label="收件人">{{scope.row.name}}</el-descriptions-item>
                            <el-descriptions-item label="公司名称">{{scope.row.companyName}}</el-descriptions-item>
                            <el-descriptions-item label="电话号码">{{scope.row.phoneNumber}}</el-descriptions-item>
                            <el-descriptions-item label="手机号码">{{scope.row.mobilePhoneNumber}}</el-descriptions-item>
                            <el-descriptions-item label="邮编">{{scope.row.postalCode}}</el-descriptions-item>
                            <el-descriptions-item label="详细地址">{{scope.row.detailAddress}}</el-descriptions-item>
                        </el-descriptions>
                        <el-link type="primary" slot="reference" :underline="false">查看</el-link>
                    </el-popover>
                </template>
            </el-table-column>

            <el-table-column align="left" label="会员编号" prop="memberAccountDisplay"></el-table-column>

            <el-table-column align="left" label="件数" prop="itemCount"></el-table-column>

            <el-table-column align="left" label="重量" prop="weight"></el-table-column>

            <el-table-column align="left" label="地区" prop="regionNumberDisplay"></el-table-column>

            <el-table-column align="left" label="S/体积" prop="volume"></el-table-column>

            <el-table-column align="left" label="品名" prop="itemName"></el-table-column>

            <el-table-column align="left" label="结算状态" prop="balanceStatusDisplay"></el-table-column>

            <el-table-column align="left" label="状态" prop="statusDisplay" width="180"/>

            <el-table-column align="left" label="录入时间" prop="createTime" width="180"/>
        </el-table>

        <el-pagination background
                       class="margin-top"
                       layout="prev, pager, next, total"
                       :current-page="packageHistoryTable.pagedParams.page"
                       :page-size="packageHistoryTable.pagedParams.pageSize"
                       :pager-count="5"
                       :total="packageHistoryTable.pagedResult.totalCount"
                       @current-change="searchPackageHistoryPageChange"
                       @size-change="searchPackageHistoryPageSizeChange">
        </el-pagination>

    </div>
  </el-card>
</template>

<script>
    import {
        getLookupItemTypes,
        getLookupMembers,
        getLookupBalanceStatuses,
        getLookupRegions,
    } from '@/api/services/lookupService';

    import {
        packageHistorySearch,
        packageHistoryExport,
        packageHistoryExportM
    } from '@/api/services/packageHistoryService'

    export default {
        name: 'PackageHistory',
        data() {
            return {

                lookupItemTypes: [],
                lookupMembers: [],
                lookupBalanceStatuses: [],
                lookupRegions: [],

                packageHistoryTable: {
                    searchParams: {
                        itemType: null,
                        memberId: null,
                        balanceStatus: null,
                        regionId: null,
                        createTimeFrom: '',
                        createTimeTo: '',
                        expressNumber: '',
                        containerNumber: '',
                        mark: ''
                    },
                    pagedParams: {
                        itemType: null,
                        memberId: null,
                        balanceStatus: null,
                        regionId: null,
                        createTimeFrom: '',
                        createTimeTo: '',
                        expressNumber: '',
                        containerNumber: '',
                        mark: '',
                        page: 1,
                        pageSize: 15
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                }
            }
        },

        methods: {
            searchPackageHistory() {
                this.packageHistoryTable.pagedParams.itemType = this.packageHistoryTable.searchParams.itemType
                this.packageHistoryTable.pagedParams.memberId = this.packageHistoryTable.searchParams.memberId
                this.packageHistoryTable.pagedParams.balanceStatus = this.packageHistoryTable.searchParams.balanceStatus
                this.packageHistoryTable.pagedParams.regionId = this.packageHistoryTable.searchParams.regionId
                this.packageHistoryTable.pagedParams.createTimeFrom = this.packageHistoryTable.searchParams.createTimeFrom
                this.packageHistoryTable.pagedParams.createTimeTo = this.packageHistoryTable.searchParams.createTimeTo
                this.packageHistoryTable.pagedParams.expressNumber = this.packageHistoryTable.searchParams.expressNumber
                this.packageHistoryTable.pagedParams.containerNumber = this.packageHistoryTable.searchParams.containerNumber
                this.packageHistoryTable.pagedParams.mark = this.packageHistoryTable.searchParams.mark
                this.packageHistoryTable.pagedParams.page = 1
                packageHistorySearch(this.packageHistoryTable.pagedParams).then(resp => {
                    this.packageHistoryTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchPackageHistoryPageChange(page) {
                this.packageHistoryTable.pagedParams.page = page
                packageHistorySearch(this.packageHistoryTable.pagedParams).then(resp => {
                    this.packageHistoryTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchPackageHistoryPageSizeChange(pageSize) {
                this.packageHistoryTable.pagedParams.page = 1
                this.packageHistoryTable.pagedParams.pageSize = pageSize
                packageHistorySearch(this.packageHistoryTable.pagedParams).then(resp => {
                    this.packageHistoryTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },

            exportShiftPackages({ id }) {
                shiftPackagesExport(id).then(resp => {
                    let blob = new Blob([resp.data], {
                        type: resp.data.type
                    })
                    let filename = resp.headers['x-filename']
                    saveAs(blob, filename)
                }).catch(_ => {
                    //
                })
            },
            exportPackageHistory() {
                packageHistoryExport(this.packageHistoryTable.pagedParams).then(resp => {
                    let blob = new Blob([resp.data], {
                        type: resp.data.type
                    })
                    let filename = resp.headers['x-filename']
                    saveAs(blob, filename)
                }).catch(_ => {
                    //
                })
            },
            exportPackageHistoryM() {
                packageHistoryExportM(this.packageHistoryTable.pagedParams).then(resp => {
                    let blob = new Blob([resp.data], {
                        type: resp.data.type
                    })
                    let filename = resp.headers['x-filename']
                    saveAs(blob, filename)
                }).catch(_ => {
                    //
                })
            },

            packageHistoryTableRowStyle({ row }) {
                return {
                    'background': row.BackgroundDisplay
                }
            }
        },

        created() {
            getLookupItemTypes().then(resp => {
                this.lookupItemTypes = resp.data
            }).catch(_ => {
                //
            })
            getLookupMembers().then(resp => {
                this.lookupMembers = resp.data
            }).catch(_ => {
                //
            })
            getLookupBalanceStatuses().then(resp => {
                this.lookupBalanceStatuses = resp.data
            }).catch(_ => {
                //
            })
            getLookupRegions().then(resp => {
                this.lookupRegions = resp.data
            }).catch(_ => {
                //
            })
            this.searchPackageHistory();
        }
    }
</script>

<style lang="scss" scoped>
    .packageHistory {
    }
</style>
