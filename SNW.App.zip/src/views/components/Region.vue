<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>基础信息</el-breadcrumb-item>
              <el-breadcrumb-item>地区</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="region">

          <el-row :gutter="8">
              <el-col :span="3">
                  <el-input placeholder="编号"
                            v-model="regionTable.searchParams.number">
                  </el-input>
              </el-col>
              <el-col :span="3">
                  <el-input placeholder="运单号/前缀"
                            v-model="regionTable.searchParams.prefix">
                  </el-input>
              </el-col>
              <el-col :span="3">
                  <el-input placeholder="筛选"
                            v-model="regionTable.searchParams.screen">
                  </el-input>
              </el-col>
              <el-col :span="15">
                  <el-button icon="el-icon-search"
                             type="primary"
                             @click="searchRegion">查询</el-button>
                  <el-button icon="el-icon-circle-plus-outline"
                             type="success"
                             @click="createRegion">新增</el-button>
              </el-col>
          </el-row>

          <el-table border
                    class="margin-top"
                    :data="regionTable.pagedResult.items"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" label="编号" prop="number"></el-table-column>

              <el-table-column align="left" label="运单号/前缀" prop="prefix"></el-table-column>

              <el-table-column align="left" label="筛选" prop="screen"></el-table-column>

              <el-table-column align="left" label="派送公司/名称" prop="expressCompanyName"></el-table-column>

              <el-table-column align="left" label="派送公司/电话号码" prop="expressCompanyPhoneNumber"></el-table-column>

              <el-table-column align="left" label="备注" prop="remark"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit-outline"
                                 size="mini"
                                 type="warning"
                                 @click="updateRegion(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                 size="mini"
                                 type="danger"
                                 @click="deleteRegion(scope.row)">删除</el-button>
                  </template>
              </el-table-column>
          </el-table>

          <el-pagination background
                         class="margin-top"
                         layout="prev, pager, next, total"
                         :current-page="regionTable.pagedParams.page"
                         :page-size="regionTable.pagedParams.pageSize"
                         :pager-count="5"
                         :total="regionTable.pagedResult.totalCount"
                         @current-change="searchRegionPageChange"
                         @size-change="searchRegionPageSizeChange">
          </el-pagination>

          <!---->

          <el-dialog title="新增"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="createRegionDialog.visible">

              <el-form :model="createRegionDialog.formModel"
                       :rules="createRegionDialog.formRules"
                       ref="createRegionRef"
                       label-width="124px">

                  <el-form-item label="编号"
                                prop="number">
                      <el-input v-model="createRegionDialog.formModel.number"></el-input>
                  </el-form-item>

                  <el-form-item label="运单号/前缀"
                                prop="prefix">
                      <el-input v-model="createRegionDialog.formModel.prefix">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="筛选"
                                prop="screen">
                      <el-input v-model="createRegionDialog.formModel.screen">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="派送公司/名称"
                                prop="expressCompanyName">
                      <el-input v-model="createRegionDialog.formModel.expressCompanyName">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="派送公司/电话号码"
                                prop="expressCompanyPhoneNumber">
                      <el-input v-model="createRegionDialog.formModel.expressCompanyPhoneNumber">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="派送公司/详细地址"
                                prop="expressCompanyDetailAddress">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createRegionDialog.formModel.expressCompanyDetailAddress">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createRegionDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="createRegionDialog.saveLoading"
                                 @click="createRegionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="createRegionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="updateRegionDialog.visible">

              <el-form :model="updateRegionDialog.formModel"
                       :rules="updateRegionDialog.formRules"
                       ref="updateRegionRef"
                       label-width="124px">

                  <el-form-item label="编号"
                                prop="number"
                                required>
                      {{updateRegionDialog.formModel.number}}
                  </el-form-item>

                  <el-form-item label="运单号/前缀"
                                prop="prefix"
                                required>
                      {{updateRegionDialog.formModel.prefix}}
                  </el-form-item>

                  <el-form-item label="筛选"
                                prop="screen">
                      <el-input v-model="updateRegionDialog.formModel.screen">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="派送公司/名称"
                                prop="expressCompanyName">
                      <el-input v-model="updateRegionDialog.formModel.expressCompanyName">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="派送公司/电话号码"
                                prop="expressCompanyPhoneNumber">
                      <el-input v-model="updateRegionDialog.formModel.expressCompanyPhoneNumber">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="派送公司/详细地址"
                                prop="expressCompanyDetailAddress">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateRegionDialog.formModel.expressCompanyDetailAddress">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateRegionDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="updateRegionDialog.saveLoading"
                                 @click="updateRegionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="updateRegionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        regionSearch,
        regionSingle,
        regionCreate,
        regionUpdate,
        regionDelete
    } from '@/api/services/regionService'

    export default {
        name: 'Region',

        data() {
            return {
                regionTable: {
                    searchParams: {
                        number: '',
                        prefix: '',
                        screen: ''
                    },
                    pagedParams: {
                        number: '',
                        prefix: '',
                        screen: '',
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },

                createRegionDialog: {
                    errorMessage: '',
                    formModel: {
                        number: '',
                        prefix: '',
                        screen: '',
                        expressCompanyName: '',
                        expressCompanyPhoneNumber: '',
                        expressCompanyDetailAddress: '',
                        //expressCompanyLogo: '',
                        remark: ''
                    },
                    formRules: {
                        number: [
                            { required: true, message: '编号', trigger: 'change' }
                        ],
                        prefix: [
                            { required: true, message: '运单号/前缀', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateRegionDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {},
                    saveLoading: false,
                    visible: false
                }
            }
        },

        methods: {
            searchRegion() {
                let table = this.regionTable

                table.pagedParams.number = table.searchParams.number
                table.pagedParams.prefix = table.searchParams.prefix
                table.pagedParams.screen = table.searchParams.screen

                table.pagedParams.page = 1

                regionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchRegionPageChange(page) {
                let table = this.regionTable

                table.pagedParams.page = page

                regionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchRegionPageSizeChange(pageSize) {
                let table = this.regionTable

                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize

                regionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createRegion() {
                let dialog = this.createRegionDialog

                dialog.visible = true
            },
            createRegionSave() {
                let dialog = this.createRegionDialog

                this.$refs['createRegionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    regionCreate(dialog.formModel).then(_ => {
                        this.searchRegion()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                        this.$refs['createRegionRef'].resetFields()
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            updateRegion({ id, number, prefix }) {
                let dialog = this.updateRegionDialog

                regionSingle(id).then(resp => {
                    dialog.formModel = resp.data
                    dialog.formModel.number = number
                    dialog.formModel.prefix = prefix
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateRegionSave() {
                this.$refs['updateRegionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }

                    let dialog = this.updateRegionDialog

                    dialog.saveLoading = true

                    regionUpdate(
                        dialog.formModel.id,
                        dialog.formModel).then(_ => {
                            this.searchRegion()
                        }).then(_ => {
                            dialog.visible = false
                            dialog.saveLoading = false
                        }).catch(_ => {
                            dialog.saveLoading = false
                            //
                        })
                })
            },
            deleteRegion({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    regionDelete(id).then(_ => {
                        this.searchRegion()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            this.searchRegion()
        }
    }
</script>

<style lang="scss" scoped>
    .region {
    }
</style>
