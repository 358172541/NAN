<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>基础信息</el-breadcrumb-item>
              <el-breadcrumb-item>会员</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="member">

          <el-row :gutter="8">
              <el-col :span="3">
                  <el-input placeholder="账号"
                            v-model="memberTable.searchParams.account"></el-input>
              </el-col>
              <el-col :span="3">
                  <el-input placeholder="姓名"
                            v-model="memberTable.searchParams.name"></el-input>
              </el-col>
              <el-col :span="3">
                  <el-input placeholder="电子邮箱"
                            v-model="memberTable.searchParams.email"></el-input>
              </el-col>
              <el-col :span="15">
                  <el-button icon="el-icon-search"
                             type="primary"
                             @click="searchMember">查询</el-button>
                  <el-button icon="el-icon-circle-plus-outline"
                             type="success"
                             @click="createMember">新增</el-button>
              </el-col>
          </el-row>

          <el-table border
                    class="margin-top"
                    :data="memberTable.pagedResult.items"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" label="账号" prop="account"></el-table-column>

              <el-table-column align="left" label="姓名" prop="name"></el-table-column>

              <el-table-column align="left" label="电子邮箱" prop="email"></el-table-column>

              <el-table-column align="center" label="是否仓库扣货" prop="enabled">
                  <template slot-scope="scope">
                      <el-switch nocursor
                                 :value="scope.row.warehouseDetained">
                      </el-switch>
                  </template>
              </el-table-column>

              <el-table-column align="center" label="是否客户扣货" prop="enabled">
                  <template slot-scope="scope">
                      <el-switch nocursor
                                 :value="scope.row.customerDetained">
                      </el-switch>
                  </template>
              </el-table-column>

              <el-table-column align="center" label="是否启用" prop="enabled">
                  <template slot-scope="scope">
                      <el-switch nocursor
                                 :value="scope.row.enabled">
                      </el-switch>
                  </template>
              </el-table-column>

              <el-table-column align="left" prop="remark" label="备注"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit"
                                 size="mini"
                                 type="warning"
                                 @click="updateMember(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                 size="mini"
                                 type="danger"
                                 @click="deleteMember(scope.row)">删除</el-button>
                  </template>
              </el-table-column>

          </el-table>

          <el-pagination background
                         class="margin-top"
                         layout="prev, pager, next, total"
                         :current-page="memberTable.pagedParams.page"
                         :page-size="memberTable.pagedParams.pageSize"
                         :pager-count="5"
                         :total="memberTable.pagedResult.totalCount"
                         @current-change="searchMemberPageChange"
                         @size-change="searchMemberPageSizeChange">
          </el-pagination>

          <!---->

          <el-dialog title="新增"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="createMemberDialog.visible">

              <el-form :model="createMemberDialog.formModel"
                       :rules="createMemberDialog.formRules"
                       ref="createMemberRef"
                       label-width="90px">

                  <el-form-item label="账号" prop="account">
                      <el-input v-model="createMemberDialog.formModel.account"></el-input>
                  </el-form-item>

                  <el-form-item label="姓名" prop="name">
                      <el-input v-model="createMemberDialog.formModel.name"></el-input>
                  </el-form-item>

                  <el-form-item label="电子邮箱" prop="email">
                      <el-input v-model="createMemberDialog.formModel.email"></el-input>
                  </el-form-item>

                  <el-form-item label="是否仓库扣货" prop="warehouseDetained">
                      <el-switch v-model="createMemberDialog.formModel.warehouseDetained"></el-switch>
                  </el-form-item>

                  <el-form-item label="是否客户扣货" prop="customerDetained">
                      <el-switch v-model="createMemberDialog.formModel.customerDetained"></el-switch>
                  </el-form-item>

                  <el-form-item label="是否启用" prop="enabled">
                      <el-switch v-model="createMemberDialog.formModel.enabled"></el-switch>
                  </el-form-item>

                  <el-form-item label="备注" prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createMemberDialog.formModel.remark"></el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="createMemberDialog.saveLoading"
                                 @click="createMemberSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="createMemberDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="updateMemberDialog.visible">

              <el-form :model="updateMemberDialog.formModel"
                       :rules="updateMemberDialog.formRules"
                       ref="updateMemberRef"
                       label-width="90px">

                  <el-form-item label="账号" prop="account" required>
                      {{updateMemberDialog.formModel.account}}
                  </el-form-item>

                  <el-form-item label="姓名" prop="name">
                      <el-input v-model="updateMemberDialog.formModel.name"></el-input>
                  </el-form-item>

                  <el-form-item label="电子邮箱" prop="email">
                      <el-input v-model="updateMemberDialog.formModel.email"></el-input>
                  </el-form-item>

                  <el-form-item label="是否仓库扣货" prop="warehouseDetained">
                      <el-switch v-model="updateMemberDialog.formModel.warehouseDetained"></el-switch>
                  </el-form-item>

                  <el-form-item label="是否客户扣货" prop="customerDetained">
                      <el-switch v-model="updateMemberDialog.formModel.customerDetained"></el-switch>
                  </el-form-item>

                  <el-form-item label="是否启用" prop="enabled">
                      <el-switch v-model="updateMemberDialog.formModel.enabled"></el-switch>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateMemberDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="updateMemberDialog.saveLoading"
                                 @click="updateMemberSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="updateMemberDialog.visible=false">取消</el-button>
                  </el-form-item>
              </el-form>

          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        memberSearch,
        memberSingle,
        memberCreate,
        memberUpdate,
        memberDelete
    } from '@/api/services/memberService'

    export default {
        name: 'Member',

        data() {
            return {
                lookupMemberTypes: [],

                memberTable: {
                    searchParams: {
                        account: '',
                        name: '',
                        email: '',
                        memberTypeId: null
                    },
                    pagedParams: {
                        account: '',
                        name: '',
                        email: '',
                        memberTypeId: null,
                        page: 1,
                        pageSize: 15
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },

                createMemberDialog: {
                    errorMessage: '',
                    formModel: {
                        account: '',
                        name: '',
                        email: '',
                        memberTypeId: null,
                        warehouseDetained: false,
                        customerDetained: false,
                        enabled: true,
                        remark: ''
                    },
                    formRules: {
                        account: [
                            { required: true, message: '请填写账号', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateMemberDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {},
                    saveLoading: false,
                    visible: false
                }
            }
        },

        methods: {
            searchMember() {
                this.memberTable.pagedParams.account = this.memberTable.searchParams.account
                this.memberTable.pagedParams.name = this.memberTable.searchParams.name
                this.memberTable.pagedParams.email = this.memberTable.searchParams.email
                //this.memberTable.pagedParams.memberTypeId = this.memberTable.searchParams.memberTypeId
                this.memberTable.pagedParams.page = 1

                memberSearch(this.memberTable.pagedParams).then(resp => {
                    this.memberTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchMemberPageChange(page) {
                this.memberTable.pagedParams.page = page
                memberSearch(this.memberTable.pagedParams).then(resp => {
                    this.memberTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchMemberPageSizeChange(pageSize) {
                this.memberTable.pagedParams.page = 1
                this.memberTable.pagedParams.pageSize = pageSize
                memberSearch(this.memberTable.pagedParams).then(resp => {
                    this.memberTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createMember() {
                this.createMemberDialog.visible = true
            },
            createMemberSave() {
                this.$refs['createMemberRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.createMemberDialog.saveLoading = true
                    memberCreate(this.createMemberDialog.formModel).then(_ => {
                        this.searchMember()
                    }).then(_ => {
                        this.createMemberDialog.visible = false
                        this.createMemberDialog.saveLoading = false
                        this.$refs['createMemberRef'].resetFields()
                    }).catch(_ => {
                        //
                    })
                })
            },
            updateMember({ id, account }) {
                memberSingle(id).then(resp => {
                    this.updateMemberDialog.formModel = resp.data
                    this.updateMemberDialog.formModel.account = account //
                }).then(_ => {
                    this.updateMemberDialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateMemberSave() {
                this.$refs['updateMemberRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.updateMemberDialog.saveLoading = true
                    memberUpdate(this.updateMemberDialog.formModel.id, this.updateMemberDialog.formModel).then(_ => {
                        this.searchMember()
                    }).then(_ => {
                        this.updateMemberDialog.visible = false
                        this.updateMemberDialog.saveLoading = false
                    }).catch(_ => {
                        //
                    })
                })
            },
            deleteMember({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    memberDelete(id).then(_ => {
                        this.searchMember()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            //getLookupMemberTypes().then(resp => {
            //    this.lookupMemberTypes = resp.data
            //}).catch(_ => {
            //    //
            //})
            this.searchMember()
        }
    }
</script>

<style lang="scss" scoped>
    .member {
    }
</style>
