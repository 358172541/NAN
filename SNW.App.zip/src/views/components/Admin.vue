<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>基础信息</el-breadcrumb-item>
              <el-breadcrumb-item>管理员</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="admin">

          <el-row :gutter="8">
              <el-col :span="3">
                  <el-input placeholder="账号"
                            v-model="adminTable.searchParams.account"></el-input>
              </el-col>
              <el-col :span="3">
                  <el-input placeholder="姓名"
                            v-model="adminTable.searchParams.name"></el-input>
              </el-col>
              <el-col :span="3">
                  <el-input placeholder="电子邮箱"
                            v-model="adminTable.searchParams.email"></el-input>
              </el-col>
              <el-col :span="3">
                  <el-select class="width-100-percent"
                             clearable
                             placeholder="管理员类型"
                             v-model="adminTable.searchParams.adminTypeId">
                      <el-option v-for="item in lookupAdminTypes"
                                 :key="item.value"
                                 :label="item.display"
                                 :value="item.value">
                      </el-option>
                  </el-select>
              </el-col>
              <el-col :span="12">
                  <el-button icon="el-icon-search"
                             type="primary"
                             @click="searchAdmin">查询</el-button>
                  <el-button icon="el-icon-circle-plus-outline"
                             type="success"
                             @click="createAdmin">新增</el-button>
              </el-col>
          </el-row>

          <el-table border
                    class="margin-top"
                    :data="adminTable.pagedResult.items"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" label="账号" prop="account"></el-table-column>

              <el-table-column align="left" label="姓名" prop="name"></el-table-column>

              <el-table-column align="left" label="电子邮箱" prop="email"></el-table-column>

              <el-table-column align="left" label="管理员类型" prop="adminTypeDisplay"></el-table-column>

              <el-table-column align="center" label="是否启用" prop="enabled">
                  <template slot-scope="scope">
                      <el-switch nocursor
                                 :value="scope.row.enabled">
                      </el-switch>
                  </template>
              </el-table-column>

              <el-table-column align="left" prop="remark" label="备注"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit-outline"
                                 size="mini"
                                 type="warning"
                                 @click="updateAdmin(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                 size="mini"
                                 type="danger"
                                 @click="deleteAdmin(scope.row)">删除</el-button>
                  </template>
              </el-table-column>
          </el-table>

          <el-pagination background
                         class="margin-top"
                         layout="prev, pager, next, total"
                         :current-page="adminTable.pagedParams.page"
                         :page-size="adminTable.pagedParams.pageSize"
                         :pager-count="5"
                         :total="adminTable.pagedResult.totalCount"
                         @current-change="searchAdminPageChange"
                         @size-change="searchAdminPageSizeChange">
          </el-pagination>

          <!---->

          <el-dialog title="新增"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="createAdminDialog.visible">

              <el-form label-width="89px"
                       ref="createAdminRef"
                       :model="createAdminDialog.formModel"
                       :rules="createAdminDialog.formRules">

                  <el-form-item label="账号" prop="account">
                      <el-input v-model="createAdminDialog.formModel.account"></el-input>
                  </el-form-item>

                  <el-form-item label="姓名" prop="name">
                      <el-input v-model="createAdminDialog.formModel.name"></el-input>
                  </el-form-item>

                  <el-form-item label="电子邮箱" prop="email">
                      <el-input v-model="createAdminDialog.formModel.email"></el-input>
                  </el-form-item>

                  <el-form-item label="管理员类型" prop="adminTypeId">
                      <el-select clearable
                                 v-model="createAdminDialog.formModel.adminTypeId">
                          <el-option v-for="item in lookupAdminTypes"
                                     :key="item.value"
                                     :label="item.display"
                                     :value="item.value">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="是否启用" prop="enabled">
                      <el-switch v-model="createAdminDialog.formModel.enabled"></el-switch>
                  </el-form-item>

                  <el-form-item label="备注" prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createAdminDialog.formModel.remark"></el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="createAdminDialog.saveLoading"
                                 @click="createAdminSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="createAdminDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="updateAdminDialog.visible">

              <el-form label-width="89px"
                       ref="updateAdminRef"
                       :model="updateAdminDialog.formModel"
                       :rules="updateAdminDialog.formRules">

                  <el-form-item label="账号" prop="account" required>
                      {{updateAdminDialog.formModel.account}}
                  </el-form-item>

                  <el-form-item label="姓名" prop="name">
                      <el-input v-model="updateAdminDialog.formModel.name"></el-input>
                  </el-form-item>

                  <el-form-item label="电子邮箱" prop="email">
                      <el-input v-model="updateAdminDialog.formModel.email"></el-input>
                  </el-form-item>

                  <el-form-item label="管理员类型" prop="adminTypeId">
                      <el-select clearable
                                 v-model="updateAdminDialog.formModel.adminTypeId">
                          <el-option v-for="item in lookupAdminTypes"
                                     :key="item.value"
                                     :label="item.display"
                                     :value="item.value">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="是否启用" prop="enabled">
                      <el-switch v-model="updateAdminDialog.formModel.enabled"></el-switch>
                  </el-form-item>

                  <el-form-item label="备注" prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateAdminDialog.formModel.remark"></el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="updateAdminDialog.saveLoading"
                                 @click="updateAdminSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="updateAdminDialog.visible=false">取消</el-button>
                  </el-form-item>
              </el-form>

          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        getLookupAdminTypes
    } from '@/api/services/lookupService'

    import {
        adminSearch,
        adminSingle,
        adminCreate,
        adminUpdate,
        adminDelete
    } from '@/api/services/adminService'

    export default {
        name: 'Admin',

        data() {
            return {
                lookupAdminTypes: [],

                adminTable: {
                    searchParams: {
                        account: '',
                        name: '',
                        email: '',
                        adminTypeId: null
                    },
                    pagedParams: {
                        account: '',
                        name: '',
                        email: '',
                        adminTypeId: null,
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },

                createAdminDialog: {
                    errorMessage: '',
                    formModel: {
                        account: '',
                        name: '',
                        email: '',
                        adminTypeId: null,
                        enabled: true,
                        remark: ''
                    },
                    formRules: {
                        account: [
                            { required: true, message: '账号', trigger: 'change' }
                        ],
                        adminTypeId: [
                            { required: true, message: '管理员类型', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateAdminDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        adminTypeId: [
                            { required: true, message: '管理员类型', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                }
            }
        },

        methods: {
            searchAdmin() {
                let table = this.adminTable

                table.pagedParams.account = table.searchParams.account
                table.pagedParams.name = table.searchParams.name
                table.pagedParams.email = table.searchParams.email
                table.pagedParams.adminTypeId = table.searchParams.adminTypeId

                table.pagedParams.page = 1

                adminSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchAdminPageChange(page) {
                let table = this.adminTable

                table.pagedParams.page = page

                adminSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchAdminPageSizeChange(pageSize) {
                let table = this.adminTable

                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize

                adminSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createAdmin() {
                let dialog = this.createAdminDialog

                dialog.visible = true
            },
            createAdminSave() {
                let dialog = this.createAdminDialog

                this.$refs['createAdminRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    adminCreate(dialog.formModel).then(_ => {
                        this.searchAdmin()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                        this.$refs['createAdminRef'].resetFields()
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            updateAdmin({ id, account }) {
                let dialog = this.updateAdminDialog

                adminSingle(id).then(resp => {
                    dialog.formModel = resp.data
                    dialog.formModel.account = account //
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateAdminSave() {
                let dialog = this.updateAdminDialog

                this.$refs['updateAdminRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    adminUpdate(dialog.formModel.id, dialog.formModel).then(_ => {
                        this.searchAdmin()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            deleteAdmin({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    adminDelete(id).then(_ => {
                        this.searchAdmin()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            getLookupAdminTypes().then(resp => {
                this.lookupAdminTypes = resp.data
            }).catch(_ => {
                //
            })
            this.searchAdmin()
        }
    }
</script>

<style scoped>
    .admin {
    }
</style>
