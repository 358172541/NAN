<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>网站前台</el-breadcrumb-item>
              <el-breadcrumb-item>内容</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="content">

          <el-row :gutter="8">
              <el-col :span="3">
                  <el-input placeholder="标题"
                              v-model="contentTable.searchParams.title"></el-input>
              </el-col>
              <el-col :span="3">
                  <el-select class="width-100-percent"
                              clearable
                              placeholder="类型"
                              v-model="contentTable.searchParams.contentCategoryId">
                      <el-option v-for="item in structureLevel4LookupContentCategories"
                                  :key="item.id"
                                  :label="item.display"
                                  :value="item.id">
                          <span :style="{ marginLeft: (item.level - 1) * 20 + 'px' }">
                              <span>{{ item.display }}</span>
                          </span>
                      </el-option>
                  </el-select>
              </el-col>
              <el-col :span="18">
                  <el-button icon="el-icon-search"
                              type="primary"
                              @click="searchContent">查询</el-button>
                  <el-button icon="el-icon-circle-plus-outline"
                              type="success"
                              @click="createContent">新增</el-button>
              </el-col>
          </el-row>

          <el-table border
                    class="margin-top"
                    :data="contentTable.pagedResult.items"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" label="标题" prop="title"></el-table-column>

              <el-table-column align="left" label="类型" prop="contentCategoryDisplay"></el-table-column>

              <el-table-column align="center" label="是否启用" prop="enabled">
                  <template slot-scope="scope">
                      <el-switch nocursor
                                  :value="scope.row.enabled">
                      </el-switch>
                  </template>
              </el-table-column>

              <el-table-column align="left" prop="remark" label="备注"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit-outline"
                                  size="mini"
                                  type="warning"
                                  @click="updateContent(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                  size="mini"
                                  type="danger"
                                  @click="deleteContent(scope.row)">删除</el-button>
                  </template>
              </el-table-column>

          </el-table>

          <el-pagination background
                         class="margin-top"
                         layout="prev, pager, next, total"
                         :current-page="contentTable.pagedParams.page"
                         :page-size="contentTable.pagedParams.pageSize"
                         :pager-count="5"
                         :total="contentTable.pagedResult.totalCount"
                         @current-change="searchContentPageChange"
                         @size-change="searchContentPageSizeChange">
          </el-pagination>

          <!---->

          <el-dialog title="新增"
                     width="320px"
                     :close-on-click-modal="false"
                     :visible.sync="createContentDialog.visible">

              <el-form label-width="64px"
                       ref="createContentRef"
                       :model="createContentDialog.formModel"
                       :rules="createContentDialog.formRules">

                  <el-form-item label="类型"
                                prop="contentCategoryId">
                      <el-select v-model="createContentDialog.formModel.contentCategoryId">
                          <el-option v-for="item in lookupContentCategories"
                                     :key="item.id"
                                     :label="item.display"
                                     :value="item.id">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="标题"
                                prop="title">
                      <el-input type="textarea"
                                v-model="createContentDialog.formModel.title">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="内容" prop="mainBody">
                      <el-button icon="el-icon-edit-outline"
                                 type="warning"
                                 @click="createContentMainBodyDialog.visible=true">编辑内容</el-button>
                  </el-form-item>

                  <el-form-item label="是否启用"
                                prop="enabled">
                      <el-switch active-color="#67c23a"
                                 v-model="createContentDialog.formModel.enabled">
                      </el-switch>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createContentDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-edit"
                                 type="primary"
                                 :loading="createContentDialog.saveLoading"
                                 @click="createContentSave">保存</el-button>
                      <el-button icon="el-icon-edit"
                                 type="danger"
                                 @click="createContentDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog append-to-body
                     title="编辑内容"
                     width="896px"
                     :close-on-click-modal="false"
                     :visible.sync="createContentMainBodyDialog.visible">

              <el-form>
                  <el-form-item>
                      <el-upload class="uploader"
                                 style="display:none"
                                 :action="uploadUrl"
                                 :multiple="false"
                                 :on-success="createContentUploaderOnSuccess"
                                 :show-file-list="false" />

                      <quill-editor ref="createContentQuillEditor"
                                    v-model="createContentDialog.formModel.mainBody"
                                    :options="editorOptions" />
                  </el-form-item>
                  <el-form-item>
                      <el-button icon="el-icon-edit-outline"
                                 type="success"
                                 @click="createContentMainBodyDialog.visible=false">完成</el-button>
                  </el-form-item>
              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="320px"
                     :close-on-click-modal="false"
                     :visible.sync="updateContentDialog.visible">

              <el-form label-width="64px"
                       ref="updateContentRef"
                       :model="updateContentDialog.formModel"
                       :rules="updateContentDialog.formRules">

                  <el-form-item label="类型"
                                prop="contentCategoryId">
                      <el-select v-model="updateContentDialog.formModel.contentCategoryId">
                          <el-option v-for="item in lookupContentCategories"
                                     :key="item.id"
                                     :label="item.display"
                                     :value="item.id">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="标题"
                                prop="title">
                      <el-input type="textarea"
                                v-model="updateContentDialog.formModel.title">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="内容" prop="mainBody">
                      <el-button icon="el-icon-edit-outline"
                                 type="warning"
                                 @click="updateContentMainBodyDialog.visible=true">编辑内容</el-button>
                  </el-form-item>

                  <el-form-item label="是否启用"
                                prop="enabled">
                      <el-switch active-color="#67c23a"
                                 v-model="updateContentDialog.formModel.enabled">
                      </el-switch>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateContentDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-edit"
                                 type="primary"
                                 :loading="updateContentDialog.saveLoading"
                                 @click="updateContentSave">保存</el-button>
                      <el-button icon="el-icon-edit"
                                 type="danger"
                                 @click="updateContentDialog.visible=false">取消</el-button>
                  </el-form-item>
              </el-form>

          </el-dialog>

          <el-dialog append-to-body
                     title="编辑内容"
                     width="896px"
                     :close-on-click-modal="false"
                     :visible.sync="updateContentMainBodyDialog.visible">

              <el-form>
                  <el-form-item>
                      <el-upload class="uploader"
                                 style="display:none"
                                 :action="uploadUrl"
                                 :multiple="false"
                                 :on-success="updateContentUploaderOnSuccess"
                                 :show-file-list="false" />

                      <quill-editor ref="updateContentQuillEditor"
                                    v-model="updateContentDialog.formModel.mainBody"
                                    :options="editorOptions" />
                  </el-form-item>
                  <el-form-item>
                      <el-button icon="el-icon-edit"
                                 type="success"
                                 @click="updateContentMainBodyDialog.visible=false">完成</el-button>
                  </el-form-item>
              </el-form>

          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        getLookupContentCategories
    } from '@/api/services/lookupService'

    import {
        contentSearch,
        contentSingle,
        contentCreate,
        contentUpdate,
        contentDelete
    } from '@/api/services/contentService'

    export default {
        name: 'Content',

        computed: {
            structureLevel4LookupContentCategories() {
                let structureLevel = (structure, source, value = null, level = 0) => {
                    level++
                    let items = source.filter(x => x.parentId === value)
                    for (let i in items) {
                        let item = items[i]
                        item.level = level
                        structure.push(item)
                        structureLevel(structure, source, item.id, level)
                    }
                }
                let structure = []
                structureLevel(structure, JSON.parse(JSON.stringify(this.lookupContentCategories)))
                return structure
            },
        },

        data() {
            return {

                editorOptions: {
                    modules: {
                        toolbar: {
                            container: [
                                [
                                    {
                                        header: [1, 2, 3, false]
                                    }
                                ],
                                ['bold', 'italic', 'underline'],
                                ['image']
                            ],
                            handlers: {
                                image: function (value) {
                                    if (value) {
                                        document.querySelector('.uploader input').click()
                                    } else {
                                        this.quill.format('image', false)
                                    }
                                }
                            }
                        }
                    }
                },
                uploadUrl: process.env.BASE_URL + '/api/uploads',

                lookupContentCategories: [],

                contentTable: {
                    searchParams: {
                        title: '',
                        contentCategoryId: null
                    },
                    pagedParams: {
                        title: '',
                        contentCategoryId: null,
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },

                createContentDialog: {
                    errorMessage: '',
                    formModel: {
                        title: '',
                        contentCategoryId: null,
                        mainBody: '',
                        enabled: true,
                        remark: ''
                    },
                    formRules: {
                        title: [
                            { required: true, message: '请填写标题', trigger: 'change' }
                        ],
                        contentCategoryId: [
                            { required: true, message: '请选择类型', trigger: 'change' }
                        ],
                        mainBody: [
                            { required: true, message: '请填写内容', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                createContentMainBodyDialog: {
                    visible: false
                },

                updateContentDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        title: [
                            { required: true, message: '请填写标题', trigger: 'change' }
                        ],
                        contentCategoryId: [
                            { required: true, message: '请选择类型', trigger: 'change' }
                        ],
                        mainBody: [
                            { required: true, message: '请填写内容', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateContentMainBodyDialog: {
                    visible: false
                }
            }
        },

        methods: {
            searchContent() {
                this.contentTable.pagedParams.number = this.contentTable.searchParams.number
                this.contentTable.pagedParams.contentCategoryId = this.contentTable.searchParams.contentCategoryId
                this.contentTable.pagedParams.page = 1
                console.log(this.contentTable.pagedParams)
                contentSearch(this.contentTable.pagedParams).then(resp => {
                    this.contentTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchContentPageChange(page) {
                this.contentTable.pagedParams.page = page
                contentSearch(this.contentTable.pagedParams).then(resp => {
                    this.contentTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchContentPageSizeChange(pageSize) {
                this.contentTable.pagedParams.page = 1
                this.contentTable.pagedParams.pageSize = pageSize
                contentSearch(this.contentTable.pagedParams).then(resp => {
                    this.contentTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },

            createContent() {
                getLookupContentCategories().then(resp => {
                    this.lookupContentCategories = resp.data
                }).then(_ => {
                    this.createContentDialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            createContentUploaderOnSuccess(resp) {
                let quill = this.$refs['createContentQuillEditor'].quill
                if (resp) {
                    let length = quill.getSelection().index;
                    quill.insertEmbed(length, 'image', process.env.BASE_URL + resp)
                    quill.setSelection(length + 1)
                } else {
                    //
                }
            },
            createContentSave() {
                this.$refs['createContentRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.createContentDialog.saveLoading = true
                    contentCreate(this.createContentDialog.formModel).then(_ => {
                        this.searchContent()
                    }).then(_ => {
                        this.createContentDialog.visible = false
                        this.createContentDialog.saveLoading = false
                        this.$refs['createContentRef'].resetFields()
                    }).catch(_ => {
                        this.createContentDialog.saveLoading = false
                        //
                    })
                })
            },

            updateContent({ id }) {
                Promise.all(
                    [
                        getLookupContentCategories(),
                        contentSingle(id)
                    ]
                ).then(resp => {
                    this.lookupContentCategories = resp[0].data
                    this.updateContentDialog.formModel = resp[1].data
                }).then(_ => {
                    this.updateContentDialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateContentUploaderOnSuccess(resp) {
                let quill = this.$refs['updateContentQuillEditor'].quill
                if (resp) {
                    let length = quill.getSelection().index;
                    quill.insertEmbed(length, 'image', process.env.BASE_URL + resp)
                    quill.setSelection(length + 1)
                } else {
                    //
                }
            },
            updateContentSave() {
                this.$refs['updateContentRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.updateContentDialog.saveLoading = true
                    contentUpdate(
                        this.updateContentDialog.formModel.id,
                        this.updateContentDialog.formModel).then(_ => {
                            this.searchContent()
                        }).then(_ => {
                            this.updateContentDialog.visible = false
                            this.updateContentDialog.saveLoading = false
                        }).catch(_ => {
                            this.updateContentDialog.saveLoading = false
                            //
                        })
                })
            },

            deleteContent({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    contentDelete(id).then(_ => {
                        this.searchContent()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            getLookupContentCategories().then(resp => {
                this.lookupContentCategories = resp.data
            }).catch(_ => {
                //
            })
            this.searchContent()
        }
    }
</script>

<style lang="scss" scoped>
    .content {
    }
</style>
