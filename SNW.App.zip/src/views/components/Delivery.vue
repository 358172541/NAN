<template>
    <div class="delivery">
        <el-row class="wrap"
                justify="center"
                type="flex">
            <el-col :span="24">

                <el-form ref="formRef"
                         :model="formModel"
                         :rules="formRules">

                    <el-form-item>
                        <el-row justify="space-between"
                                type="flex">
                            <div>派送</div>
                        </el-row>
                    </el-form-item>

                    <el-form-item prop="input">

                        <el-input v-model="formModel.input"></el-input>

                    </el-form-item>

                    <el-form-item>
                        <el-button size="medium"
                                   type="primary"
                                   :loading="loading"
                                   @click="submit">派送完成</el-button>
                        <div class="el-form-item__error">
                            {{errorMessage}}
                        </div>
                    </el-form-item>

                </el-form>

            </el-col>
        </el-row>
    </div>
</template>

<script>
    export default {
        name: 'Delivery',

        data() {
            return {
                loading: false,
                errorMessage: '',
                formModel: {
                    input: ''
                },
                formRules: {
                    input: [
                        { required: true, message: '请输入运单号', trigger: 'change' }
                    ]
                }
            }
        },

        methods: {
            submit() {
                this.$refs['formRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    // this.loading = true
                    console.log(this.formModel.input)
                })
            },
            reset() {
                this.$refs['formRef'].resetFields()
            }
        }
    }
</script>

<style lang="scss" scoped>
    .delivery {
        height: 100vh;
        margin: auto;
        max-width: 335px;
        padding: 0px 20px;

        .wrap {
            position: relative;
            top: 50%;
            transform: translateY(-50%);
        }
    }
</style>

<!--
.\wb163Cms.Web\aspx\html5_paisong.aspx.cs
-->
