<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>网站前台</el-breadcrumb-item>
              <el-breadcrumb-item>友情链接</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="friendlyLink">
          <el-row :gutter="8">
              <el-col class="margin-bottom-8">
                  <el-button icon="el-icon-plus" size="small" type="primary" @click="createFriendlyLink()">添加</el-button>
              </el-col>
          </el-row>
          <el-row :gutter="8">
              <el-col :sm="3" class="margin-bottom-8">
                  <el-input placeholder="标题" v-model="friendlyLinkTable.searchParams.title"></el-input>
              </el-col>
              <el-col :sm="21" class="margin-bottom-8">
                  <el-button icon="el-icon-search" type="primary" @click="searchFriendlyLink()">搜索</el-button>
              </el-col>
          </el-row>
          <el-row :gutter="8">
              <el-col class="margin-bottom-8">
                  <el-table border :data="friendlyLinkTable.pagedResult.items">
                      <el-table-column align="center" type="index" width="56">
                          <template slot="header" slot-scope="scope">
                              <i class="el-icon-s-operation font-size-16 font-weight-bold" />
                          </template>
                      </el-table-column>

                      <el-table-column align="left" label="标题" prop="title" width="230"></el-table-column>

                      <!--<el-table-column align="left" label="链接" prop="linkUrl" width="230"></el-table-column>-->

                      <el-table-column align="center" label="是否图片" prop="isImage" width="80">
                          <template slot-scope="scope">
                              <el-switch size="mini" :value="scope.row.isImage" nocursor></el-switch>
                          </template>
                      </el-table-column>

                      <!--<el-table-column align="left" label="图片路径" prop="imagePath" width="230"></el-table-column>-->
                      <!--<el-table-column align="left" label="联系人" prop="contactor" width="230"></el-table-column>-->
                      <!--<el-table-column align="left" label="电话号码" prop="phoneNumber" width="230"></el-table-column>-->
                      <!--<el-table-column align="left" label="电子邮箱" prop="email" width="230"></el-table-column>-->

                      <el-table-column align="center" label="是否推荐" prop="isRecommended" width="80">
                          <template slot-scope="scope">
                              <el-switch size="mini" :value="scope.row.isRecommended" nocursor></el-switch>
                          </template>
                      </el-table-column>

                      <el-table-column align="center" label="排序" prop="sort" width="70"></el-table-column>

                      <el-table-column align="center" label="是否启用" prop="isEnabled" width="80">
                          <template slot-scope="scope">
                              <el-switch size="mini" :value="scope.row.isEnabled" nocursor></el-switch>
                          </template>
                      </el-table-column>

                      <el-table-column align="left" prop="remark" label="备注" width="230"></el-table-column>

                      <el-table-column align="left" label="操作">
                          <template slot-scope="scope">
                              <el-button icon="el-icon-edit" plain size="mini"
                                         @click="updateFriendlyLink(scope.row)">修改</el-button>
                              <el-button icon="el-icon-delete" plain size="mini"
                                         @click="deleteFriendlyLink(scope.row)">删除</el-button>
                          </template>
                      </el-table-column>
                  </el-table>
              </el-col>
          </el-row>
          <el-row :gutter="8">
              <el-col class="margin-bottom-8">
                  <el-pagination background layout="prev, pager, next, sizes, total"
                                 :current-page="friendlyLinkTable.pagedParams.page"
                                 :page-size="friendlyLinkTable.pagedParams.pageSize"
                                 :page-sizes="[10]"
                                 :total="friendlyLinkTable.pagedResult.totalCount"
                                 @current-change="searchFriendlyLinkPageChange"
                                 @size-change="searchFriendlyLinkPageSizeChange">
                  </el-pagination>
              </el-col>
          </el-row>

          <el-dialog title="添加" width="380px"
                     :close-on-click-modal="false"
                     :visible.sync="createFriendlyLinkDialog.visible">

              <el-form :model="createFriendlyLinkDialog.formModel"
                       :rules="createFriendlyLinkDialog.formRules"
                       ref="createFriendlyLinkRef"
                       label-width="79px">

                  <el-form-item label="标题" prop="title">
                      <el-input v-model="createFriendlyLinkDialog.formModel.title"></el-input>
                  </el-form-item>

                  <el-form-item label="链接" prop="linkUrl">
                      <el-input v-model="createFriendlyLinkDialog.formModel.linkUrl"></el-input>
                  </el-form-item>

                  <el-form-item label="是否图片" prop="isImage">
                      <el-switch v-model="createFriendlyLinkDialog.formModel.isImage"></el-switch>
                  </el-form-item>

                  <!--<el-form-item label="是否图片" prop="isImage">
                      <el-switch v-model="createFriendlyLinkDialog.formModel.isImage"></el-switch>
                  </el-form-item>-->

                  <el-form-item label="联系人" prop="contactor">
                      <el-input v-model="createFriendlyLinkDialog.formModel.contactor"></el-input>
                  </el-form-item>

                  <el-form-item label="联系电话" prop="phoneNumber">
                      <el-input v-model="createFriendlyLinkDialog.formModel.phoneNumber"></el-input>
                  </el-form-item>

                  <el-form-item label="电子邮箱" prop="email">
                      <el-input v-model="createFriendlyLinkDialog.formModel.email"></el-input>
                  </el-form-item>

                  <el-form-item label="是否推荐" prop="isRecommended">
                      <el-switch v-model="createFriendlyLinkDialog.formModel.isRecommended"></el-switch>
                  </el-form-item>

                  <el-row>
                      <el-col :span="12">
                          <el-form-item label="排序" prop="sort">
                              <el-input-number controls-position="right"
                                               v-model="createFriendlyLinkDialog.formModel.sort"
                                               class="width-100-percent"
                                               :min="111"
                                               :max="999"></el-input-number>
                          </el-form-item>
                      </el-col>
                  </el-row>

                  <el-form-item label="是否可用" prop="isEnabled">
                      <el-switch v-model="createFriendlyLinkDialog.formModel.isEnabled"></el-switch>
                  </el-form-item>

                  <el-form-item label="备注" prop="remark">
                      <el-input type="textarea" v-model="createFriendlyLinkDialog.formModel.remark"></el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button type="primary"
                                 :loading="createFriendlyLinkDialog.saveLoading"
                                 @click="createFriendlyLinkSave()">保存</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="修改" width="380px"
                     :close-on-click-modal="false"
                     :visible.sync="updateFriendlyLinkDialog.visible">

              <el-form :model="updateFriendlyLinkDialog.formModel"
                       :rules="updateFriendlyLinkDialog.formRules"
                       ref="updateFriendlyLinkRef"
                       label-width="79px">

                  <el-form-item label="标题" prop="title">
                      <el-input v-model="updateFriendlyLinkDialog.formModel.title"></el-input>
                  </el-form-item>

                  <el-form-item label="链接" prop="linkUrl">
                      <el-input v-model="updateFriendlyLinkDialog.formModel.linkUrl"></el-input>
                  </el-form-item>

                  <el-form-item label="是否图片" prop="isImage">
                      <el-switch v-model="updateFriendlyLinkDialog.formModel.isImage"></el-switch>
                  </el-form-item>

                  <!--<el-form-item label="是否图片" prop="isImage">
                      <el-switch v-model="updateFriendlyLinkDialog.formModel.isImage"></el-switch>
                  </el-form-item>-->

                  <el-form-item label="联系人" prop="contactor">
                      <el-input v-model="updateFriendlyLinkDialog.formModel.contactor"></el-input>
                  </el-form-item>

                  <el-form-item label="联系电话" prop="phoneNumber">
                      <el-input v-model="updateFriendlyLinkDialog.formModel.phoneNumber"></el-input>
                  </el-form-item>

                  <el-form-item label="电子邮箱" prop="email">
                      <el-input v-model="updateFriendlyLinkDialog.formModel.email"></el-input>
                  </el-form-item>

                  <el-form-item label="是否推荐" prop="isRecommended">
                      <el-switch v-model="updateFriendlyLinkDialog.formModel.isRecommended"></el-switch>
                  </el-form-item>

                  <el-row>
                      <el-col :span="12">
                          <el-form-item label="排序" prop="sort">
                              <el-input-number controls-position="right"
                                               v-model="updateFriendlyLinkDialog.formModel.sort"
                                               class="width-100-percent"
                                               :min="111"
                                               :max="999"></el-input-number>
                          </el-form-item>
                      </el-col>
                  </el-row>

                  <el-form-item label="是否可用" prop="isEnabled">
                      <el-switch border v-model="updateFriendlyLinkDialog.formModel.isEnabled"></el-switch>
                  </el-form-item>

                  <el-form-item label="备注" prop="remark">
                      <el-input type="textarea" v-model="updateFriendlyLinkDialog.formModel.remark"></el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button type="primary"
                                 :loading="updateFriendlyLinkDialog.saveLoading"
                                 @click="updateFriendlyLinkSave()">保存</el-button>
                  </el-form-item>
              </el-form>

          </el-dialog>
      </div>
    </el-card>
</template>

<script>
    import {
        friendlyLinkSearch,
        friendlyLinkSingle,
        friendlyLinkCreate,
        friendlyLinkUpdate,
        friendlyLinkDelete
    } from '@/api/services/friendlyLinkService'

    export default {
        name: 'FriendlyLink',
        data() {
            return {
                friendlyLinkTable: {
                    searchParams: {
                        title: ''
                    },
                    pagedParams: {
                        number: '',
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },
                createFriendlyLinkDialog: {
                    errorMessage: '',
                    formModel: {
                        title: '',
                        linkUrl: '',
                        isImage: false,
                        ImagePath: '',
                        contactor: '',
                        phoneNumber: '',
                        email: '',
                        isRecommended: false,
                        sort: 111,
                        isEnabled: true,
                        remark: ''
                    },
                    formRules: {
                        title: [
                            { required: true, message: '请填写标题', trigger: 'change' }
                        ],
                        linkUrl: [
                            { required: true, message: '请填写链接地址', trigger: 'change' }
                        ],
                        sort: [
                            { required: true, message: '请填写排序', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateFriendlyLinkDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        title: [
                            { required: true, message: '请填写标题', trigger: 'change' }
                        ],
                        linkUrl: [
                            { required: true, message: '请填写链接地址', trigger: 'change' }
                        ],
                        sort: [
                            { required: true, message: '请填写排序', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                }
            }
        },
        methods: {
            searchFriendlyLink() {
                this.friendlyLinkTable.pagedParams.title = this.friendlyLinkTable.searchParams.title
                this.friendlyLinkTable.pagedParams.page = 1
                friendlyLinkSearch(this.friendlyLinkTable.pagedParams).then(resp => {
                    this.friendlyLinkTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchFriendlyLinkPageChange(page) {
                this.friendlyLinkTable.pagedParams.page = page
                friendlyLinkSearch(this.friendlyLinkTable.pagedParams).then(resp => {
                    this.friendlyLinkTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchFriendlyLinkPageSizeChange(pageSize) {
                this.friendlyLinkTable.pagedParams.page = 1
                this.friendlyLinkTable.pagedParams.pageSize = pageSize
                friendlyLinkSearch(this.friendlyLinkTable.pagedParams).then(resp => {
                    this.friendlyLinkTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createFriendlyLink() {
                this.createFriendlyLinkDialog.visible = true
            },
            createFriendlyLinkSave() {
                this.$refs['createFriendlyLinkRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.createFriendlyLinkDialog.saveLoading = true
                    friendlyLinkCreate(this.createFriendlyLinkDialog.formModel).then(_ => {
                        this.searchFriendlyLink()
                    }).then(_ => {
                        this.createFriendlyLinkDialog.visible = false
                        this.createFriendlyLinkDialog.saveLoading = false
                        this.$refs['createFriendlyLinkRef'].resetFields()
                    }).catch(_ => {
                        //
                    })
                })
            },
            updateFriendlyLink({ id }) {
                friendlyLinkSingle(id).then(resp => {
                    this.updateFriendlyLinkDialog.formModel = resp.data
                }).then(_ => {
                    this.updateFriendlyLinkDialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateFriendlyLinkSave() {
                this.$refs['updateFriendlyLinkRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.updateFriendlyLinkDialog.saveLoading = true
                    friendlyLinkUpdate(this.updateFriendlyLinkDialog.formModel.id, this.updateFriendlyLinkDialog.formModel).then(_ => {
                        this.searchFriendlyLink()
                    }).then(_ => {
                        this.updateFriendlyLinkDialog.visible = false
                        this.updateFriendlyLinkDialog.saveLoading = false
                    }).catch(_ => {
                        //
                    })
                })
            },
            deleteFriendlyLink({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    friendlyLinkDelete(id).then(_ => {
                        this.searchFriendlyLink()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            this.searchFriendlyLink()
        }
    }
</script>

<style lang="scss" scoped>
    .friendlyLink {
    }
</style>
