<template>
    <div class="advert">
        Advert
    </div>
</template>

<script>
    export default {
        name: 'Advert',
        data() {
            return {

            }
        }
    }
</script>

<style lang="scss" scoped>
    .advert {
    }
</style>
