<template>
    <el-card>
        <div slot="header" class="clearfix">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item>货物管理</el-breadcrumb-item>
                <el-breadcrumb-item>货物-派送路线车次</el-breadcrumb-item>
            </el-breadcrumb>
        </div>

        <div class="shift">

            <el-row :gutter="8">
                <el-col :span="3">
                    <el-select class="width-100-percent"
                               clearable
                               placeholder="派送路线"
                               v-model="shiftTable.searchParams.deliveryRouteId">
                        <el-option v-for="item in lookupDeliveryRoutes"
                                   :key="item.id"
                                   :label="item.number"
                                   :value="item.id">
                        </el-option>
                    </el-select>
                </el-col>
                <el-col :span="3">
                    <el-date-picker class="width-100-percent"
                                    placeholder="开始时间"
                                    placement="bottom-start"
                                    type="date"
                                    v-model="shiftTable.searchParams.createTimeFrom">
                    </el-date-picker>
                </el-col>
                <el-col :span="3">
                    <el-date-picker class="width-100-percent"
                                    placeholder="结束时间"
                                    placement="bottom-start"
                                    type="date"
                                    v-model="shiftTable.searchParams.createTimeTo">
                    </el-date-picker>
                </el-col>
                <el-col :span="15">
                    <el-button icon="el-icon-search"
                               type="primary"
                               @click="searchShift">查询</el-button>
                    <el-button icon="el-icon-circle-plus-outline"
                               type="success"
                               @click="createShift">新增</el-button>
                    <el-button icon="el-icon-edit-outline"
                               type="info"
                               @click="finishShift">完成装车</el-button>
                </el-col>
            </el-row>

            <el-table border
                      class="margin-top"
                      :data="shiftTable.pagedResult.items"
                      :row-key="'id'"
                      :row-style="shiftTableRowStyle"
                      @selection-change="shiftTableSelectionChange">

                <el-table-column align="center" type="selection" width="40"></el-table-column>

                <el-table-column align="left" label="编号" prop="number"></el-table-column>

                <el-table-column align="left" label="派送路线" prop="deliveryRouteNumber"></el-table-column>

                <el-table-column align="left" label="所属司机" prop="driverName"></el-table-column>

                <el-table-column align="left" label="联系电话" prop="contactPhoneNumber"></el-table-column>

                <el-table-column align="left" label="车牌号码" prop="licensePlateNumber"></el-table-column>

                <el-table-column align="left" label="创建时间" prop="createTime"></el-table-column>

                <el-table-column align="center" label="状态">
                    <template slot-scope="scope">
                        <span :style="{ color: scope.row.statusColor }">
                            {{scope.row.statusDisplay}}
                        </span>
                    </template>
                </el-table-column>

                <el-table-column align="center" label="出库检测">
                    <template slot-scope="scope">
                        <el-button icon="el-icon-edit-outline"
                                   size="mini"
                                   type="info"
                                   @click="detectShift(scope.row)">开始检测</el-button>
                    </template>
                </el-table-column>

                <el-table-column align="left" label="备注" prop="remark" />

                <el-table-column align="center" label="操作项" width="350">
                    <template slot-scope="scope">
                        <el-button icon="el-icon-edit-outline"
                                   size="mini"
                                   type="warning"
                                   @click="updateShift(scope.row)">编辑</el-button>
                        <el-button icon="el-icon-delete"
                                   size="mini"
                                   type="danger"
                                   @click="deleteShift(scope.row)">删除</el-button>
                        <el-button icon="el-icon-edit-outline"
                                   size="mini"
                                   type="primary"
                                   @click="manageShiftPackages(scope.row)">管理包裹</el-button>
                        <el-button icon="el-icon-edit-outline"
                                   size="mini"
                                   type="info"
                                   @click="exportShiftPackages(scope.row)">导出派送清单</el-button>
                    </template>
                </el-table-column>

            </el-table>

            <el-pagination background
                           class="margin-top"
                           layout="prev, pager, next, total"
                           :current-page="shiftTable.pagedParams.page"
                           :page-size="shiftTable.pagedParams.pageSize"
                           :pager-count="5"
                           :total="shiftTable.pagedResult.totalCount"
                           @current-change="searchShiftPageChange"
                           @size-change="searchShiftPageSizeChange">
            </el-pagination>

            <el-dialog title="新增"
                       width="384px"
                       :close-on-click-modal="false"
                       :visible.sync="createShiftDialog.visible">

                <el-form label-width="76px"
                         ref="createShiftRef"
                         :model="createShiftDialog.formModel"
                         :rules="createShiftDialog.formRules">

                    <el-form-item label="编号"
                                  prop="number">
                        <el-input v-model="createShiftDialog.formModel.number">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="派送路线"
                                  prop="deliveryRouteId">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder=""
                                   v-model="createShiftDialog.formModel.deliveryRouteId">
                            <el-option v-for="item in lookupDeliveryRoutes"
                                       :label="item.number"
                                       :key="item.id"
                                       :value="item.id">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="派送公司"
                                  prop="expressCompanyName">
                        <el-input v-model="createShiftDialog.formModel.expressCompanyName">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="所属司机"
                                  prop="driverName">
                        <el-input v-model="createShiftDialog.formModel.driverName">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="联系电话"
                                  prop="contactPhoneNumber">
                        <el-input v-model="createShiftDialog.formModel.contactPhoneNumber">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="车牌号码"
                                  prop="licensePlateNumber">
                        <el-input v-model="createShiftDialog.formModel.licensePlateNumber">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="备注"
                                  prop="remark">
                        <el-input type="textarea"
                                  rows="5"
                                  v-model="createShiftDialog.formModel.remark"></el-input>
                    </el-form-item>

                    <el-form-item>
                        <el-button icon="el-icon-edit-outline"
                                   type="primary"
                                   :loading="createShiftDialog.saveLoading"
                                   @click="createShiftSave">保存</el-button>
                        <el-button icon="el-icon-edit-outline"
                                   type="danger"
                                   @click="createShiftDialog.visible=false">取消</el-button>
                    </el-form-item>

                </el-form>

            </el-dialog>

            <el-dialog title="编辑"
                       width="384px"
                       :close-on-click-modal="false"
                       :visible.sync="updateShiftDialog.visible">

                <el-form label-width="95px"
                         ref="updateShiftRef"
                         :model="updateShiftDialog.formModel"
                         :rules="updateShiftDialog.formRules">

                    <el-form-item label="编号"
                                  prop="number">
                        <el-input v-model="updateShiftDialog.formModel.number">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="派送路线"
                                  prop="deliveryRouteId">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder=""
                                   v-model="updateShiftDialog.formModel.deliveryRouteId">
                            <el-option v-for="item in lookupDeliveryRoutes"
                                       :label="item.number"
                                       :key="item.id"
                                       :value="item.id">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="派送公司"
                                  prop="expressCompanyName">
                        <el-input v-model="updateShiftDialog.formModel.expressCompanyName">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="所属司机"
                                  prop="driverName">
                        <el-input v-model="updateShiftDialog.formModel.driverName">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="联系电话"
                                  prop="contactPhoneNumber">
                        <el-input v-model="updateShiftDialog.formModel.contactPhoneNumber">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="车牌号码"
                                  prop="licensePlateNumber">
                        <el-input v-model="updateShiftDialog.formModel.licensePlateNumber">
                        </el-input>
                    </el-form-item>

                    <el-form-item label="备注"
                                  prop="remark">
                        <el-input type="textarea"
                                  rows="5"
                                  v-model="updateShiftDialog.formModel.remark">
                        </el-input>
                    </el-form-item>

                    <el-form-item>
                        <el-button icon="el-icon-edit-outline"
                                   type="primary"
                                   :loading="updateShiftDialog.saveLoading"
                                   @click="updateShiftSave">保存</el-button>
                        <el-button icon="el-icon-edit-outline"
                                   type="danger"
                                   @click="updateShiftDialog.visible=false">取消</el-button>
                    </el-form-item>
                </el-form>

            </el-dialog>

            <el-dialog title="管理包裹"
                       width="1360px"
                       :close-on-click-modal="false"
                       :visible.sync="shiftPackagesDialog.visible">

                <el-descriptions size="medium"
                                 :column="8">
                    <el-descriptions-item label="编号">
                        <span class="font-weight-bold">
                            {{shiftPackagesDialog.info.number}}
                        </span>
                    </el-descriptions-item>
                    <el-descriptions-item label="总体积">
                        <span class="font-weight-bold">
                            {{shiftPackagesDialog.shiftPackagesTable.pagedResult.extras.totalVolume}} M³
                        </span>
                    </el-descriptions-item>
                    <el-descriptions-item label="总重量">
                        <span class="font-weight-bold">
                            {{shiftPackagesDialog.shiftPackagesTable.pagedResult.extras.totalWeight}} KG
                        </span>
                    </el-descriptions-item>
                </el-descriptions>

                <el-row class="margin-top"
                        :gutter="8">

                    <el-col :span="3">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder="所属会员"
                                   v-model="shiftPackagesDialog.shiftPackagesTable.searchParams.memberId">
                            <el-option v-for="item in lookupMembers"
                                       :key="item.id"
                                       :label="item.account"
                                       :value="item.id">
                            </el-option>
                        </el-select>
                    </el-col>

                    <el-col :span="3">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder="地区"
                                   v-model="shiftPackagesDialog.shiftPackagesTable.searchParams.regionId">
                            <el-option v-for="item in lookupRegions"
                                       :key="item.id"
                                       :label="item.number"
                                       :value="item.id">
                            </el-option>
                        </el-select>
                    </el-col>

                    <el-col :span="3">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder="派送地区"
                                   v-model="shiftPackagesDialog.shiftPackagesTable.searchParams.deliveryRegionId">
                            <el-option v-for="item in lookupDeliveryRegions"
                                       :key="item.id"
                                       :label="item.number"
                                       :value="item.id">
                            </el-option>
                        </el-select>
                    </el-col>

                    <el-col :span="3">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder="物品类型"
                                   v-model="shiftPackagesDialog.shiftPackagesTable.searchParams.itemType">
                            <el-option v-for="item in lookupItemTypes"
                                       :key="item.key"
                                       :label="item.value"
                                       :value="item.key">
                            </el-option>
                        </el-select>
                    </el-col>

                    <el-col :span="3">
                        <el-input placeholder="运单号"
                                  v-model="shiftPackagesDialog.shiftPackagesTable.searchParams.expressNumber">
                        </el-input>
                    </el-col>

                    <el-col :span="3">
                        <el-input placeholder="唛头"
                                  v-model="shiftPackagesDialog.shiftPackagesTable.searchParams.mark">
                        </el-input>
                    </el-col>

                    <el-col :span="6">
                        <el-button icon="el-icon-search"
                                   type="primary"
                                   @click="searchShiftPackages">查询</el-button>
                        <!--<el-button icon="el-icon-edit-outline"
                           type="info"
                           @click="">导出小包</el-button>-->
                    </el-col>
                </el-row>

                <el-row class="margin-top">
                    <el-col :span="24">
                        <el-button icon="el-icon-circle-plus-outline"
                                   type="success"
                                   @click="importShiftPackagesDialogOpen">导入库存</el-button>
                        <el-button icon="el-icon-edit-outline"
                                   type="danger"
                                   @click="removeShiftPackages">移回库存</el-button>
                    </el-col>
                </el-row>

                <el-table border
                          class="margin-top"
                          :data="shiftPackagesDialog.shiftPackagesTable.pagedResult.items"
                          :row-key="'id'"
                          :row-style="shiftPackagesTableRowStyle"
                          @selection-change="shiftPackagesTableSelectionChange">

                    <el-table-column align="center" type="selection" width="40"></el-table-column>

                    <el-table-column align="center" label="类型" prop="itemTypeDisplay"></el-table-column>

                    <el-table-column align="left" label="运单号" prop="expressNumber"></el-table-column>

                    <el-table-column align="left" label="唛头" prop="mark"></el-table-column>

                    <el-table-column align="center" label="会员编号" prop="memberAccount"></el-table-column>

                    <el-table-column align="center" label="柜号" prop="containerNumber"></el-table-column>

                    <el-table-column align="left" label="品名" prop="itemName"></el-table-column>

                    <el-table-column align="center" label="地区" prop="regionNumber"></el-table-column>

                    <el-table-column align="center" label="件数" prop="itemCount"></el-table-column>

                    <el-table-column align="center" label="重量" prop="weight"></el-table-column>

                    <el-table-column align="center" label="体积" prop="volume"></el-table-column>

                    <el-table-column align="center" label="包装类型" prop="packingTypeDisplay"></el-table-column>

                    <el-table-column align="center" label="出库检测" prop="outputStockDetectPassedDisplay">
                        <template slot-scope="scope">
                            <el-tag type="success"
                                    v-if="scope.row.outputStockDetectPassed">
                                {{scope.row.outputStockDetectPassedDisplay}}
                            </el-tag>
                            <el-tag type="danger"
                                    v-if="!scope.row.outputStockDetectPassed">
                                {{scope.row.outputStockDetectPassedDisplay}}
                            </el-tag>
                        </template>
                    </el-table-column>

                    <el-table-column align="center" label="操作项">
                        <template slot-scope="scope">
                            <el-button icon="el-icon-view"
                                       size="mini"
                                       type="info"
                                       v-if="!scope.row.outputStockDetectPassed"
                                       @click="packageNumberDialogOpen(scope.row)">查看</el-button>
                        </template>
                    </el-table-column>

                </el-table>

                <el-pagination background
                               class="margin-top"
                               layout="prev, pager, next, total"
                               :current-page="shiftPackagesDialog.shiftPackagesTable.pagedParams.page"
                               :pager-count="5"
                               :page-size="shiftPackagesDialog.shiftPackagesTable.pagedParams.pageSize"
                               :total="shiftPackagesDialog.shiftPackagesTable.pagedResult.totalCount"
                               @current-change="searchShiftPackagesPageChange"
                               @size-change="searchShiftPackagesPageSizeChange">
                </el-pagination>

            </el-dialog>

            <el-dialog append-to-body
                       title="查看"
                       width="576px"
                       :close-on-click-modal="false"
                       :visible.sync="packageNumberDialog.visible">

                <el-row :gutter="8">
                    <el-col :span="3">
                        <el-button icon="el-icon-edit-outline"
                                   type="primary"
                                   @click="printLabel">打印未检测条码</el-button>
                    </el-col>
                </el-row>

                <el-table border
                          class="margin-top"
                          :data="packageNumberDialog.packageNumberTable.pagedResult.items"
                          :row-key="'id'">

                    <el-table-column align="left" label="条码单号" prop="value"></el-table-column>

                    <el-table-column align="left" label="出库检测" prop="destOutIsPassDisplay"></el-table-column>

                </el-table>

                <el-pagination background
                               class="margin-top"
                               layout="prev, pager, next, total"
                               :current-page="packageNumberDialog.packageNumberTable.pagedParams.page"
                               :page-size="packageNumberDialog.packageNumberTable.pagedParams.pageSize"
                               :pager-count="5"
                               :total="packageNumberDialog.packageNumberTable.pagedResult.totalCount"
                               @current-change="packageNumberPageChange"
                               @size-change="packageNumberPageSizeChange">
                </el-pagination>



            </el-dialog>

            <el-dialog append-to-body
                       title="导入库存"
                       width="1280px"
                       :close-on-click-modal="false"
                       :visible.sync="importShiftPackagesDialog.visible">

                <el-row :gutter="8">

                    <el-col :span="3">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder="所属会员"
                                   v-model="importShiftPackagesDialog.importShiftPackagesTable.searchParams.memberId">
                            <el-option v-for="item in lookupMembers"
                                       :key="item.id"
                                       :label="item.account"
                                       :value="item.id">
                            </el-option>
                        </el-select>
                    </el-col>

                    <!--<el-col :span="3">
                <el-select class="width-100-percent"
                           clearable
                           placeholder="货柜"
                           v-model="importStockDialog.importStockTable.searchParams.memberId">
                    <el-option v-for="item in lookupMembers"
                               :key="item.id"
                               :label="item.account"
                               :value="item.id">
                    </el-option>
                </el-select>
            </el-col>-->

                    <el-col :span="3">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder="地区"
                                   v-model="importShiftPackagesDialog.importShiftPackagesTable.searchParams.regionId">
                            <el-option v-for="item in lookupRegions"
                                       :key="item.id"
                                       :label="item.number"
                                       :value="item.id">
                            </el-option>
                        </el-select>
                    </el-col>

                    <el-col :span="3">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder="派送地区"
                                   v-model="importShiftPackagesDialog.importShiftPackagesTable.searchParams.deliveryRegionId">
                            <el-option v-for="item in lookupDeliveryRegions"
                                       :key="item.id"
                                       :label="item.number"
                                       :value="item.id">
                            </el-option>
                        </el-select>
                    </el-col>

                    <el-col :span="3">
                        <el-select class="width-100-percent"
                                   clearable
                                   placeholder="物品类型"
                                   v-model="importShiftPackagesDialog.importShiftPackagesTable.searchParams.itemType">
                            <el-option v-for="item in lookupItemTypes"
                                       :key="item.key"
                                       :label="item.value"
                                       :value="item.key">
                            </el-option>
                        </el-select>
                    </el-col>

                    <el-col :span="3">
                        <el-input placeholder="运单号"
                                  v-model="importShiftPackagesDialog.importShiftPackagesTable.searchParams.expressNumber">
                        </el-input>
                    </el-col>

                    <el-col :span="3">
                        <el-input placeholder="唛头"
                                  v-model="importShiftPackagesDialog.importShiftPackagesTable.searchParams.mark">
                        </el-input>
                    </el-col>

                    <el-col :span="6">
                        <el-button icon="el-icon-search"
                                   type="primary"
                                   @click="importShiftPackagesSearch">查询</el-button>
                        <el-button icon="el-icon-edit-outline"
                                   type="info"
                                   @click="importShiftPackages">批量添加</el-button>
                    </el-col>

                </el-row>

                <el-table border
                          class="margin-top"
                          :data="importShiftPackagesDialog.importShiftPackagesTable.pagedResult.items"
                          :row-key="'id'"
                          :row-style="importShiftPackagesTableRowStyle"
                          @selection-change="importShiftPackagesTableSelectionChange">

                    <el-table-column align="center" type="selection" width="40"></el-table-column>

                    <el-table-column align="center" label="类型" prop="itemTypeDisplay"></el-table-column>

                    <el-table-column align="left" label="运单号" prop="expressNumber"></el-table-column>

                    <el-table-column align="left" label="唛头" prop="mark"></el-table-column>

                    <el-table-column align="center" label="会员编号" prop="memberAccount"></el-table-column>

                    <el-table-column align="center" label="重量" prop="weight"></el-table-column>

                    <el-table-column align="center" label="体积" prop="volume"></el-table-column>

                    <el-table-column align="left" label="品名" prop="itemName"></el-table-column>

                    <el-table-column align="center" label="件数" prop="itemCount"></el-table-column>

                    <el-table-column align="center" label="地区" prop="regionNumber"></el-table-column>

                    <el-table-column align="left" label="派送地区" prop="deliveryRegionNumber"></el-table-column>

                    <el-table-column align="left" label="地址" prop="detailAddress"></el-table-column>

                </el-table>

                <el-pagination background
                               class="margin-top"
                               layout="prev, pager, next, total"
                               :current-page="importShiftPackagesDialog.importShiftPackagesTable.pagedParams.page"
                               :page-size="importShiftPackagesDialog.importShiftPackagesTable.pagedParams.pageSize"
                               :pager-count="5"
                               :total="importShiftPackagesDialog.importShiftPackagesTable.pagedResult.totalCount"
                               @current-change="importShiftPackagesPageChange"
                               @size-change="importShiftPackagesPageSizeChange">
                </el-pagination>

            </el-dialog>

            <div style="display:none">

                <div id="printElement">

                    <div style="page-break-after: always"
                         v-for="item in packageNumberDialog.packageNumberPrintData"
                         :key="item">

                        <table border="0" cellpadding="0" cellspacing="0" style="font-family: Arial; height: 66mm; width: 426px">

                            <tr style="height: 25mm">

                                <td colspan="2" style="border: 5px solid black; border-bottom: none; text-align: center">
                                    <div style="margin:5px 15px 0px 15px">
                                        <img :src="item.barcodeSrc" style="height: 60px; width: 100%" />
                                    </div>
                                    <span style="font-size: 30px; font-weight: bolder">
                                        {{item.expressNumber}}
                                    </span>
                                </td>

                            </tr>

                            <tr style="height: 21mm">

                                <td style="border: 5px solid black; border-bottom: none; border-right: none; font-size: 24px; font-weight: bolder; text-align: center; vertical-align: middle; width: 80px">
                                    MARK
                                </td>

                                <td style="border: 5px solid black; border-bottom: none; font-size: 34px; font-weight: bolder; text-align: center; vertical-align: middle">
                                    {{item.mark}}
                                </td>

                            </tr>

                            <tr style="height:10mm">

                                <td style="border: 5px solid black; border-bottom: none; border-right: none; font-size: 25px; font-weight: bolder; text-align: center; vertical-align: middle">
                                    POD
                                </td>

                                <td style="border: 5px solid black; border-bottom: none; font-size: 25px; font-weight: bolder; text-align: center; vertical-align: middle">
                                    CTNS
                                </td>

                            </tr>

                            <tr style="height:10mm">

                                <td style="border: 5px solid black; border-right: none; font-size: 25px; font-weight: bolder; text-align: center; vertical-align: middle">
                                    {{item.prefix}}
                                </td>

                                <td style="border: 5px solid black; font-size: 25px; font-weight: bolder; text-align: center; vertical-align: middle">
                                    {{item.itemCountIndex}}
                                </td>

                            </tr>

                        </table>
                    </div>

                </div>

            </div>
            
        </div>

    </el-card>
</template>

<script>
    import printJS from 'print-js'

    import {
        saveAs
    } from 'file-saver'

    import {
        getLookupDeliveryRegions,
        getLookupDeliveryRoutes,
        getLookupItemTypes,
        getLookupMembers,
        getLookupRegions
    } from '@/api/services/lookupService'

    import {
        getPagedPackageNumbersByPackageId
    } from '@/api/services/packageNumberService'

    import {
        shiftSearch,
        shiftSingle,
        shiftCreate,
        shiftDetect,
        shiftFinish,
        shiftUpdate,
        shiftDelete,
        shiftPackagesSearch,
        shiftPackagesImport,
        shiftPackagesImportSearch,
        shiftPackagesRemove,
        shiftPackagesExport,

        shiftPackagePackageNumberDestOutstockUnpassed
    } from '@/api/services/shiftService'

    export default {
        name: 'Shift',
        data() {
            return {
                lookupContainers: [],
                lookupDeliveryRegions: [],
                lookupDeliveryRoutes: [],
                lookupItemTypes: [],
                lookupMembers: [],
                lookupRegions: [],

                shiftTable: {
                    selection: [],
                    searchParams: {
                        createTimeFrom: '',
                        createTimeTo: '',
                        deliveryRouteId: null
                    },
                    pagedParams: {
                        createTimeFrom: '',
                        createTimeTo: '',
                        deliveryRouteId: null,
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },

                createShiftDialog: {
                    errorMessage: '',
                    formModel: {
                        number: '',
                        deliveryRouteId: null,
                        expressCompanyName: '',
                        driverName: '',
                        contactPhoneNumber: '',
                        licensePlateNumber: '',
                        remark: ''
                    },
                    formRules: {
                        number: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        deliveryRouteId: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        expressCompanyName: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        driverName: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        contactPhoneNumber: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        licensePlateNumber: [
                            { required: true, message: '', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateShiftDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        number: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        deliveryRouteId: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        expressCompanyName: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        driverName: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        contactPhoneNumber: [
                            { required: true, message: '', trigger: 'change' }
                        ],
                        licensePlateNumber: [
                            { required: true, message: '', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },

                shiftPackagesDialog: {
                    info: {
                        id: null,
                        number: ''
                    },
                    visible: false,
                    shiftPackagesTable: {
                        selection: [],
                        searchParams: {
                            memberId: null,
                            regionId: null,
                            deliveryRegionId: null,
                            itemType: null,
                            expressNumber: '',
                            mark: ''
                        },
                        pagedParams: {
                            memberId: null,
                            regionId: null,
                            deliveryRegionId: null,
                            itemType: null,
                            expressNumber: '',
                            mark: '',
                            page: 1,
                            pageSize: 10
                        },
                        pagedResult: {
                            items: [],
                            totalCount: 0,
                            extras: {
                                totalWeight: 0,
                                totalVolme: 0
                            }
                        }
                    }
                },

                packageNumberDialog: {
                    info: {
                        id: null,
                        expressNumber: '',
                    },
                    visible: false,
                    packageNumberTable: {
                        selection: [],
                        searchParams: {},
                        pagedParams: {
                            page: 1,
                            pageSize: 10
                        },
                        pagedResult: {
                            items: [],
                            totalCount: 0
                        }
                    },
                    packageNumberPrintData: []
                },

                importShiftPackagesDialog: {
                    info: {},
                    visible: false,
                    importShiftPackagesTable: {
                        selection: [],
                        searchParams: {
                            containerId: null,
                            deliveryRegionId: null,
                            memberId: null,
                            regionId: null,
                            itemType: null,
                            expressNumber: '',
                            mark: ''
                        },
                        pagedParams: {
                            containerId: null,
                            deliveryRegionId: null,
                            memberId: null,
                            regionId: null,
                            itemType: null,
                            expressNumber: '',
                            mark: '',
                            page: 1,
                            pageSize: 10
                        },
                        pagedResult: {
                            items: [],
                            totalCount: 0
                        }
                    }
                }
            }
        },
        methods: {
            shiftTableRowStyle({ row }) {
                return {
                    'background': row.background
                }
            },
            shiftTableSelectionChange(selection) {
                this.shiftTable.selection = selection
            },
            shiftPackagesTableRowStyle({ row }) {
                return {
                    'background': row.background
                }
            },
            shiftPackagesTableSelectionChange(selection) {
                let dialog = this.shiftPackagesDialog
                dialog.shiftPackagesTable.selection = selection
            },

            importShiftPackagesTableRowStyle({ row }) {
                return {
                    'background': row.background
                }
            },
            importShiftPackagesTableSelectionChange(selection) {
                let dialog = this.importShiftPackagesDialog
                dialog.importShiftPackagesTable.selection = selection
            },

            searchShift() {
                this.shiftTable.pagedParams.createTimeFrom = this.shiftTable.searchParams.createTimeFrom
                this.shiftTable.pagedParams.createTimeTo = this.shiftTable.searchParams.createTimeTo
                this.shiftTable.pagedParams.deliveryRouteId = this.shiftTable.searchParams.deliveryRouteId
                this.shiftTable.pagedParams.page = 1
                shiftSearch(this.shiftTable.pagedParams).then(resp => {
                    this.shiftTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchShiftPageChange(page) {
                this.shiftTable.pagedParams.page = page
                shiftSearch(this.shiftTable.pagedParams).then(resp => {
                    this.shiftTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchShiftPageSizeChange(pageSize) {
                this.shiftTable.pagedParams.page = 1
                this.shiftTable.pagedParams.pageSize = pageSize
                shiftSearch(this.shiftTable.pagedParams).then(resp => {
                    this.shiftTable.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createShift() {
                this.createShiftDialog.visible = true
            },
            createShiftSave() {
                this.$refs['createShiftRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.createShiftDialog.saveLoading = true
                    shiftCreate(this.createShiftDialog.formModel).then(_ => {
                        this.searchShift()
                    }).then(_ => {
                        this.createShiftDialog.visible = false
                        this.createShiftDialog.saveLoading = false
                        this.$refs['createShiftRef'].resetFields()
                    }).catch(_ => {
                        //
                    })
                })
            },
            updateShift({ id }) {
                shiftSingle(id).then(resp => {
                    this.updateShiftDialog.formModel = resp.data
                }).then(_ => {
                    this.updateShiftDialog.visible = true
                }).catch(_ => {
                    this.updateShiftDialog.saveLoading = false
                })
            },
            updateShiftSave() {
                this.$refs['updateShiftRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.updateShiftDialog.saveLoading = true
                    shiftUpdate(this.updateShiftDialog.formModel.id, this.updateShiftDialog.formModel).then(_ => {
                        this.searchShift()
                    }).then(_ => {
                        this.updateShiftDialog.visible = false
                        this.updateShiftDialog.saveLoading = false
                    }).catch(_ => {
                        this.updateShiftDialog.saveLoading = false
                    })
                })
            },
            deleteShift({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    shiftDelete(id).then(_ => {
                        this.searchShift()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            },

            detectShift({ id }) {
                shiftDetect([id]).then(resp => {
                    if (resp.data === true) {
                        this.$message({
                            showClose: true,
                            message: '检测通过',
                            type: 'success'
                        })
                    } else {
                        this.$message({
                            showClose: true,
                            message: '检测不通过，有包裹尚未通过出库检测',
                            type: 'error'
                        })
                    }
                }).catch(_ => {
                    //
                })
            },

            manageShiftPackages({ id, number }) {
                let dialog = this.shiftPackagesDialog
                dialog.info = { id, number }
                this.searchShiftPackages(true)
            },
            searchShiftPackages(showDialog = false) {
                let dialog = this.shiftPackagesDialog
                let table = dialog.shiftPackagesTable
                table.pagedParams.memberId = table.searchParams.memberId
                table.pagedParams.regionId = table.searchParams.regionId
                table.pagedParams.deliveryRegionId = table.searchParams.deliveryRegionId
                table.pagedParams.itemType = table.searchParams.itemType
                table.pagedParams.expressNumber = table.searchParams.expressNumber
                table.pagedParams.mark = table.searchParams.mark
                table.pagedParams.page = 1
                shiftPackagesSearch(dialog.info.id, table.pagedParams).then(resp => { // getPagedPackagesByShiftId
                    table.pagedResult = resp.data
                    if (showDialog === true) {
                        dialog.visible = true
                    }
                }).catch(_ => {
                    //
                })
            },
            searchShiftPackagesPageChange(page) {
                let dialog = this.shiftPackagesDialog
                let table = dialog.shiftPackagesTable
                table.pagedParams.page = page
                shiftPackagesSearch(dialog.info.id, table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchShiftPackagesPageSizeChange(pageSize) {
                let dialog = this.shiftPackagesDialog
                let table = dialog.shiftPackagesTable
                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize
                shiftPackagesSearch(this.shiftPackagesDialog.id, table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },

            packageNumberDialogOpen({ id, expressNumber }) {
                let dialog = this.packageNumberDialog
                dialog.info = { id, expressNumber }
                this.packageNumber(true)
            },
            packageNumber(showDialog = false) {
                let dialog = this.packageNumberDialog
                let table = dialog.packageNumberTable
                table.pagedParams.page = 1
                getPagedPackageNumbersByPackageId(dialog.info.id, table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                    if (showDialog === true) {
                        dialog.visible = true
                    }
                }).catch(_ => {
                    //
                })
            },
            packageNumberPageChange(page) {
                let dialog = this.packageNumberDialog
                let table = dialog.packageNumberTable
                table.pagedParams.page = page
                getPagedPackageNumbersByPackageId(dialog.info.id, table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            packageNumberPageSizeChange(pageSize) {
                let dialog = this.packageNumberDialog
                let table = dialog.packageNumberTable
                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize
                getPagedPackageNumbersByPackageId(dialog.info.id, table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },

            importShiftPackagesDialogOpen() {
                this.importShiftPackagesSearch(true)
            },
            importShiftPackagesSearch(showDialog = false) {
                let dialog = this.importShiftPackagesDialog
                let table = dialog.importShiftPackagesTable

                table.pagedParams.containerId = table.searchParams.containerId
                table.pagedParams.deliveryRegionId = table.searchParams.deliveryRegionId
                table.pagedParams.memberId = table.searchParams.memberId
                table.pagedParams.regionId = table.searchParams.regionId
                table.pagedParams.itemType = table.searchParams.itemType
                table.pagedParams.expressNumber = table.searchParams.expressNumber
                table.pagedParams.mark = table.searchParams.mark

                table.pagedParams.page = 1
                shiftPackagesImportSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                    if (showDialog === true) {
                        dialog.visible = true
                    }
                }).catch(_ => {
                    //
                })
            },
            importShiftPackagesPageChange(page) {
                let dialog = this.importShiftPackagesDialog
                let table = dialog.importShiftPackagesTable
                table.pagedParams.page = page
                shiftPackagesImportSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            importShiftPackagesPageSizeChange(pageSize) {
                let dialog = this.importShiftPackagesDialog
                let table = dialog.importShiftPackagesTable
                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize
                shiftPackagesImportSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            importShiftPackages() {
                let id = this.shiftPackagesDialog.info.id
                let dialog = this.importShiftPackagesDialog
                let selection = dialog.importShiftPackagesTable.selection
                if (selection.length === 0) {
                    this.$message({
                        showClose: true,
                        message: '请选择操作项',
                        type: 'warning'
                    })
                    return false
                }
                let packageIds = []
                for (let item of selection) {
                    packageIds.push(item.id)
                }
                shiftPackagesImport(id, packageIds).then(_ => {
                    this.searchShiftPackages()
                }).then(_ => {
                    dialog.visible = false
                }).catch(_ => {
                    //
                })
            },

            removeShiftPackages() {
                let dialog = this.shiftPackagesDialog
                let selection = dialog.shiftPackagesTable.selection
                if (selection.length === 0) {
                    this.$message({
                        showClose: true,
                        message: '请选择操作项',
                        type: 'warning'
                    })
                    return false
                }
                let packageIds = []
                for (let item of selection) {
                    packageIds.push(item.id)
                }
                shiftPackagesRemove(dialog.info.id, packageIds).then(_ => {
                    this.searchShiftPackages()
                }).catch(_ => {
                    //
                })
            },

            exportShiftPackages({ id }) {
                this.$confirm('确定导出派送清单', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(_ => {
                    shiftPackagesExport(id).then(resp => {
                        let blob = new Blob([resp.data], {
                            type: resp.data.type
                        })
                        let filename = resp.headers['x-filename']
                        saveAs(blob, filename)
                    }).catch(_ => {
                        //
                    })
                })
            },

            finishShift() {
                let selection = this.shiftTable.selection
                if (selection.length === 0) {
                    this.$message({
                        showClose: true,
                        message: '请选择操作项',
                        type: 'warning'
                    })
                    return false
                }
                let shiftIds = []
                for (let item of selection) {
                    shiftIds.push(item.id)
                }
                shiftDetect(shiftIds).then(resp => {
                    if (resp.data === false) {
                        this.$confirm('有包裹尚未通过出库检测，是否强制执行', '提示', {
                            confirmButtonText: '确定',
                            cancelButtonText: '取消',
                            type: 'warning'
                        }).then(_ => {
                            shiftFinish(shiftIds).then(_ => {
                                this.searchShift()
                                this.$message({
                                    showClose: true,
                                    message: '操作成功',
                                    type: 'success'
                                })
                            }).catch(_ => {
                                //
                            })
                        })
                    } else {
                        shiftFinish(shiftIds).then(_ => {
                            this.searchShift()
                            this.$message({
                                showClose: true,
                                message: '操作成功',
                                type: 'success'
                            })
                        })
                    }
                })
            },

            printLabel() {
                let dialog = this.packageNumberDialog
                shiftPackagePackageNumberDestOutstockUnpassed(dialog.info.id).then(resp => {
                    dialog.packageNumberPrintData = resp.data
                }).then(_ => {
                    printJS({
                        printable: 'printElement',
                        type: 'html',
                        scanStyles: true,
                        targetStyles: ['*']
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            getLookupDeliveryRegions().then(resp => {
                this.lookupDeliveryRegions = resp.data
            }).catch(_ => {
                //
            })
            getLookupDeliveryRoutes().then(resp => {
                this.lookupDeliveryRoutes = resp.data
            }).catch(_ => {
                //
            })
            getLookupItemTypes().then(resp => {
                this.lookupItemTypes = resp.data
            }).catch(_ => {
                //
            })
            getLookupMembers().then(resp => {
                this.lookupMembers = resp.data
            }).catch(_ => {
                //
            })
            getLookupRegions().then(resp => {
                this.lookupRegions = resp.data
            }).catch(_ => {
                //
            })
            this.searchShift()
        }
    }
</script>

<style lang="scss" scoped>
    .shift {
    }
</style>
