<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>网站前台</el-breadcrumb-item>
              <el-breadcrumb-item>内容类别</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="contentCategory">

          <el-button icon="el-icon-circle-plus-outline"
                     type="success"
                     @click="createContentCategory">新增</el-button>

          <el-table border
                    class="margin-top"
                    :data="structureLevel4ContentCategories"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" prop="display">
                  <template slot="header">
                      <i class="el-icon-view" />
                  </template>
                  <template slot-scope="scope">
                      <span :style="{ marginLeft: (scope.row.level - 1) * 20 + 'px' }">
                          <span>{{ scope.row.display }}</span>
                      </span>
                  </template>
              </el-table-column>

              <el-table-column align="left" label="唯一编号" prop="number"></el-table-column>

              <el-table-column align="left" label="标题" prop="display"></el-table-column>

              <el-table-column align="center" label="排序" prop="sort"></el-table-column>

              <el-table-column align="center" label="是否启用" prop="enabled">
                  <template slot-scope="scope">
                      <el-switch nocursor
                                 :value="scope.row.enabled">
                      </el-switch>
                  </template>
              </el-table-column>

              <el-table-column align="left" label="备注" prop="remark"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit-outline"
                                 size="mini"
                                 type="warning"
                                 @click="updateContentCategory(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                 size="mini"
                                 type="danger"
                                 @click="deleteContentCategory(scope.row)">删除</el-button>
                  </template>
              </el-table-column>

          </el-table>

          <!---->

          <el-dialog title="新增"
                     width="320px"
                     :close-on-click-modal="false"
                     :visible.sync="createContentCategoryDialog.visible">

              <el-form label-width="79px"
                       ref="createContentCategoryRef"
                       :model="createContentCategoryDialog.formModel"
                       :rules="createContentCategoryDialog.formRules">

                  <el-form-item label="所属父级"
                                prop="parentId">
                      <el-select clearable
                                 v-model="createContentCategoryDialog.formModel.parentId">
                          <el-option v-for="item in structureLevel4LookupContentCategories"
                                     :key="item.id"
                                     :label="item.display"
                                     :value="item.id">
                              <span :style="{ marginLeft: (item.level - 1) * 20 + 'px' }">
                                  <span>{{ item.display }}</span>
                              </span>
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="唯一编号"
                                prop="number">
                      <el-input v-model="createContentCategoryDialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="标题"
                                prop="display">
                      <el-input v-model="createContentCategoryDialog.formModel.display">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="排序"
                                prop="sort">
                      <el-input-number controls-position="right"
                                       v-model="createContentCategoryDialog.formModel.sort"
                                       :min="111"
                                       :max="999">
                      </el-input-number>
                  </el-form-item>

                  <el-form-item label="是否可用"
                                prop="enabled">
                      <el-switch active-color="#67c23a"
                                 v-model="createContentCategoryDialog.formModel.enabled">
                      </el-switch>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createContentCategoryDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-edit"
                                 type="primary"
                                 :loading="createContentCategoryDialog.saveLoading"
                                 @click="createContentCategorySave()">保存</el-button>
                      <el-button icon="el-icon-edit"
                                 type="danger"
                                 @click="createContentCategoryDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="updateContentCategoryDialog.visible">

              <el-form :model="updateContentCategoryDialog.formModel"
                       :rules="updateContentCategoryDialog.formRules"
                       ref="updateContentCategoryRef"
                       label-width="79px">

                  <el-form-item label="所属父级"
                                prop="parentId">
                      <el-select clearable
                                 v-model="updateContentCategoryDialog.formModel.parentId">
                          <el-option v-for="item in structureLevel4LookupContentCategories"
                                     :key="item.id"
                                     :label="item.display"
                                     :value="item.id">
                              <span :style="{ marginLeft: (item.level - 1) * 20 + 'px' }">
                                  <i :class="item.icon" />
                                  <span>{{ item.display }}</span>
                              </span>
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="唯一编号"
                                prop="number">
                      <el-input v-model="updateContentCategoryDialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="标题"
                                prop="display">
                      <el-input v-model="updateContentCategoryDialog.formModel.display">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="排序"
                                prop="sort">
                      <el-input-number controls-position="right"
                                       v-model="updateContentCategoryDialog.formModel.sort"
                                       :min="111"
                                       :max="999">
                      </el-input-number>
                  </el-form-item>

                  <el-form-item label="是否可用"
                                prop="enabled">
                      <el-switch active-color="#67c23a"
                                 v-model="updateContentCategoryDialog.formModel.enabled">
                      </el-switch>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateContentCategoryDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-edit"
                                 type="primary"
                                 :loading="updateContentCategoryDialog.saveLoading"
                                 @click="updateContentCategorySave()">保存</el-button>
                      <el-button icon="el-icon-edit"
                                 type="danger"
                                 @click="updateContentCategoryDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        getLookupContentCategories
    } from '@/api/services/lookupService'

    import {
        contentCategorySearch,
        contentCategorySingle,
        contentCategoryCreate,
        contentCategoryUpdate,
        contentCategoryDelete
    } from '@/api/services/contentCategoryService'

    export default {
        name: 'ContentCategory',

        computed: {
            structureLevel4ContentCategories() {
                let structureLevel = (structure, source, value = null, level = 0) => {
                    level++
                    let items = source.filter(x => x.parentId === value)
                    for (let i in items) {
                        let item = items[i]
                        item.level = level
                        structure.push(item)
                        structureLevel(structure, source, item.id, level)
                    }
                }
                let structure = []
                structureLevel(structure, JSON.parse(JSON.stringify(this.contentCategoryTable.items)))
                return structure
            },
            structureLevel4LookupContentCategories() {
                let structureLevel = (structure, source, value = null, level = 0) => {
                    level++
                    let items = source.filter(x => x.parentId === value)
                    for (let i in items) {
                        let item = items[i]
                        item.level = level
                        structure.push(item)
                        structureLevel(structure, source, item.id, level)
                    }
                }
                let structure = []
                structureLevel(structure, JSON.parse(JSON.stringify(this.lookupContentCategories)))
                return structure
            },
        },

        data() {
            return {
                lookupContentCategories: [],
                contentCategoryTable: {
                    items: []
                },
                createContentCategoryDialog: {
                    errorMessage: '',
                    formModel: {
                        parentId: null,
                        number: '',
                        display: '',
                        sort: 111,
                        enabled: true,
                        remark: ''
                    },
                    formRules: {
                        number: [
                            { required: true, message: '请填写唯一编号', trigger: 'change' }
                        ],
                        display: [
                            { required: true, message: '请填写标题', trigger: 'change' }
                        ],
                        sort: [
                            { required: true, message: '请填写排序', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateContentCategoryDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        number: [
                            { required: true, message: '请填写唯一编号', trigger: 'change' }
                        ],
                        display: [
                            { required: true, message: '请填写标题', trigger: 'change' }
                        ],
                        sort: [
                            { required: true, message: '请填写排序', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                }
            }
        },

        methods: {
            searchContentCategory() {
                contentCategorySearch().then(resp => {
                    this.contentCategoryTable.items = resp.data
                }).catch(_ => {
                    //
                })
            },
            createContentCategory() {
                getLookupContentCategories().then(resp => {
                    this.lookupContentCategories = resp.data
                }).then(_ => {
                    this.createContentCategoryDialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            createContentCategorySave() {
                this.$refs['createContentCategoryRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.createContentCategoryDialog.saveLoading = true
                    contentCategoryCreate(this.createContentCategoryDialog.formModel).then(_ => {
                        this.searchContentCategory()
                    }).then(_ => {
                        this.createContentCategoryDialog.visible = false
                        this.createContentCategoryDialog.saveLoading = false
                        this.$refs['createContentCategoryRef'].resetFields()
                    }).catch(_ => {
                        //
                    })
                })
            },
            updateContentCategory({ id }) {
                Promise.all(
                    [
                        getLookupContentCategories(),
                        contentCategorySingle(id)
                    ]
                ).then(resp => {
                    this.lookupContentCategories = resp[0].data
                    this.updateContentCategoryDialog.formModel = resp[1].data
                }).then(_ => {
                    this.updateContentCategoryDialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateContentCategorySave() {
                this.$refs['updateContentCategoryRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    this.updateContentCategoryDialog.saveLoading = true
                    contentCategoryUpdate(
                        this.updateContentCategoryDialog.formModel.id,
                        this.updateContentCategoryDialog.formModel).then(_ => {
                            this.searchContentCategory()
                        }).then(_ => {
                            this.updateContentCategoryDialog.visible = false
                            this.updateContentCategoryDialog.saveLoading = false
                        }).catch(_ => {
                            //
                        })
                })
            },
            deleteContentCategory({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    contentCategoryDelete(id).then(_ => {
                        this.searchContentCategory()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            this.searchContentCategory()
        }
    }
</script>

<style lang="scss" scoped>
    .contentCategory {
    }
</style>
