<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>基础信息</el-breadcrumb-item>
              <el-breadcrumb-item>派送路线</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="deliveryRoute">

          <el-row :gutter="8">
              <el-col :span="3">
                  <el-input placeholder="编号"
                            v-model="deliveryRouteTable.searchParams.number">
                  </el-input>
              </el-col>
              <el-col :span="3">
                  <el-select class="width-100-percent"
                             clearable
                             placeholder="所属地区"
                             v-model="deliveryRouteTable.searchParams.regionId">
                      <el-option v-for="item in lookupRegions"
                                 :key="item.id"
                                 :label="item.number"
                                 :value="item.id">
                      </el-option>
                  </el-select>
              </el-col>
              <el-col :span="18">
                  <el-button icon="el-icon-search"
                             type="primary"
                             @click="searchDeliveryRoute">查询</el-button>
                  <el-button icon="el-icon-circle-plus-outline"
                             type="success"
                             @click="createDeliveryRoute">新增</el-button>
              </el-col>
          </el-row>

          <el-table border
                    class="margin-top"
                    :data="deliveryRouteTable.pagedResult.items"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" label="编号" prop="number"></el-table-column>

              <el-table-column align="left" label="所属地区" prop="regionNumber"></el-table-column>

              <el-table-column align="left" label="备注" prop="remark"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit"
                                 size="mini"
                                 type="warning"
                                 @click="updateDeliveryRoute(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                 size="mini"
                                 type="danger"
                                 @click="deleteDeliveryRoute(scope.row)">删除</el-button>
                  </template>
              </el-table-column>
          </el-table>

          <el-pagination background
                         class="margin-top"
                         layout="prev, pager, next, total"
                         :current-page="deliveryRouteTable.pagedParams.page"
                         :page-size="deliveryRouteTable.pagedParams.pageSize"
                         :pager-count="5"
                         :total="deliveryRouteTable.pagedResult.totalCount"
                         @current-change="searchDeliveryRoutePageChange"
                         @size-change="searchDeliveryRoutePageSizeChange">
          </el-pagination>

          <!---->

          <el-dialog title="新增"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="createDeliveryRouteDialog.visible">

              <el-form label-width="76px"
                       ref="createDeliveryRouteRef"
                       :model="createDeliveryRouteDialog.formModel"
                       :rules="createDeliveryRouteDialog.formRules">

                  <el-form-item label="编号"
                                prop="number">
                      <el-input v-model="createDeliveryRouteDialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="所属地区"
                                prop="regionId">
                      <el-select clearable
                                 v-model="createDeliveryRouteDialog.formModel.regionId">
                          <el-option v-for="item in lookupRegions"
                                     :key="item.id"
                                     :label="item.number"
                                     :value="item.id">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createDeliveryRouteDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="createDeliveryRouteDialog.saveLoading"
                                 @click="createDeliveryRouteSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="createDeliveryRouteDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="384px"
                     :close-on-click-modal="false"
                     :visible.sync="updateDeliveryRouteDialog.visible">

              <el-form label-width="76px"
                       ref="updateDeliveryRouteRef"
                       :model="updateDeliveryRouteDialog.formModel"
                       :rules="updateDeliveryRouteDialog.formRules">

                  <el-form-item label="编号"
                                prop="account">
                      <el-input v-model="updateDeliveryRouteDialog.formModel.number">
                      </el-input>
                  </el-form-item>

                  <el-form-item label="所属地区"
                                prop="regionId">
                      <el-select clearable
                                 v-model="updateDeliveryRouteDialog.formModel.regionId">
                          <el-option v-for="item in lookupRegions"
                                     :key="item.id"
                                     :label="item.number"
                                     :value="item.id">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateDeliveryRouteDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="updateDeliveryRouteDialog.saveLoading"
                                 @click="updateDeliveryRouteSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="updateDeliveryRouteDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        getLookupRegions
    } from '@/api/services/lookupService'

    import {
        deliveryRouteSearch,
        deliveryRouteSingle,
        deliveryRouteCreate,
        deliveryRouteUpdate,
        deliveryRouteDelete
    } from '@/api/services/deliveryRouteService'

    export default {
        name: 'DeliveryRoute',

        data() {
            return {
                lookupRegions: [],

                deliveryRouteTable: {
                    searchParams: {
                        number: '',
                        regionId: null
                    },
                    pagedParams: {
                        number: '',
                        regionId: null,
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },

                createDeliveryRouteDialog: {
                    errorMessage: '',
                    formModel: {
                        number: '',
                        regionId: null,
                        remark: ''
                    },
                    formRules: {
                        number: [
                            { required: true, message: '编号', trigger: 'change' }
                        ],
                        regionId: [
                            { required: true, message: '所属地区', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateDeliveryRouteDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        number: [
                            { required: true, message: '编号', trigger: 'change' }
                        ],
                        regionId: [
                            { required: true, message: '所属地区', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                }
            }
        },

        methods: {
            searchDeliveryRoute() {
                let table = this.deliveryRouteTable

                table.pagedParams.number = table.searchParams.number
                table.pagedParams.regionId = table.searchParams.regionId

                table.pagedParams.page = 1

                deliveryRouteSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchDeliveryRoutePageChange(page) {
                let table = this.deliveryRouteTable

                table.pagedParams.page = page

                deliveryRouteSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchDeliveryRoutePageSizeChange(pageSize) {
                let table = this.deliveryRouteTable

                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize

                deliveryRouteSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createDeliveryRoute() {
                let dialog = this.createDeliveryRouteDialog

                dialog.visible = true
            },
            createDeliveryRouteSave() {
                let dialog = this.createDeliveryRouteDialog

                this.$refs['createDeliveryRouteRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    deliveryRouteCreate(dialog.formModel).then(_ => {
                        this.searchDeliveryRoute()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                        this.$refs['createDeliveryRouteRef'].resetFields()
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            updateDeliveryRoute({ id }) {
                let dialog = this.updateDeliveryRouteDialog

                deliveryRouteSingle(id).then(resp => {
                    dialog.formModel = resp.data
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateDeliveryRouteSave() {
                let dialog = this.updateDeliveryRouteDialog

                this.$refs['updateDeliveryRouteRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    deliveryRouteUpdate(dialog.formModel.id, dialog.formModel).then(_ => {
                        this.searchDeliveryRoute()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            deleteDeliveryRoute({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    deliveryRouteDelete(id).then(_ => {
                        this.searchDeliveryRoute()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            getLookupRegions().then(resp => {
                this.lookupRegions = resp.data
            }).catch(_ => {
                //
            })
            this.searchDeliveryRoute()
        }
    }
</script>

<style lang="scss" scoped>
    .deliveryRoute {
    }
</style>
