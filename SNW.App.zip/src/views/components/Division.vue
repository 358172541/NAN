<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>基础信息</el-breadcrumb-item>
              <el-breadcrumb-item>区域划分</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="division">

          <el-row :gutter="8">
              <el-col :span="3">
                  <el-input placeholder="邮编"
                            v-model="divisionTable.searchParams.postalCode">
                  </el-input>
              </el-col>
              <el-col :span="3">
                  <el-input placeholder="行政区域/州"
                            v-model="divisionTable.searchParams.state">
                  </el-input>
              </el-col>
              <el-col :span="3">
                  <el-input placeholder="行政区域/县"
                            v-model="divisionTable.searchParams.county">
                  </el-input>
              </el-col>
              <el-col :span="3">
                  <el-select class="width-100-percent"
                             clearable
                             placeholder="所属地区"
                             v-model="divisionTable.searchParams.regionId">
                      <el-option v-for="item in lookupRegions"
                                 :key="item.id"
                                 :label="item.number"
                                 :value="item.id">
                      </el-option>
                  </el-select>
              </el-col>
              <el-col :span="12">
                  <el-button icon="el-icon-search"
                             type="primary"
                             @click="searchDivision">查询</el-button>
                  <el-button icon="el-icon-circle-plus-outline"
                             type="success"
                             @click="createDivision">新增</el-button>
              </el-col>
          </el-row>

          <el-table border
                    class="margin-top"
                    :data="divisionTable.pagedResult.items"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" label="邮编" prop="postalCode"></el-table-column>

              <el-table-column align="left" label="行政区域/州" prop="state"></el-table-column>

              <el-table-column align="left" label="行政区域/县" prop="county"></el-table-column>

              <el-table-column align="left" label="所属地区" prop="regionNumber"></el-table-column>

              <el-table-column align="left" label="备注" prop="remark"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-edit"
                                 size="mini"
                                 type="warning"
                                 @click="updateDivision(scope.row)">编辑</el-button>
                      <el-button icon="el-icon-delete"
                                 size="mini"
                                 type="danger"
                                 @click="deleteDivision(scope.row)">删除</el-button>
                  </template>
              </el-table-column>
          </el-table>

          <el-pagination background
                         class="margin-top"
                         layout="prev, pager, next, total"
                         :current-page="divisionTable.pagedParams.page"
                         :page-size="divisionTable.pagedParams.pageSize"
                         :pager-count="5"
                         :total="divisionTable.pagedResult.totalCount"
                         @current-change="searchDivisionPageChange"
                         @size-change="searchDivisionPageSizeChange">
          </el-pagination>

          <!---->

          <el-dialog title="新增"
                     width="448px"
                     :close-on-click-modal="false"
                     :visible.sync="createDivisionDialog.visible">

              <el-form label-width="97px"
                       ref="createDivisionRef"
                       :model="createDivisionDialog.formModel"
                       :rules="createDivisionDialog.formRules">

                  <el-form-item label="邮编"
                                prop="postalCode">
                      <el-input v-model="createDivisionDialog.formModel.postalCode"></el-input>
                  </el-form-item>

                  <el-form-item label="行政区域/州"
                                prop="state">
                      <el-input v-model="createDivisionDialog.formModel.state"></el-input>
                  </el-form-item>

                  <el-form-item label="行政区域/县"
                                prop="county">
                      <el-input v-model="createDivisionDialog.formModel.county"></el-input>
                  </el-form-item>

                  <el-form-item label="所属地区"
                                prop="regionId">
                      <el-select class="width-100-percent"
                                 v-model="createDivisionDialog.formModel.regionId">
                          <el-option v-for="item in lookupRegions"
                                     :key="item.id"
                                     :label="item.number"
                                     :value="item.id">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="createDivisionDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="createDivisionDialog.saveLoading"
                                 @click="createDivisionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="createDivisionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

          <el-dialog title="编辑"
                     width="448px"
                     :close-on-click-modal="false"
                     :visible.sync="updateDivisionDialog.visible">

              <el-form label-width="97px"
                       ref="updateDivisionRef"
                       :model="updateDivisionDialog.formModel"
                       :rules="updateDivisionDialog.formRules">

                  <el-form-item label="邮编"
                                prop="postalCode">
                      <el-input v-model="updateDivisionDialog.formModel.postalCode"></el-input>
                  </el-form-item>

                  <el-form-item label="行政区域/州"
                                prop="state">
                      <el-input v-model="updateDivisionDialog.formModel.state"></el-input>
                  </el-form-item>

                  <el-form-item label="行政区域/县"
                                prop="county">
                      <el-input v-model="updateDivisionDialog.formModel.county"></el-input>
                  </el-form-item>

                  <el-form-item label="所属地区"
                                prop="regionId">
                      <el-select class="width-100-percent"
                                 v-model="updateDivisionDialog.formModel.regionId">
                          <el-option v-for="item in lookupRegions"
                                     :key="item.id"
                                     :label="item.number"
                                     :value="item.id">
                          </el-option>
                      </el-select>
                  </el-form-item>

                  <el-form-item label="备注"
                                prop="remark">
                      <el-input type="textarea"
                                rows="5"
                                v-model="updateDivisionDialog.formModel.remark">
                      </el-input>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="updateDivisionDialog.saveLoading"
                                 @click="updateDivisionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="updateDivisionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>

          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        getLookupRegions
    } from '@/api/services/lookupService'

    import {
        divisionSearch,
        divisionSingle,
        divisionCreate,
        divisionUpdate,
        divisionDelete
    } from '@/api/services/divisionService'

    export default {
        name: 'Division',

        data() {
            return {
                lookupRegions: [],

                divisionTable: {
                    searchParams: {
                        postalCode: '',
                        state: '',
                        county: '',
                        regionId: null
                    },
                    pagedParams: {
                        postalCode: '',
                        state: '',
                        county: '',
                        regionId: null,

                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },

                createDivisionDialog: {
                    errorMessage: '',
                    formModel: {
                        postalCode: '',
                        state: '',
                        county: '',
                        regionId: null,
                        remark: ''
                    },
                    formRules: {
                        postalCode: [
                            { required: true, message: '邮编', trigger: 'change' }
                        ],
                        state: [
                            { required: true, message: '行政区域/州', trigger: 'change' }
                        ],
                        county: [
                            { required: true, message: '行政区域/县', trigger: 'change' }
                        ],
                        regionId: [
                            { required: true, message: '所属地区', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateDivisionDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {
                        postalCode: [
                            { required: true, message: '邮编', trigger: 'change' }
                        ],
                        state: [
                            { required: true, message: '行政区域/州', trigger: 'change' }
                        ],
                        county: [
                            { required: true, message: '行政区域/县', trigger: 'change' }
                        ],
                        regionId: [
                            { required: true, message: '所属地区', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                }
            }
        },
        methods: {
            searchDivision() {
                let table = this.divisionTable

                table.pagedParams.postalCode = table.searchParams.postalCode
                table.pagedParams.state = table.searchParams.state
                table.pagedParams.county = table.searchParams.county
                table.pagedParams.regionId = table.searchParams.regionId

                table.pagedParams.page = 1

                divisionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchDivisionPageChange(page) {
                let table = this.divisionTable

                table.pagedParams.page = page

                divisionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchDivisionPageSizeChange(pageSize) {
                let table = this.divisionTable

                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize

                divisionSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createDivision() {
                let dialog = this.createDivisionDialog

                dialog.visible = true
            },
            createDivisionSave() {
                let dialog = this.createDivisionDialog

                this.$refs['createDivisionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    divisionCreate(dialog.formModel).then(_ => {
                        this.searchDivision()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                        this.$refs['createDivisionRef'].resetFields()
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            updateDivision({ id }) {
                let dialog = this.updateDivisionDialog

                divisionSingle(id).then(resp => {
                    dialog.formModel = resp.data
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateDivisionSave() {
                let dialog = this.updateDivisionDialog

                this.$refs['updateDivisionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    divisionUpdate(
                        dialog.formModel.id,
                        dialog.formModel).then(_ => {
                            this.searchDivision()
                        }).then(_ => {
                            dialog.visible = false
                            dialog.saveLoading = false
                        }).catch(_ => {
                            dialog.saveLoading = false
                            //
                        })
                })
            },
            deleteDivision({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    divisionDelete(id).then(_ => {
                        this.searchDivision()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            getLookupRegions().then(resp => {
                this.lookupRegions = resp.data
            }).catch(_ => {
                //
            })
            this.searchDivision()
        }
    }
</script>

<style lang="scss" scoped>
    .division {
    }
</style>
