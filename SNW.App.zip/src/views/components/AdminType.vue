<template>
    <el-card>
      <div slot="header" class="clearfix">
          <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>基础信息</el-breadcrumb-item>
              <el-breadcrumb-item>管理员类型</el-breadcrumb-item>
          </el-breadcrumb>
      </div>
      <div class="adminType">

          <el-table border
                    :data="adminTypeTable.items"
                    :row-key="'id'">

              <el-table-column align="center" type="index" width="40">
                  <template slot="header" slot-scope="scope">
                      <i class="el-icon-s-operation" />
                  </template>
              </el-table-column>

              <el-table-column align="left" label="名称" prop="display"></el-table-column>

              <el-table-column align="center" label="操作项">
                  <template slot-scope="scope">
                      <el-button icon="el-icon-setting"
                                 size="mini"
                                 type="warning"
                                 @click="assignAdminTypePermission(scope.row)">设置权限</el-button>
                      <el-button icon="el-icon-setting"
                                 size="mini"
                                 type="warning"
                                 @click="assignAdminTypeRegion(scope.row)">设置地区权限</el-button>
                      <el-button icon="el-icon-setting"
                                 size="mini"
                                 type="warning"
                                 @click="assignAdminTypeDeliveryRegion(scope.row)">设置派送地区权限</el-button>
                  </template>
              </el-table-column>

          </el-table>

          <!---->

          <el-dialog title="设置派送地区权限"
                     width="768px"
                     :close-on-click-modal="false"
                     :visible.sync="assignAdminTypeDeliveryRegionDialog.visible">
              <el-form :model="assignAdminTypeDeliveryRegionDialog.formModel"
                       :rules="assignAdminTypeDeliveryRegionDialog.formRules"
                       ref="assignAdminTypeDeliveryRegionRef"
                       label-width="77px">

                  <el-form-item label="管理员类型">
                      {{ assignAdminTypeDeliveryRegionDialog.formModel.adminTypeDisplay }}
                  </el-form-item>

                  <el-form-item label="派送地区" prop="deliveryRegionIds">
                      <el-checkbox-group v-model="assignAdminTypeDeliveryRegionDialog.formModel.deliveryRegionIds">
                          <el-row>
                              <el-col :span="12" v-for="item in lookupDeliveryRegions" :key="item.id">
                                  <el-checkbox :label="item.id">
                                      {{item.number}}
                                  </el-checkbox>
                              </el-col>
                          </el-row>
                      </el-checkbox-group>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="assignAdminTypeDeliveryRegionDialog.saveLoading"
                                 @click="assignAdminTypeDeliveryRegionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="assignAdminTypeDeliveryRegionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>
          </el-dialog>

          <el-dialog title="设置权限" width="768px"
                     :close-on-click-modal="false"
                     :visible.sync="assignAdminTypePermissionDialog.visible">
              <el-form :model="assignAdminTypePermissionDialog.formModel"
                       :rules="assignAdminTypePermissionDialog.formRules"
                       ref="assignAdminTypePermissionRef"
                       label-width="77px">

                  <el-form-item label="管理员类型">
                      {{ assignAdminTypePermissionDialog.formModel.adminTypeDisplay }}
                  </el-form-item>

                  <el-form-item label="权限" prop="permissionIds">
                      <el-checkbox-group v-model="assignAdminTypePermissionDialog.formModel.permissionIds">
                          <el-row v-for="item in structureLevel4ViewPermissions" :key="item.id">
                              <el-col :span="8">
                                  <el-checkbox :label="item.id"
                                               :style="{ marginLeft: (item.level - 1) * 20 + 'px' }">
                                      {{item.display}}
                                  </el-checkbox>
                              </el-col>
                              <el-col :span="14">
                                  <el-checkbox v-if="item.ctrls"
                                               v-for="ctrl in item.ctrls"
                                               :label="ctrl.id"
                                               :key="ctrl.id">
                                      {{ctrl.display}}
                                  </el-checkbox>
                              </el-col>
                          </el-row>
                      </el-checkbox-group>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="assignAdminTypePermissionDialog.saveLoading"
                                 @click="assignAdminTypePermissionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="assignAdminTypePermissionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>
          </el-dialog>

          <el-dialog title="设置地区权限" width="768px"
                     :close-on-click-modal="false"
                     :visible.sync="assignAdminTypeRegionDialog.visible">
              <el-form :model="assignAdminTypeRegionDialog.formModel"
                       :rules="assignAdminTypeRegionDialog.formRules"
                       ref="assignAdminTypeRegionRef"
                       label-width="77px">

                  <el-form-item label="管理员类型">
                      {{ assignAdminTypeRegionDialog.formModel.adminTypeDisplay }}
                  </el-form-item>

                  <el-form-item label="地区" prop="regionIds">
                      <el-checkbox-group v-model="assignAdminTypeRegionDialog.formModel.regionIds">
                          <el-row>
                              <el-col :span="6" v-for="item in lookupRegions" :key="item.id">
                                  <el-checkbox :label="item.id">
                                      {{item.number}}
                                  </el-checkbox>
                              </el-col>
                          </el-row>
                      </el-checkbox-group>
                  </el-form-item>

                  <el-form-item>
                      <el-button icon="el-icon-document-checked"
                                 type="primary"
                                 :loading="assignAdminTypeRegionDialog.saveLoading"
                                 @click="assignAdminTypeRegionSave">保存</el-button>
                      <el-button icon="el-icon-document-remove"
                                 type="danger"
                                 @click="assignAdminTypeRegionDialog.visible=false">取消</el-button>
                  </el-form-item>

              </el-form>
          </el-dialog>

      </div>
    </el-card>
</template>

<script>
    import {
        getLookupDeliveryRegions,
        getLookupPermissions,
        getLookupRegions
    } from '@/api/services/lookupService'

    import {
        adminTypeSearch,
        adminTypeDeliveryRegions,
        adminTypePermissions,
        adminTypeRegions,
        adminTypeDeliveryRegionsAssign,
        adminTypePermissionsAssign,
        adminTypeRegionsAssign
    } from '@/api/services/adminTypeService'

    export default {
        name: 'AdminType',

        computed: {
            structureLevel4ViewPermissions() {
                let structureLevel = (structure, source, value = null, level = 0) => {
                    level++
                    let items = source.filter(x => x.parentId === value && x.type === 1)
                    for (let i in items) {
                        let item = items[i]
                        item.level = level
                        let ctrls = source.filter(x => x.parentId === item.id && x.type === 2)
                        if (ctrls.length > 0)
                            item.ctrls = ctrls
                        structure.push(item)
                        structureLevel(structure, source, item.id, level)
                    }
                }
                let structure = []
                structureLevel(structure, JSON.parse(JSON.stringify(this.lookupPermissions)))
                return structure
            }
        },

        data() {
            return {
                lookupDeliveryRegions: [],
                lookupPermissions: [],
                lookupRegions: [],

                adminTypeTable: {
                    items: []
                },

                assignAdminTypeDeliveryRegionDialog: {
                    errorMessage: '',
                    formModel: {
                        adminTypeId: 0,
                        adminTypeDisplay: '',
                        deliveryRegionIds: []
                    },
                    formRules: {},
                    saveLoading: false,
                    visible: false
                },
                assignAdminTypePermissionDialog: {
                    errorMessage: '',
                    formModel: {
                        adminTypeId: 0,
                        adminTypeDisplay: '',
                        permissionIds: []
                    },
                    formRules: {},
                    saveLoading: false,
                    visible: false
                },
                assignAdminTypeRegionDialog: {
                    errorMessage: '',
                    formModel: {
                        adminTypeId: 0,
                        adminTypeDisplay: '',
                        regionIds: []
                    },
                    formRules: {},
                    saveLoading: false,
                    visible: false
                }
            }
        },

        methods: {
            searchAdminType() {
                let table = this.adminTypeTable

                adminTypeSearch().then(resp => {
                    table.items = resp.data
                }).catch(_ => {
                    //
                })
            },
            assignAdminTypeDeliveryRegion({ id, display }) {
                let dialog = this.assignAdminTypeDeliveryRegionDialog

                dialog.formModel.adminTypeId = id
                dialog.formModel.adminTypeDisplay = display

                Promise.all([
                    getLookupDeliveryRegions(),
                    adminTypeDeliveryRegions(id)
                ]).then(resp => {
                    this.lookupDeliveryRegions = resp[0].data
                    dialog.formModel.deliveryRegionIds = resp[1].data
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            assignAdminTypeDeliveryRegionSave() {
                let dialog = this.assignAdminTypeDeliveryRegionDialog

                this.$refs['assignAdminTypeDeliveryRegionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    adminTypeDeliveryRegionsAssign(dialog.formModel.adminTypeId, dialog.formModel.deliveryRegionIds).then(_ => {
                        this.searchAdminType()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            assignAdminTypePermission({ id, display }) {
                let dialog = this.assignAdminTypePermissionDialog

                dialog.formModel.adminTypeId = id
                dialog.formModel.adminTypeDisplay = display

                Promise.all([
                    getLookupPermissions(),
                    adminTypePermissions(id)
                ]).then(resp => {
                    this.lookupPermissions = resp[0].data
                    dialog.formModel.permissionIds = resp[1].data
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            assignAdminTypePermissionSave() {
                let dialog = this.assignAdminTypePermissionDialog

                this.$refs['assignAdminTypePermissionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    adminTypePermissionsAssign(
                        dialog.formModel.adminTypeId,
                        dialog.formModel.permissionIds).then(_ => {
                            this.searchAdminType()
                        }).then(_ => {
                            dialog.visible = false
                            dialog.saveLoading = false
                        }).catch(_ => {
                            dialog.saveLoading = false
                            //
                        })
                })
            },
            assignAdminTypeRegion({ id, display }) {
                let dialog = this.assignAdminTypeRegionDialog

                dialog.formModel.adminTypeId = id
                dialog.formModel.adminTypeDisplay = display

                Promise.all([
                    getLookupRegions(),
                    adminTypeRegions(id)
                ]).then(resp => {
                    this.lookupRegions = resp[0].data
                    dialog.formModel.regionIds = resp[1].data
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            assignAdminTypeRegionSave() {
                let dialog = this.assignAdminTypeRegionDialog

                this.$refs['assignAdminTypeRegionRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    adminTypeRegionsAssign(
                        dialog.formModel.adminTypeId,
                        dialog.formModel.regionIds).then(_ => {
                            this.searchAdminType()
                        }).then(_ => {
                            dialog.visible = false
                            dialog.saveLoading = false
                        }).catch(_ => {
                            dialog.saveLoading = false
                            //
                        })
                })
            }
        },

        created() {
            this.searchAdminType()
        }
    }
</script>

<style lang="scss" scoped>
    .adminType {
    }
</style>
