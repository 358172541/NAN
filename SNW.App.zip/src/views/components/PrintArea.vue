<template>
  <div id="myPrintArea" style="width: 210mm; height:297mm; ">
  	<div id="head">
  		<div style="float:left; font-size:20px; width:600px; height:101px;">
  			<div class="head1">
  				<span v-if="value.expressCompany != null">
  					<input type="text" name="" :value="value.expressCompany.name" style="border-style:none;height: 28px;  width: 600px; line-height: 30px; font-size: 20px; ">
  				</span>
  			</div>
  			<div class="head2">
  				<span v-if="value.expressCompany != null">
  					<textarea rows="3" style=" text-align: left;  width: 600px;border-style:none;height: 56px;  font-size: 13px; resize:none;overflow:hidden;">{{value.expressCompany.detailAddress}}</textarea>
  				</span>
  			</div>
  		</div>
  	</div>
  	<hr style="height:1px;border:none;border-top:3px ridge black;  width:100%;">
  	<div id="Contents">
  		<div class="huodan" style="text-align:center;">
  			<span style=" font-size:28px; ">DELIVERY ORDER</span>
  		</div>
  		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table1">
  			<tbody>
  				<tr height="30">
  					<td width="15%">
  						<span style="margin-left: 2px;">MARKING</span>
  					</td>
  					<td width="43%">
  						<span v-if="value.package != null && value.package.mark != null" style="font-size: 24px;">{{value.package.mark}}</span>
  					</td>
  					<td width="20%">
  						<span>D.O. No</span>
  					</td>
  					<td width="20%" v-if="value.package != null">
  						<span>{{value.ship != null ? value.ship.shipNo : value.package.id}}</span>
  					</td>
  				</tr>
  				<tr height="30">
  					<td width="15%">
  						<span style="margin-left: 2px;">CUSTOMER</span>
  					</td>
  					<td width="43%">
  						<span v-if="value.package != null">{{value.package.itemName}}</span>
  					</td>
  					<td width="20%">
  						<span>DATE</span>
  					</td>
  					<td width="20%">
  						<span v-if="value.ship != null">{{value.ship.receiveTime}}</span>
  					</td>
  				</tr>
  				<tr height="90">
  					<td width="15%" valign="top">
  						<span style="margin-left: 2px;">ADDRESS</span>
  					</td>
  					<td width="43%" valign="top" v-if="value.expressCompany != null">
  						<span style="width:190px; font-size:16px;word-break: break-word; margin-right:5px;">{{value.expressCompany.detailAddress}}</span>
  					</td>
  					<td width="41%" valign="top" colspan="3">
  						<table width="100%" border="0" cellspacing="0" cellpadding="0">
  							<tbody>
  								<tr height="30">
  									<td colspan="3">
  										<span>Shipping Info</span>
  									</td>
  								</tr>
  								<tr height="30">
  									<td width="47%" valign="top">
  										<span>Ref. No.</span>
  									</td>
  									<td width="53%" align="left" valign="middle">
  										<span style="font-size: 24px;">{{value.ship == null ? "" : value.ship.shipNo}}</span>
  									</td>
  								</tr>
  							</tbody>
  						</table>
  					</td>
  				</tr>
  				<tr height="30">
  					<td width="15%">
  						<span style="margin-left: 2px;">ATTN </span>
  					</td>
  					<td width="84%" colspan="4">
  						<span v-if="value.package != null">{{value.package.mark}}</span>
  					</td>
  				</tr>
  				<tr height="30">
  					<td width="15%">
  						<span style="margin-left: 2px;">TEL </span>
  					</td>
  					<td width="43%">
  						<span v-if="value.package != null">
  							{{value.package.recipentPhoneNo}}<br>{{value.package.recipentTelephone}}
  						</span>
  					</td>
  					<td colspan="2">
  						<font style="font-size:12px;">(资料补充时间：补充人:未补充)</font>
  					</td>
  				</tr>
  				<tr style=" height:5px;"></tr>
  			</tbody>
  		</table>
  		<table width="100%" border="0" cellspacing="0" cellpadding="0">
  			<tbody>
  				<tr style="height:1px;">
  					<td colspan="4">
  						<hr style=" height:1px;border:none;border-top:1px ridge black;">
  					</td>
  				</tr>
  				<tr style="height:18px; font-size:14px;">
  					<td width="20%">NO</td>
  					<td width="10%" align="center">
  						<span>OrderNO</span>
  					</td>
  					<td width="45%" align="center">
  						<span>CUSTOMER REMARK</span>
  					</td>
  					<td width="20%" colspan="2">
  						<span>QUANTITY</span>
  					</td>
  				</tr>
  				<tr style="height:1px;">
  					<td colspan="4">
  						<hr style=" height:1px;border:none;border-top:1px ridge black;">
  					</td>
  				</tr>
  				<tr style="height:10mm;">
  					<td width="10%" v-if="value.package != null">
  						<span style="font-size:30px; margin-left:40px; font-family: Arial;font-weight: bolder;">{{value.package.expressNumber}}</span>
  					</td>
  					<td width="50%" align="center">
  						<span style="white-space:normal;">
  							<div  v-if="value.package != null" style="width:100px;word-wrap: break-word;">{{value.package.mark}}</div>
  						</span>
  					</td>
  					<td width="20%" colspan="2">
  						<span>{{value.package.itemCount}}</span>&nbsp;&nbsp;&nbsp;<span>CTNS</span>
  					</td>
  				</tr>
  				<tr style="height:10mm;">
  					<td width="20%"> </td>
  					<td width="10%"></td>
  					<td width="50%" align="center"></td>
  					<td width="20%" colspan="2">
  						<span></span>
  					</td>
  				</tr>
  				<tr style="height:10mm;">
  					<td width="20%"> </td>
  					<td width="10%"></td>
  					<td width="50%" align="center"></td>
  					<td width="20%" colspan="2">
  						<span></span>
  					</td>
  				</tr>
  				<tr style="height:10mm;">
  					<td width="20%"> </td>
  					<td width="10%"></td>
  					<td width="50%" align="center"></td>
  					<td width="20%" colspan="2">
  						<span></span>
  					</td>
  				</tr>
  				<tr style="height:10mm;">
  					<td width="20%"> </td>
  					<td width="10%"></td>
  					<td width="50%" align="center"></td>
  					<td width="20%" colspan="2">
  						<span></span>
  					</td>
  				</tr>
  			</tbody>
  		</table>
  		<table width="100%" border="0" cellspacing="0" cellpadding="0">
  			<tbody>
  				<tr style="height:1px;">
  					<td colspan="5">
  						<hr style=" height:1px;border:none;border-top:1px ridge black;">
  					</td>
  				</tr>
  				<tr height="10">
  					<td width="80%" align="left" colspan="3" style="border-right:1px solid #000; color:Red;">派送前一天请和客人核对地址，和具体时间，得到客人回复再提交和派送，谢谢
  						(Please check the address and specific time with the customer the day before the delivery, and submit and deliver after receiving the customer's reply. Thank you)</td>
  					<td width="10%" align="right">
  						<span style="font-size:18px;">TOTAL :</span>
  					</td>
  					<td width="10%" align="left" style="font-size:18px;">&nbsp;{{value.package.itemCount}}&nbsp;&nbsp;&nbsp;<span style="font-size:18px;">CTNS</span>
  					</td>
  				</tr>
  				<tr style="height:1px;">
  					<td colspan="5">
  						<hr style=" height:1px;border:none;border-top:1px ridge black;">
  					</td>
  				</tr>
  			</tbody>
  		</table>
  		<div style=" text-align:center;">
  			<span style="font-size: 18px;margin-left: 2px;">TELEFON 1 HARI &amp; TELEFON 2 JAM SEBELUM HANTAR !</span>
  		</div>
  		<div>
  			<span style="font-size: 12px; font-weight: bold;margin-left: 2px;">温馨提示：</span>
  		</div>
  		<div>
  			<span style="font-size: 12px; font-weight: bold;margin-left: 2px;">货物如有少件,破坏,箱规不符等,必须在送货单上注明罗里车牌,货员I/C及送货员签名确认,签收后一律与本公司无关,谢谢!</span>
  		</div>
  		<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border-top:1px solid #000;margin-top:20px;">
  			<tbody>
  				<tr height="30">
  					<td width="50%">
  						<span style="margin-left: 2px;">Received the above goods in correct quantity</span>
  					</td>
  					<td width="10%">
  						<span></span>
  					</td>
  					<td width="40%">
  						<span>{{value.expressCompany != null ? value.expressCompany.name : ''}}</span>
  					</td>
  				</tr>
  				<tr height="30">
  					<td width="50%">
  						<span style="margin-left: 2px;">and good condition.</span>
  					</td>
  					<td width="10%">
  						<span></span>
  					</td>
  					<td width="40%">
  						<span></span>
  					</td>
  				</tr>
  				<tr height="120">
  					<td width="50%" style=" border-bottom:1px solid #000">
  						<span style="margin-left: 2px;"></span>
  					</td>
  					<td width="10%">
  						<span></span>
  					</td>
  					<td width="40%" style=" border-bottom:1px solid #000; text-align:left;">
  						<span>
  							<img v-if="value.expressCompany != null" :src="value.expressCompany.logo" style="width:120px; height:120px; "/>
                <img v-else-if="value.expressCompany == null" src="" style="width:120px; height:120px; "/>
  						</span>
  						<div style="float:right; font-size:20px; width:120px; margin-right:40px; ">
  							<div style=" font-size:12px; text-align:center; margin-bottom:5px;">请帮忙扫描签收,谢谢!</div>
                <img id="qrcode" :src="value.qrcodeUrlBase64" style="margin-left:10px;" width="100" height="100"/>
  							<div style=" font-size:12px; text-align:center;">扫一扫?签收完成</div>
  						</div>
  					</td>
  				</tr>
  				<tr height="30">
  					<td width="50%">
  						<span style="margin-left: 2px;">Customer's chop or name, signature &amp; date</span>
  					</td>
  					<td width="10%">
  						<span></span>
  					</td>
  					<td width="40%" align="center">
  						<span>Authorised Signatory</span>
  					</td>
  				</tr>
  			</tbody>
  		</table>
  	</div>
  </div>
</template>
<script>

export default{
  name:'PrintArea',
  props:{
    value:{
      default:{}
    }
  },
  methods:{

  }
}
</script>
