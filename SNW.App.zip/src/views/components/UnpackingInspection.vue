<template>
    <div class="unpackingInspection">
        <el-row class="wrap"
                justify="center"
                type="flex">
            <el-col :span="24">

                <el-form ref="formRef"
                         :model="formModel"
                         :rules="formRules">

                    <el-form-item>
                        <el-row justify="space-between"
                                type="flex">
                            <div>拆柜检测</div>
                        </el-row>
                    </el-form-item>

                    <el-form-item prop="inputs">

                        <el-input type="textarea"
                                  v-model="formModel.inputs"
                                  :rows="8">
                        </el-input>

                    </el-form-item>

                    <el-form-item>
                        <el-button size="medium"
                                   type="primary"
                                   :loading="loading"
                                   @click="submit">提交</el-button>
                        <el-button size="medium"
                                   type="info"
                                   @click="reset">重置</el-button>
                        <div class="el-form-item__error">
                            {{errorMessage}}
                        </div>
                    </el-form-item>

                </el-form>

            </el-col>
        </el-row>
    </div>
</template>

<script>
    export default {
        name: 'UnpackingInspection',

        data() {
            return {
                loading: false,
                errorMessage: '',
                formModel: {
                    inputs: ''
                },
                formRules: {
                    inputs: [
                        { required: true, message: '请输入运单号', trigger: 'change' }
                    ]
                }
            }
        },

        methods: {
            submit() {
                this.$refs['formRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    // this.loading = true
                    window.alert(this.formModel.inputs.trimEnd('\n').split('\n'))
                })
            },
            reset() {
                this.$refs['formRef'].resetFields()
            }
        }
    }
</script>

<style lang="scss" scoped>
    .unpackingInspection {
        height: 100vh;
        margin: auto;
        max-width: 335px;
        padding: 0px 20px;

        .wrap {
            position: relative;
            top: 50%;
            transform: translateY(-50%);
        }
    }
</style>
