<template>
    <div class="route">

        <el-row :gutter="8">
            <el-col :span="3">
                <el-input placeholder="编号"
                          v-model="routeTable.searchParams.number">
                </el-input>
            </el-col>
            <el-col :span="3">
                <el-input placeholder="运单号/前缀"
                          v-model="routeTable.searchParams.expressNumberPrefix">
                </el-input>
            </el-col>
            <el-col :span="3">
                <el-input placeholder="筛选"
                          v-model="routeTable.searchParams.screen">
                </el-input>
            </el-col>
            <el-col :span="15">
                <el-button icon="el-icon-search"
                           type="primary"
                           @click="searchRoute">查询</el-button>
                <el-button icon="el-icon-circle-plus-outline"
                           type="success"
                           @click="createRoute">新增</el-button>
            </el-col>
        </el-row>

        <el-table border
                  class="margin-top"
                  :data="routeTable.pagedResult.items"
                  :row-key="'id'">

            <el-table-column align="center" type="index" width="40">
                <template slot="header">
                    <i class="el-icon-s-operation" />
                </template>
            </el-table-column>

            <el-table-column align="left" label="编号" prop="number"></el-table-column>

            <el-table-column align="left" label="运单号/前缀" prop="expressNumberPrefix"></el-table-column>

            <el-table-column align="left" label="筛选" prop="screen"></el-table-column>

            <el-table-column align="left" label="派送公司/名称" prop="expressCompanyName"></el-table-column>

            <el-table-column align="left" label="派送公司/电话号码" prop="expressCompanyPhoneNumber"></el-table-column>

            <el-table-column align="left" label="备注" prop="remark"></el-table-column>

            <el-table-column align="center" label="操作项">
                <template slot-scope="scope">
                    <el-button icon="el-icon-edit-outline"
                               size="mini"
                               type="warning"
                               @click="updateRoute(scope.row)">编辑</el-button>
                    <el-button icon="el-icon-delete"
                               size="mini"
                               type="danger"
                               @click="deleteRoute(scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>

        <el-pagination background
                       class="margin-top"
                       layout="prev, pager, next, total"
                       :current-page="routeTable.pagedParams.page"
                       :page-size="routeTable.pagedParams.pageSize"
                       :pager-count="5"
                       :total="routeTable.pagedResult.totalCount"
                       @current-change="searchRoutePageChange"
                       @size-change="searchRoutePageSizeChange">
        </el-pagination>

        <!---->

        <el-dialog title="新增"
                   width="448px"
                   :close-on-click-modal="false"
                   :visible.sync="createRouteDialog.visible">

            <el-form :model="createRouteDialog.formModel"
                     :rules="createRouteDialog.formRules"
                     ref="createRouteRef"
                     label-width="124px">

                <el-form-item label="编号"
                              prop="number">
                    <el-input v-model="createRouteDialog.formModel.number"></el-input>
                </el-form-item>

                <el-form-item label="运单号/前缀"
                              prop="expressNumberPrefix">
                    <el-input v-model="createRouteDialog.formModel.expressNumberPrefix">
                    </el-input>
                </el-form-item>

                <el-form-item label="筛选"
                              prop="screen">
                    <el-input v-model="createRouteDialog.formModel.screen">
                    </el-input>
                </el-form-item>

                <el-form-item label="派送公司/名称"
                              prop="expressCompanyName">
                    <el-input v-model="createRouteDialog.formModel.expressCompanyName">
                    </el-input>
                </el-form-item>

                <el-form-item label="派送公司/电话号码"
                              prop="expressCompanyPhoneNumber">
                    <el-input v-model="createRouteDialog.formModel.expressCompanyPhoneNumber">
                    </el-input>
                </el-form-item>

                <el-form-item label="派送公司/详细地址"
                              prop="expressCompanyDetailAddress">
                    <el-input type="textarea"
                              rows="5"
                              v-model="createRouteDialog.formModel.expressCompanyDetailAddress">
                    </el-input>
                </el-form-item>

                <el-form-item label="备注"
                              prop="remark">
                    <el-input type="textarea"
                              rows="5"
                              v-model="createRouteDialog.formModel.remark">
                    </el-input>
                </el-form-item>

                <el-form-item>
                    <el-button icon="el-icon-document-checked"
                               type="primary"
                               :loading="createRouteDialog.saveLoading"
                               @click="createRouteSave">保存</el-button>
                    <el-button icon="el-icon-document-remove"
                               type="danger"
                               @click="createRouteDialog.visible=false">取消</el-button>
                </el-form-item>

            </el-form>

        </el-dialog>

        <el-dialog title="编辑"
                   width="448px"
                   :close-on-click-modal="false"
                   :visible.sync="updateRouteDialog.visible">

            <el-form :model="updateRouteDialog.formModel"
                     :rules="updateRouteDialog.formRules"
                     ref="updateRouteRef"
                     label-width="124px">

                <el-form-item label="编号"
                              prop="number"
                              required>
                    {{updateRouteDialog.formModel.number}}
                </el-form-item>

                <el-form-item label="运单号/前缀"
                              prop="expressNumberPrefix"
                              required>
                    {{updateRouteDialog.formModel.expressNumberPrefix}}
                </el-form-item>

                <el-form-item label="筛选"
                              prop="screen">
                    <el-input v-model="updateRouteDialog.formModel.screen">
                    </el-input>
                </el-form-item>

                <el-form-item label="派送公司/名称"
                              prop="expressCompanyName">
                    <el-input v-model="updateRouteDialog.formModel.expressCompanyName">
                    </el-input>
                </el-form-item>

                <el-form-item label="派送公司/电话号码"
                              prop="expressCompanyPhoneNumber">
                    <el-input v-model="updateRouteDialog.formModel.expressCompanyPhoneNumber">
                    </el-input>
                </el-form-item>

                <el-form-item label="派送公司/详细地址"
                              prop="expressCompanyDetailAddress">
                    <el-input type="textarea"
                              rows="5"
                              v-model="updateRouteDialog.formModel.expressCompanyDetailAddress">
                    </el-input>
                </el-form-item>

                <el-form-item label="备注"
                              prop="remark">
                    <el-input type="textarea"
                              rows="5"
                              v-model="updateRouteDialog.formModel.remark">
                    </el-input>
                </el-form-item>

                <el-form-item>
                    <el-button icon="el-icon-document-checked"
                               type="primary"
                               :loading="updateRouteDialog.saveLoading"
                               @click="updateRouteSave">保存</el-button>
                    <el-button icon="el-icon-document-remove"
                               type="danger"
                               @click="updateRouteDialog.visible=false">取消</el-button>
                </el-form-item>

            </el-form>

        </el-dialog>

    </div>
</template>

<script>
    import {
        routeSearch,
        routeSingle,
        routeCreate,
        routeUpdate,
        routeDelete
    } from '@/api/services/routeService'

    export default {
        name: 'Route',

        data() {
            return {
                routeTable: {
                    searchParams: {
                        number: '',
                        expressNumberPrefix: '',
                        screen: ''
                    },
                    pagedParams: {
                        number: '',
                        expressNumberPrefix: '',
                        screen: '',
                        page: 1,
                        pageSize: 10
                    },
                    pagedResult: {
                        items: [],
                        totalCount: 0
                    }
                },

                createRouteDialog: {
                    errorMessage: '',
                    formModel: {
                        number: '',
                        expressNumberPrefix: '',
                        screen: '',
                        expressCompanyName: '',
                        expressCompanyPhoneNumber: '',
                        expressCompanyDetailAddress: '',
                        //expressCompanyLogo: '',
                        remark: ''
                    },
                    formRules: {
                        number: [
                            { required: true, message: '编号', trigger: 'change' }
                        ],
                        expressNumberPrefix: [
                            { required: true, message: '运单号/前缀', trigger: 'change' }
                        ]
                    },
                    saveLoading: false,
                    visible: false
                },
                updateRouteDialog: {
                    errorMessage: '',
                    formModel: {},
                    formRules: {},
                    saveLoading: false,
                    visible: false
                }
            }
        },

        methods: {
            searchRoute() {
                let table = this.routeTable

                table.pagedParams.number = table.searchParams.number
                table.pagedParams.expressNumberPrefix = table.searchParams.expressNumberPrefix
                table.pagedParams.screen = table.searchParams.screen

                table.pagedParams.page = 1

                routeSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchRoutePageChange(page) {
                let table = this.routeTable

                table.pagedParams.page = page

                routeSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            searchRoutePageSizeChange(pageSize) {
                let table = this.routeTable

                table.pagedParams.page = 1
                table.pagedParams.pageSize = pageSize

                routeSearch(table.pagedParams).then(resp => {
                    table.pagedResult = resp.data
                }).catch(_ => {
                    //
                })
            },
            createRoute() {
                let dialog = this.createRouteDialog

                dialog.visible = true
            },
            createRouteSave() {
                let dialog = this.createRouteDialog

                this.$refs['createRouteRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }
                    dialog.saveLoading = true
                    routeCreate(dialog.formModel).then(_ => {
                        this.searchRoute()
                    }).then(_ => {
                        dialog.visible = false
                        dialog.saveLoading = false
                        this.$refs['createRouteRef'].resetFields()
                    }).catch(_ => {
                        dialog.saveLoading = false
                        //
                    })
                })
            },
            updateRoute({ id, number, expressNumberPrefix }) {
                let dialog = this.updateRouteDialog

                routeSingle(id).then(resp => {
                    dialog.formModel = resp.data
                    dialog.formModel.number = number
                    dialog.formModel.expressNumberPrefix = expressNumberPrefix
                }).then(_ => {
                    dialog.visible = true
                }).catch(_ => {
                    //
                })
            },
            updateRouteSave() {
                this.$refs['updateRouteRef'].validate((valid) => {
                    if (valid === false) {
                        return false
                    }

                    let dialog = this.updateRouteDialog

                    dialog.saveLoading = true

                    routeUpdate(
                        dialog.formModel.id,
                        dialog.formModel).then(_ => {
                            this.searchRoute()
                        }).then(_ => {
                            dialog.visible = false
                            dialog.saveLoading = false
                        }).catch(_ => {
                            dialog.saveLoading = false
                            //
                        })
                })
            },
            deleteRoute({ id }) {
                this.$confirm('此操作将永久删除该数据, 是否继续', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    routeDelete(id).then(_ => {
                        this.searchRoute()
                    }).catch(_ => {
                        //
                    })
                }).catch(_ => {
                    //
                })
            }
        },

        created() {
            this.searchRoute()
        }
    }
</script>

<style lang="scss" scoped>
    .route {
    }
</style>
