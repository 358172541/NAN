<template>
  <div id="myPrintArea1" style="width: 210mm; height:297mm; ">
  	<div id="head">
  		<div style="float:left; font-size:20px; width:100px; ">
  		</div>
  		<div style="float:right; font-size:20px; width:600px; height:101px;">
  			<div class="head1">
  				<span style="margin-left:100px;" v-if="value.expressCompany != null">
  					<input type="text" name="" :value="value.expressCompany.name" style="border-style:none;height: 28px;  width: 600px; line-height: 30px; font-size: 20px; ">
  				</span>
  			</div>
  			<div class="head2">
  				<span style="margin-left:0px;" v-if="value.expressCompany != null">
  					<textarea rows="3" style=" text-align: left;  width: 600px;border-style:none;height: 56px;  font-size: 13px; resize:none;overflow:hidden;">
              {{value.expressCompany.detailAddress}}
            </textarea>
  				</span>
  			</div>
  		</div>
  	</div>
  	<hr style="height:1px;border:none;border-top:3px ridge black;  width:100%;">
  	<div id="Contents">
  		<div class="huodan" style="text-align:center;">
  			<span style=" font-size:28px; ">DELIVERY ORDER</span>
  		</div>
  		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table1">
  			<tbody>
  				<tr height="30">
  					<td width="15%">
  						<span style="margin-left: 2px;">MARKING</span>
  					</td>
  					<td width="43%">
  						<span style="font-size: 24px;" v-if="value.package != null">{{value.package.mark}}</span>
  					</td>
  					<td width="20%">
  						<span>D.O. No</span>
  					</td>
  					<td width="20%">
  						<span></span>
  					</td>
  				</tr>
  				<tr height="30">
  					<td width="15%">
  						<span style="margin-left: 2px;">CUSTOMER</span>
  					</td>
  					<td width="43%">
  						<span v-if="value.package != null">{{value.package.expressNumber}}</span>
  					</td>
  					<td width="20%">
  						<span>DATE</span>
  					</td>
  					<td width="20%">
  						<span v-if="value.package != null">{{value.package.updateTimeDisplay}}</span>
  					</td>
  				</tr>
  				<tr height="90">
  					<td width="15%" valign="top">
  						<span style="margin-left: 2px;">ADDRESS</span>
  					</td>
  					<td width="43%" valign="top">
  						<span style="width:200px; font-size:16px;" v-if="value.expressCompany">{{value.expressCompany.detailAddress}}</span>
  					</td>
  					<td width="41%" valign="top" colspan="3">
  						<table width="100%" border="0" cellspacing="0" cellpadding="0">
  							<tbody>
  								<tr height="30">
  									<td colspan="3">
  										<span>Shipping Info</span>
  									</td>
  								</tr>
  								<tr height="30">
  									<td width="47%" valign="top">
  										<span>Ref. No.</span>
  									</td>
  									<td width="53%" align="left" valign="middle">
  										<span style="font-size: 24px;" v-if="value.ship != null">{{value.ship.shipNo}}</span>
  									</td>
  								</tr>
  							</tbody>
  						</table>
  					</td>
  				</tr>
  				<tr height="30">
  					<td width="15%">
  						<span style="margin-left: 2px;">ATTN</span>
  					</td>
  					<td width="84%" colspan="4">
  						<span>{{value.package.expressNumber}}</span>
  					</td>
  				</tr>
  				<tr height="30">
  					<td width="15%">
  						<span style="margin-left: 2px;">TEL </span>
  					</td>
  					<td width="84%" colspan="4">
  						<span>
  							{{value.package.recipentTelephone}}<br>
  						</span>
  					</td>
  				</tr>
  				<tr style=" height:5px;"></tr>
  			</tbody>
  		</table>
  		<table width="100%" border="0" cellspacing="0" cellpadding="0">
  			<tbody>
  				<tr style="height:1px;">
  					<td colspan="4">
  						<hr style=" height:1px;border:none;border-top:1px ridge black;">
  					</td>
  				</tr>
  				<tr style="height:18px; font-size:14px;">
  					<td width="20%">NO</td>
  					<td width="10%" align="center">
  						<span>OrderNO</span>
  					</td>
  					<td width="35%" align="center"></td>
  					<td width="30%" colspan="2">
  						<span>QUANTITY</span>
  					</td>
  				</tr>
  				<tr style="height:1px;">
  					<td colspan="4">
  						<hr style=" height:1px;border:none;border-top:1px ridge black;">
  					</td>
  				</tr>
  			</tbody>
  		</table>
  		<table width="100%" border="0" cellspacing="0" cellpadding="0">
  			<tbody>
  				<tr style="height:1px;">
  					<td colspan="5">
  						<hr style=" height:1px;border:none;border-top:1px ridge black;">
  					</td>
  				</tr>
  				<tr height="10">
  					<td width="90%" align="right" colspan="4">
  						<span>TOTAL :</span>
  					</td>
  					<td width="10%" align="left">&nbsp;{{value.package.itemCount}}&nbsp;&nbsp;&nbsp;<span>CTNS</span>
  					</td>
  				</tr>
  				<tr style="height:1px;">
  					<td colspan="5">
  						<hr style=" height:1px;border:none;border-top:1px ridge black;">
  					</td>
  				</tr>
  			</tbody>
  		</table>
  		<div style=" text-align:center;">
  			<span style="font-size: 18px;margin-left: 2px;">TELEFON 1 HARI &amp; TELEFON 2 JAM SEBELUM HANTAR !</span>
  		</div>
  		<div style="margin-top:30px; text-align:right;">
  			<span style="font-size: 22px; font-weight: bold;margin-left: 2px; ">代收马币：{{value.totalCollection}}</span>
  		</div>
  	</div>
  </div>
</template>
<script>
export default{
  name:'BillPrintArea',
  props:{
    value:{
      default:{}
    }
  },
}
</script>
