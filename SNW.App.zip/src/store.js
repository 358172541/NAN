import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        DEFAULT_ACTIVE: localStorage.getItem('DEFAULT_ACTIVE'),
        TOKEN: localStorage.getItem('TOKEN'),
        TOKEN_EXPIRE_TIME: localStorage.getItem('TOKEN_EXPIRE_TIME'),
        TOKEN_REFRESH_EXPIRE_TIME: localStorage.getItem('TOKEN_REFRESH_EXPIRE_TIME')
    },
    mutations: {
        DEFAULT_ACTIVE(state, value) {
            state.DEFAULT_ACTIVE = value
            localStorage.setItem('DEFAULT_ACTIVE', state.DEFAULT_ACTIVE)
        },
        TOKEN(state, value) {
            state.TOKEN = value
            localStorage.setItem('TOKEN', state.TOKEN)
        },
        TOKEN_EXPIRE_TIME(state, value) {
            state.TOKEN_EXPIRE_TIME = value
            localStorage.setItem('TOKEN_EXPIRE_TIME', state.TOKEN_EXPIRE_TIME)
        },
        TOKEN_REFRESH_EXPIRE_TIME(state, value) {
            state.TOKEN_REFRESH_EXPIRE_TIME = value
            localStorage.setItem('TOKEN_REFRESH_EXPIRE_TIME', state.TOKEN_REFRESH_EXPIRE_TIME)
        }
    }
})
