// 播放声音文件
export function playAudio(file){
  let signSucc = new Audio()
  console.log(`path: ../../static/${file}`)
  signSucc.src = require(`../../static/${file}`)
  signSucc.play()
}
