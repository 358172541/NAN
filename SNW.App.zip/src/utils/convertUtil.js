export function jsonToQueryParams(json){
  let str = "";
  let query = "";
  for(let i in json){//i是对象的键值
    console.log(`${i}:${json[i]}`)
    str += i + "=" + json[i] + "&"//json[i][j]是属性值
  }
  query = str.substring(0,str.length-1);
  return query;
}
