import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

import store from '@/store'

import Login from '@/views/Login'
import Main from '@/views/Main'

import Admin from '@/views/components/Admin'
import AdminType from '@/views/components/AdminType'
import Advert from '@/views/components/Advert'
import Content from '@/views/components/Content'
import ContentCategory from '@/views/components/ContentCategory'
import Dashboard from '@/views/components/Dashboard'
import DeliveryRegion from '@/views/components/DeliveryRegion'
import DeliveryRoute from '@/views/components/DeliveryRoute'

import Division from '@/views/components/Division'

import FriendlyLink from '@/views/components/FriendlyLink'
import Home from '@/views/components/Home'
import Member from '@/views/components/Member'
import MemberType from '@/views/components/MemberType'
import Param from '@/views/components/Param'
import Permission from '@/views/components/Permission'
import Region from '@/views/components/Region'
import Route from '@/views/components/Route'

import DrawerExample from '@/views/examples/DrawerExample'
import ExportExample from '@/views/examples/ExportExample'
import ImportExample from '@/views/examples/ImportExample'
import PrintExample from '@/views/examples/PrintExample'
import PrintLabelExample from '@/views/examples/PrintLabelExample'
import QuillEditorExample from '@/views/examples/QuillEditorExample'
import SundryExample from '@/views/examples/SundryExample'

import PackageDelivering from '@/views/components/PackageDelivering'
import PackageHistory from '@/views/components/PackageHistory'

import Shift from '@/views/components/Shift'

import Delivery from '@/views/components/Delivery'
import DeliveringInspection from '@/views/components/DeliveringInspection'
import LoadingInspection from '@/views/components/LoadingInspection'
import UnpackingInspection from '@/views/components/UnpackingInspection'

import OpenOrder from '@/views/merchandise/OpenOrder'
import OpenOrderList from '@/views/merchandise/OpenOrderList'
import SmallBagStoring from '@/views/merchandise/SmallBagStoring'
import BigBagStoring from '@/views/merchandise/BigBagStoring'
import PackageSignList from '@/views/merchandise/PackageSignList'
import PackageSign from '@/views/merchandise/PackageSign'
import PackageSignListItemOpenOrder from '@/views/merchandise/PackageSignListItemOpenOrder'

const router = new VueRouter({
    routes: [
        { path: '/', name: '', redirect: '/login' },
        { path: '/login', name: 'login', component: Login },
        {
            path: '/',
            name: 'main',
            component: Main,
            children: [
                { path: 'admin', name: 'admin', component: Admin },
                { path: 'adminType', name: 'adminType', component: AdminType },
                { path: 'advert', name: 'advert', component: Advert },
                { path: 'content', name: 'content', component: Content },
                { path: 'contentCategory', name: 'contentCategory', component: ContentCategory },
                { path: 'dashboard', name: 'dashboard', component: Dashboard },
                { path: 'deliveryRegion', name: 'deliveryRegion', component: DeliveryRegion },
                { path: 'deliveryRoute', name: 'deliveryRoute', component: DeliveryRoute },
                { path: 'division', name: 'division', component: Division },
                { path: 'friendlyLink', name: 'friendlyLink', component: FriendlyLink },
                { path: 'home', name: 'home', component: Home },
                { path: 'member', name: 'member', component: Member },
                { path: 'memberType', name: 'memberType', component: MemberType },
                { path: 'param', name: 'param', component: Param },
                { path: 'permission', name: 'permission', component: Permission },
                { path: 'region', name: 'region', component: Region },
                { path: 'route', name: 'route', component: Route },

                { path: 'shift', name: 'shift', component: Shift },

                { path: 'drawerExample', name: 'drawerExample', component: DrawerExample },
                { path: 'exportExample', name: 'exportExample', component: ExportExample },
                { path: 'importExample', name: 'importExample', component: ImportExample },
                
                { path: 'printExample', name: 'printExample', component: PrintExample },
                { path: 'printLabelExample', name: 'printLabelExample', component: PrintLabelExample },
                { path: 'quillEditorExample', name: 'quillEditorExample', component: QuillEditorExample },
                { path: 'sundryExample', name: 'sundryExample', component: SundryExample },

                { path: 'packageDelivering', name: 'packageDelivering', component: PackageDelivering },
                { path: 'packageHistory', name: 'packageHistory', component: PackageHistory },

                { path: 'OpenOrderList', name: 'OpenOrderList', component: OpenOrderList },
                { path: 'OpenOrder', name: 'OpenOrder', component: OpenOrder },
                { path: 'SmallBagStoring', name: 'SmallBagStoring', component: SmallBagStoring },
                { path: 'BigBagStoring', name: 'BigBagStoring', component: BigBagStoring },
                { path: 'PackageSignList', name: 'PackageSignList', component: PackageSignList },
                { path: 'PackageSign', name: 'PackageSign', component: PackageSign },
                { path: 'PackageSignListItemOpenOrder', hidden: true, name: 'PackageSignListItemOpenOrder', component: PackageSignListItemOpenOrder },
                { path: 'MerchandiseStoring', hidden: false, name: 'MerchandiseStoring', component: () => import('@/views/merchandise/MerchandiseStoring') },
                { path: 'ScanStoringSmallBagSlowExpress', hidden: false, name: 'ScanStoringSmallBagSlowExpress', component: () => import('@/views/merchandise/ScanStoringSmallBagSlowExpress') },
                { path: 'PackageStoringSmallBagSlowExpress', hidden: false, name: 'PackageStoringSmallBagSlowExpress', component: () => import('@/views/merchandise/PackageStoringSmallBagSlowExpress') },
                { path: 'PackageStoringSmallBagSlowExpressList', hidden: false, name: 'PackageStoringSmallBagSlowExpressList', component: () => import('@/views/merchandise/PackageStoringSmallBagSlowExpressList') },
                { path: 'MerchandiseInfoSupplementAndCheckList', hidden: false, name: 'MerchandiseInfoSupplementAndCheckList', component: () => import('@/views/merchandise/MerchandiseInfoSupplementAndCheckList') },
                { path: 'MerchandiseStrageList', hidden: false, name: 'MerchandiseStrageList', component: () => import('@/views/merchandise/MerchandiseStorageList') },
                { path: 'MerchandiseInfoSupplementAndCheckEdit', hidden: false, name: 'MerchandiseInfoSupplementAndCheckEdit', component: () => import('@/views/merchandise/MerchandiseInfoSupplementAndCheckEdit') },
                { path: 'MerchandiseShipCreate', hidden: false, name: 'MerchandiseShipCreate', component: () => import('@/views/merchandise/MerchandiseShipCreate') },
                { path: 'MerchandiseSettlementList', hidden: false, name: 'MerchandiseSettlementList', component: () => import('@/views/merchandise/MerchandiseSettlementList') },
                { path: 'MerchandiseExpressInfoList', hidden: false, name: 'MerchandiseExpressInfoList', component: () => import('@/views/merchandise/MerchandiseExpressInfoList') },
                { path: 'MerchandiseExpressGatherList', hidden: false, name: 'MerchandiseExpressGatherList', component: () => import('@/views/merchandise/MerchandiseExpressGatherList') },
                { path: 'MerchandiseCollectFreightList', name: 'MerchandiseCollectFreightList', component: () => import('@/views/merchandise/MerchandiseCollectFreightList') },
                { path: 'MerchandiseUnpackScanCheckList', name: 'MerchandiseUnpackScanCheckList', component: () => import('@/views/merchandise/MerchandiseUnpackScanCheckList') },
                { path: 'MerchandiseDestKongStoreList', name: 'MerchandiseDestKongStoreList', component: () => import('@/views/merchandise/MerchandiseDestKongStoreList') },
                { path: 'ShipPackageManageList', name: 'ShipPackageManageList', component: () => import('@/views/merchandise/ShipPackageManageList') },
                { path: 'ExpressInfoPackageManageList', name: 'ExpressInfoPackageManageList', component: () => import('@/views/merchandise/ExpressInfoPackageManageList') },
                { path: 'MerchandiseQuickStorageList', name: 'MerchandiseQuickStorageList', component:() => import('@/views/merchandise/MerchandiseQuickStorageList') },
                { path: 'MerchandiseSupplementOrder', name: 'MerchandiseSupplementOrder', component:() => import('@/views/merchandise/MerchandiseSupplementOrder') },
                { path: 'PostShippingCheckList', name: 'PostShippingCheckList', component:() => import('@/views/merchandise/PostShippingCheckList') },
                { path: 'PostShipCheckList', name: 'PostShipCheckList', component:() => import('@/views/merchandise/PostShipCheckList') },
                { path: 'PostUnpackCheckList', name: 'PostUnpackCheckList', component:() => import('@/views/merchandise/PostUnpackCheckList') },
                { path: 'MerchandiseStorageEdit',name:'MerchandiseStorageEdit',component:() => import('@/views/merchandise/MerchandiseStorageEdit')},
                { path: 'MerchandisePackageAdd',name:'MerchandisePackageAdd',component:() => import('@/views/merchandise/MerchandisePackageAdd')},
            ]
        },
        { path: '/delivery', name: 'delivery', component: Delivery },
        { path: '/deliveringInspection', name: 'deliveringInspection', component: DeliveringInspection },
        { path: '/loadingInspection', name: 'loadingInspection', component: LoadingInspection },
        { path: '/unpackingInspection', name: 'unpackingInspection', component: UnpackingInspection },

    ]
})

router.beforeEach((to, _, next) => {
    store.commit('DEFAULT_ACTIVE', to.name)

    if (localStorage.getItem('TOKEN')) {
        to.name === 'login' ? next({ name: 'home' }) : next()
    } else {
        to.name === 'login' ? next() : next({ name: 'login' })
    }
})

export default router
